import { useEffect, useState } from "react";
import { getUserFriendlyError } from "@/lib/error-utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Trash2, Settings2, ChevronDown, ChevronUp, Copy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface OptionGroup {
  id: string;
  name: string;
  description: string | null;
  is_required: boolean;
  min_selections: number;
  max_selections: number;
  sort_order: number;
  product_options: Option[];
}

interface Option {
  id: string;
  name: string;
  price_adjustment: number;
  is_available: boolean;
  sort_order: number;
}

interface Props {
  productId: string;
  restaurantId: string;
}

const ProductOptionsManager = ({ productId, restaurantId }: Props) => {
  const [groups, setGroups] = useState<OptionGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedGroup, setExpandedGroup] = useState<string | null>(null);
  const [newGroupName, setNewGroupName] = useState("");
  const [addingOption, setAddingOption] = useState<string | null>(null);
  const [newOption, setNewOption] = useState({ name: "", price_adjustment: "" });
  const { toast } = useToast();

  useEffect(() => {
    loadGroups();
  }, [productId]);

  const loadGroups = async () => {
    const { data, error } = await supabase
      .from("product_option_groups")
      .select("*, product_options(*)")
      .eq("product_id", productId)
      .order("sort_order");

    if (!error && data) {
      const sorted = data.map((g: any) => ({
        ...g,
        product_options: (g.product_options || []).sort((a: any, b: any) => a.sort_order - b.sort_order),
      }));
      setGroups(sorted);
    }
    setLoading(false);
  };

  const addGroup = async () => {
    if (!newGroupName.trim()) return;
    const { error } = await supabase.from("product_option_groups").insert({
      product_id: productId,
      restaurant_id: restaurantId,
      name: newGroupName.trim(),
      sort_order: groups.length,
    });
    if (error) {
      toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" });
      return;
    }
    setNewGroupName("");
    toast({ title: "Grupo creado" });
    loadGroups();
  };

  const deleteGroup = async (groupId: string) => {
    await supabase.from("product_option_groups").delete().eq("id", groupId);
    toast({ title: "Grupo eliminado" });
    loadGroups();
  };

  const updateGroup = async (groupId: string, updates: Partial<OptionGroup>) => {
    await supabase.from("product_option_groups").update(updates).eq("id", groupId);
    loadGroups();
  };

  const addOption = async (groupId: string) => {
    if (!newOption.name.trim()) return;
    const group = groups.find((g) => g.id === groupId);
    const { error } = await supabase.from("product_options").insert({
      option_group_id: groupId,
      name: newOption.name.trim(),
      price_adjustment: parseFloat(newOption.price_adjustment) || 0,
      sort_order: group?.product_options.length || 0,
    });
    if (error) {
      toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" });
      return;
    }
    setNewOption({ name: "", price_adjustment: "" });
    setAddingOption(null);
    toast({ title: "Opción añadida" });
    loadGroups();
  };

  const deleteOption = async (optionId: string) => {
    await supabase.from("product_options").delete().eq("id", optionId);
    toast({ title: "Opción eliminada" });
    loadGroups();
  };

  const toggleOptionAvailable = async (optionId: string, current: boolean) => {
    await supabase.from("product_options").update({ is_available: !current }).eq("id", optionId);
    loadGroups();
  };

  // --- Import from another product ---
  const [importOpen, setImportOpen] = useState(false);
  const [otherProducts, setOtherProducts] = useState<{ id: string; name: string; groupCount: number }[]>([]);
  const [loadingImport, setLoadingImport] = useState(false);
  const [copying, setCopying] = useState(false);

  const loadOtherProducts = async () => {
    setLoadingImport(true);
    const { data } = await supabase
      .from("product_option_groups")
      .select("product_id, products(id, name)")
      .eq("restaurant_id", restaurantId)
      .neq("product_id", productId);

    if (data) {
      const map = new Map<string, { id: string; name: string; groupCount: number }>();
      data.forEach((row: any) => {
        const p = row.products;
        if (!p) return;
        const existing = map.get(p.id);
        if (existing) {
          existing.groupCount++;
        } else {
          map.set(p.id, { id: p.id, name: p.name, groupCount: 1 });
        }
      });
      setOtherProducts(Array.from(map.values()));
    }
    setLoadingImport(false);
  };

  const copyFromProduct = async (sourceProductId: string) => {
    setCopying(true);
    try {
      const { data: sourceGroups } = await supabase
        .from("product_option_groups")
        .select("*, product_options(*)")
        .eq("product_id", sourceProductId)
        .order("sort_order");

      if (!sourceGroups?.length) {
        toast({ title: "Sin opciones", description: "Este producto no tiene opciones." });
        setCopying(false);
        return;
      }

      const currentMaxSort = groups.length;

      for (let i = 0; i < sourceGroups.length; i++) {
        const sg = sourceGroups[i];
        const { data: newGroup } = await supabase
          .from("product_option_groups")
          .insert({
            product_id: productId,
            restaurant_id: restaurantId,
            name: sg.name,
            description: sg.description,
            is_required: sg.is_required,
            min_selections: sg.min_selections,
            max_selections: sg.max_selections,
            sort_order: currentMaxSort + i,
          })
          .select("id")
          .single();

        if (newGroup && sg.product_options?.length) {
          const opts = sg.product_options.map((o: any) => ({
            option_group_id: newGroup.id,
            name: o.name,
            price_adjustment: o.price_adjustment,
            is_available: o.is_available,
            sort_order: o.sort_order,
          }));
          await supabase.from("product_options").insert(opts);
        }
      }

      toast({ title: "Opciones copiadas", description: `Se copiaron ${sourceGroups.length} grupo(s) de opciones.` });
      setImportOpen(false);
      loadGroups();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
    setCopying(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-6">
        <div className="animate-spin w-5 h-5 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Separator />
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Settings2 className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-sm">Extras y Opciones</h3>
        </div>
        <Dialog open={importOpen} onOpenChange={(open) => { setImportOpen(open); if (open) loadOtherProducts(); }}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="h-7 text-xs gap-1">
              <Copy className="w-3 h-3" /> Copiar de otro producto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle className="text-base">Copiar opciones de otro producto</DialogTitle>
            </DialogHeader>
            {loadingImport ? (
              <div className="flex justify-center py-6">
                <div className="animate-spin w-5 h-5 border-2 border-primary border-t-transparent rounded-full" />
              </div>
            ) : otherProducts.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No hay otros productos con opciones configuradas.</p>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {otherProducts.map((p) => (
                  <button
                    key={p.id}
                    disabled={copying}
                    onClick={() => copyFromProduct(p.id)}
                    className="w-full flex items-center justify-between p-3 rounded-lg border border-border hover:bg-accent/50 transition-colors text-left disabled:opacity-50"
                  >
                    <span className="text-sm font-medium">{p.name}</span>
                    <Badge variant="secondary" className="text-[10px]">{p.groupCount} grupo(s)</Badge>
                  </button>
                ))}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
      <p className="text-xs text-muted-foreground">
        Crea grupos como "Tamaño", "Extras" o "Ingredientes" con sus opciones y precios.
      </p>

      {/* Existing groups */}
      {groups.map((group) => (
        <Card key={group.id} className="border-border/60">
          <CardHeader className="py-3 px-4 cursor-pointer" onClick={() => setExpandedGroup(expandedGroup === group.id ? null : group.id)}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CardTitle className="text-sm">{group.name}</CardTitle>
                {group.is_required && <Badge variant="secondary" className="text-[10px]">Obligatorio</Badge>}
                <Badge variant="outline" className="text-[10px]">{group.product_options.length} opciones</Badge>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={(e) => { e.stopPropagation(); deleteGroup(group.id); }}>
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
                {expandedGroup === group.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </div>
            </div>
          </CardHeader>

          {expandedGroup === group.id && (
            <CardContent className="pt-0 px-4 pb-4 space-y-3">
              {/* Group settings */}
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={group.is_required}
                    onCheckedChange={(v) => updateGroup(group.id, { is_required: v })}
                  />
                  <Label className="text-xs">Obligatorio</Label>
                </div>
                <div className="flex items-center gap-1">
                  <Label className="text-xs whitespace-nowrap">Máx. selecciones:</Label>
                  <Input
                    type="number"
                    min={1}
                    className="w-16 h-7 text-xs"
                    value={group.max_selections}
                    onChange={(e) => updateGroup(group.id, { max_selections: parseInt(e.target.value) || 1 })}
                  />
                </div>
              </div>

              <Separator className="my-2" />

              {/* Options list */}
              {group.product_options.length > 0 ? (
                <div className="space-y-1.5">
                  {group.product_options.map((opt) => (
                    <div key={opt.id} className="flex items-center justify-between bg-muted/50 rounded-lg px-3 py-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{opt.name}</span>
                        {opt.price_adjustment !== 0 && (
                          <Badge variant="outline" className="text-[10px]">
                            {opt.price_adjustment > 0 ? "+" : ""}${Number(opt.price_adjustment).toFixed(2)}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-1">
                        <Switch
                          checked={opt.is_available}
                          onCheckedChange={() => toggleOptionAvailable(opt.id, opt.is_available)}
                        />
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteOption(opt.id)}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground text-center py-2">Sin opciones aún</p>
              )}

              {/* Add option */}
              {addingOption === group.id ? (
                <div className="flex items-end gap-2">
                  <div className="flex-1">
                    <Label className="text-xs">Nombre</Label>
                    <Input
                      className="h-8 text-sm"
                      placeholder="Ej: Grande"
                      value={newOption.name}
                      onChange={(e) => setNewOption({ ...newOption, name: e.target.value })}
                      onKeyDown={(e) => e.key === "Enter" && addOption(group.id)}
                    />
                  </div>
                  <div className="w-24">
                    <Label className="text-xs">+Precio</Label>
                    <Input
                      type="number"
                      step="0.01"
                      className="h-8 text-sm"
                      placeholder="0.00"
                      value={newOption.price_adjustment}
                      onChange={(e) => setNewOption({ ...newOption, price_adjustment: e.target.value })}
                      onKeyDown={(e) => e.key === "Enter" && addOption(group.id)}
                    />
                  </div>
                  <Button size="sm" className="h-8" onClick={() => addOption(group.id)}>Añadir</Button>
                  <Button size="sm" variant="ghost" className="h-8" onClick={() => { setAddingOption(null); setNewOption({ name: "", price_adjustment: "" }); }}>✕</Button>
                </div>
              ) : (
                <Button variant="outline" size="sm" className="w-full text-xs" onClick={() => setAddingOption(group.id)}>
                  <Plus className="w-3 h-3 mr-1" /> Añadir opción
                </Button>
              )}
            </CardContent>
          )}
        </Card>
      ))}

      {/* Add new group */}
      <div className="flex gap-2">
        <Input
          className="h-9 text-sm"
          placeholder="Nombre del grupo (Ej: Tamaño, Extras...)"
          value={newGroupName}
          onChange={(e) => setNewGroupName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addGroup()}
        />
        <Button size="sm" className="h-9 shrink-0" onClick={addGroup} disabled={!newGroupName.trim()}>
          <Plus className="w-4 h-4 mr-1" /> Grupo
        </Button>
      </div>
    </div>
  );
};

export default ProductOptionsManager;
