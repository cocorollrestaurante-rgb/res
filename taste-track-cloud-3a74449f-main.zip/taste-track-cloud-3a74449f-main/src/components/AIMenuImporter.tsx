import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Upload, Sparkles, Loader2, Trash2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ExtractedProduct {
  name: string;
  description: string;
  price: number;
  category_id: string;
  selected: boolean;
}

interface AIMenuImporterProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  categories: { id: string; name: string; icon?: string }[];
  restaurantId: string;
  onImported: () => void;
}

const AIMenuImporter = ({ open, onOpenChange, categories, restaurantId, onImported }: AIMenuImporterProps) => {
  const [step, setStep] = useState<"upload" | "extracting" | "preview" | "saving">("upload");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [products, setProducts] = useState<ExtractedProduct[]>([]);
  const [defaultCategory, setDefaultCategory] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const reset = () => {
    setStep("upload");
    setImagePreview(null);
    setProducts([]);
    setDefaultCategory("");
  };

  const handleClose = (open: boolean) => {
    if (!open) reset();
    onOpenChange(open);
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(",")[1]);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast({ title: "Error", description: "Solo se permiten imágenes.", variant: "destructive" });
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast({ title: "Error", description: "Máximo 10MB.", variant: "destructive" });
      return;
    }

    const preview = URL.createObjectURL(file);
    setImagePreview(preview);
    setStep("extracting");

    try {
      const base64 = await fileToBase64(file);
      const { data, error } = await supabase.functions.invoke("extract-menu", {
        body: { imageBase64: base64, mimeType: file.type },
      });

      if (error) throw new Error("No se pudo procesar el menú. Inténtalo de nuevo.");
      if (data?.error) throw new Error(data.error);

      const extracted: ExtractedProduct[] = (data.products || []).map((p: any) => ({
        name: p.name || "",
        description: p.description || "",
        price: Number(p.price) || 0,
        category_id: "",
        selected: true,
      }));

      if (extracted.length === 0) {
        toast({ title: "Sin resultados", description: "No se encontraron productos en la imagen. Intenta con otra foto.", variant: "destructive" });
        setStep("upload");
        return;
      }

      setProducts(extracted);
      setStep("preview");
    } catch (err: any) {
      console.error("AI extraction error:", err);
      toast({ title: "Error", description: err.message || "No se pudo analizar la imagen.", variant: "destructive" });
      setStep("upload");
    }
  };

  const updateProduct = (index: number, field: keyof ExtractedProduct, value: any) => {
    setProducts((prev) => prev.map((p, i) => (i === index ? { ...p, [field]: value } : p)));
  };

  const applyDefaultCategory = () => {
    if (!defaultCategory) return;
    setProducts((prev) => prev.map((p) => (p.category_id ? p : { ...p, category_id: defaultCategory })));
  };

  const handleImport = async () => {
    const selected = products.filter((p) => p.selected && p.name.trim());
    if (selected.length === 0) {
      toast({ title: "Error", description: "Selecciona al menos un producto.", variant: "destructive" });
      return;
    }

    setStep("saving");
    try {
      const payload = selected.map((p) => ({
        name: p.name.trim(),
        description: p.description || null,
        price: p.price,
        category_id: p.category_id || null,
        restaurant_id: restaurantId,
      }));

      const { error } = await supabase.from("products").insert(payload);
      if (error) throw error;

      toast({ title: "¡Menú importado!", description: `${selected.length} producto${selected.length > 1 ? "s" : ""} creado${selected.length > 1 ? "s" : ""}.` });
      handleClose(false);
      onImported();
    } catch (err: any) {
      console.error("Import error:", err);
      toast({ title: "Error", description: err.message || "No se pudieron crear los productos.", variant: "destructive" });
      setStep("preview");
    }
  };

  const selectedCount = products.filter((p) => p.selected).length;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Importar Menú con IA
          </DialogTitle>
        </DialogHeader>

        {step === "upload" && (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Sube una foto de tu menú actual y la IA extraerá automáticamente los productos con sus precios.
            </p>
            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileSelect} className="hidden" />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-48 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-3 text-muted-foreground hover:border-primary hover:text-primary transition-colors"
            >
              <Upload className="w-10 h-10" />
              <div className="text-center">
                <p className="font-medium">Toca para subir una foto</p>
                <p className="text-xs mt-1">JPG, PNG • Máximo 10MB</p>
              </div>
            </button>
          </div>
        )}

        {step === "extracting" && (
          <div className="space-y-4">
            {imagePreview && (
              <div className="w-full h-40 rounded-xl overflow-hidden border border-border">
                <img src={imagePreview} alt="Menu" className="w-full h-full object-cover" />
              </div>
            )}
            <div className="flex flex-col items-center gap-3 py-8">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
              <p className="text-sm font-medium">Analizando menú con IA...</p>
              <p className="text-xs text-muted-foreground">Esto puede tardar unos segundos</p>
            </div>
          </div>
        )}

        {step === "preview" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Se encontraron <strong>{products.length}</strong> productos. Revisa, asigna categorías y confirma.
              </p>
            </div>

            {categories.length > 0 && (
              <div className="flex items-end gap-2 p-3 rounded-lg bg-muted/50 border border-border">
                <div className="flex-1">
                  <Label className="text-xs">Asignar categoría a todos sin categoría</Label>
                  <Select value={defaultCategory} onValueChange={setDefaultCategory}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Seleccionar categoría..." />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((c) => (
                        <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button variant="outline" size="sm" onClick={applyDefaultCategory} disabled={!defaultCategory}>
                  Aplicar
                </Button>
              </div>
            )}

            <div className="space-y-3 max-h-[45vh] overflow-y-auto pr-1">
              {products.map((p, i) => (
                <div key={i} className={`border rounded-lg p-3 space-y-2 transition-opacity ${!p.selected ? "opacity-50" : ""}`}>
                  <div className="flex items-start gap-2">
                    <Checkbox
                      checked={p.selected}
                      onCheckedChange={(v) => updateProduct(i, "selected", !!v)}
                      className="mt-1"
                    />
                    <div className="flex-1 space-y-2">
                      <div className="flex gap-2">
                        <Input
                          value={p.name}
                          onChange={(e) => updateProduct(i, "name", e.target.value)}
                          placeholder="Nombre"
                          className="flex-1 text-sm font-medium"
                        />
                        <Input
                          type="number"
                          step="0.01"
                          value={p.price}
                          onChange={(e) => updateProduct(i, "price", parseFloat(e.target.value) || 0)}
                          placeholder="Precio"
                          className="w-24 text-sm"
                        />
                      </div>
                      <Input
                        value={p.description}
                        onChange={(e) => updateProduct(i, "description", e.target.value)}
                        placeholder="Descripción (opcional)"
                        className="text-sm"
                      />
                      {categories.length > 0 && (
                        <Select value={p.category_id} onValueChange={(v) => updateProduct(i, "category_id", v)}>
                          <SelectTrigger className="text-sm">
                            <SelectValue placeholder="Sin categoría" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((c) => (
                              <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="shrink-0 text-destructive"
                      onClick={() => setProducts((prev) => prev.filter((_, idx) => idx !== i))}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-2 border-t">
              <p className="text-sm text-muted-foreground">{selectedCount} seleccionados</p>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => handleClose(false)}>Cancelar</Button>
                <Button onClick={handleImport} disabled={selectedCount === 0}>
                  <Sparkles className="w-4 h-4 mr-1.5" />
                  Importar {selectedCount} producto{selectedCount !== 1 ? "s" : ""}
                </Button>
              </div>
            </div>
          </div>
        )}

        {step === "saving" && (
          <div className="flex flex-col items-center gap-3 py-8">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
            <p className="text-sm font-medium">Creando productos...</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default AIMenuImporter;
