import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import OwnerDashboard from "./pages/owner/Dashboard";
import OwnerCategories from "./pages/owner/Categories";
import OwnerProducts from "./pages/owner/Products";
import OwnerDelivery from "./pages/owner/Delivery";
import OwnerPayments from "./pages/owner/Payments";
import OwnerSettings from "./pages/owner/Settings";
import OwnerOrders from "./pages/owner/Orders";
import OwnerReports from "./pages/owner/Reports";
import OwnerPlan from "./pages/owner/Plan";
import PublicMenu from "./pages/menu/PublicMenu";
import AdminDashboard from "./pages/admin/AdminDashboard";
import OrderTracking from "./pages/order/OrderTracking";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/owner" element={<OwnerDashboard />} />
          <Route path="/owner/categories" element={<OwnerCategories />} />
          <Route path="/owner/products" element={<OwnerProducts />} />
          <Route path="/owner/products/new" element={<OwnerProducts />} />
          <Route path="/owner/delivery" element={<OwnerDelivery />} />
          <Route path="/owner/payments" element={<OwnerPayments />} />
          <Route path="/owner/settings" element={<OwnerSettings />} />
          <Route path="/owner/orders" element={<OwnerOrders />} />
          <Route path="/owner/reports" element={<OwnerReports />} />
          <Route path="/owner/plan" element={<OwnerPlan />} />
          <Route path="/menu/:slug" element={<PublicMenu />} />
          <Route path="/order/tracking/:orderId" element={<OrderTracking />} />
          <Route path="/admin" element={<AdminDashboard />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;