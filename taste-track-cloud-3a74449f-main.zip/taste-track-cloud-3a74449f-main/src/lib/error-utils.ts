/**
 * Returns a user-friendly error message instead of raw database/API error details.
 * Logs the full error server-side for debugging.
 */
export function getUserFriendlyError(error: { message?: string; code?: string } | null): string {
  if (!error) return "Ocurrió un error inesperado.";

  // Log full error for debugging (visible in dev tools, not exposed in UI)
  console.error("[App Error]", error);

  // Map known error codes to user-friendly messages
  if (error.code === "23505") return "Este elemento ya existe.";
  if (error.code === "23503") return "No se puede eliminar porque está en uso.";
  if (error.code === "42501") return "No tienes permisos para realizar esta acción.";
  if (error.code === "PGRST301") return "No tienes permisos para realizar esta acción.";

  // Auth-specific messages we can safely pass through
  if (error.message?.includes("User already registered")) {
    return "Este correo ya está registrado. Intenta iniciar sesión.";
  }
  if (error.message?.includes("Invalid login credentials")) {
    return "Correo o contraseña incorrectos.";
  }
  if (error.message?.includes("Email not confirmed")) {
    return "Debes confirmar tu correo electrónico antes de iniciar sesión.";
  }

  // Generic fallback
  return "No se pudo completar la operación. Inténtalo de nuevo.";
}
