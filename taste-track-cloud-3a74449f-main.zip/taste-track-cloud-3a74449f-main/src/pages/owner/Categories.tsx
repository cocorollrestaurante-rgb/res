import { useEffect, useState } from "react";
import { getUserFriendlyError } from "@/lib/error-utils";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Pencil, Trash2, Tag } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import OwnerLayout from "@/components/OwnerLayout";

const Categories = () => {
  const [categories, setCategories] = useState<any[]>([]);
  const [restaurant, setRestaurant] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<any>(null);
  const [form, setForm] = useState({ name: "", description: "", icon: "" });
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) { navigate("/auth"); return; }
    const { data: rest } = await supabase.from("restaurants").select("*").eq("owner_id", session.user.id).limit(1).maybeSingle();
    if (!rest) { toast({ title: "Sin restaurante", description: "Primero crea tu restaurante en configuración.", variant: "destructive" }); navigate("/owner"); return; }
    setRestaurant(rest);
    const { data: cats } = await supabase.from("categories").select("*").eq("restaurant_id", rest.id).order("sort_order");
    setCategories(cats || []);
    setLoading(false);
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast({ title: "Error", description: "El nombre es obligatorio.", variant: "destructive" }); return; }
    if (editingCategory) {
      const { error } = await supabase.from("categories").update({ name: form.name, description: form.description || null, icon: form.icon || null }).eq("id", editingCategory.id);
      if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); return; }
      toast({ title: "Categoría actualizada" });
    } else {
      const { error } = await supabase.from("categories").insert({ name: form.name, description: form.description || null, icon: form.icon || null, restaurant_id: restaurant.id });
      if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); return; }
      toast({ title: "Categoría creada" });
    }
    setDialogOpen(false); setEditingCategory(null); setForm({ name: "", description: "", icon: "" }); loadData();
  };

  const handleEdit = (cat: any) => { setEditingCategory(cat); setForm({ name: cat.name, description: cat.description || "", icon: cat.icon || "" }); setDialogOpen(true); };
  const handleDelete = async (id: string) => { await supabase.from("categories").delete().eq("id", id); toast({ title: "Categoría eliminada" }); loadData(); };
  const toggleActive = async (id: string, current: boolean) => { await supabase.from("categories").update({ is_active: !current }).eq("id", id); loadData(); };

  const addButton = (
    <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) { setEditingCategory(null); setForm({ name: "", description: "", icon: "" }); } }}>
      <DialogTrigger asChild>
        <Button size="sm" className="bg-gradient-to-r from-primary to-accent text-primary-foreground"><Plus className="w-4 h-4 mr-1.5" /> Nueva</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>{editingCategory ? "Editar Categoría" : "Nueva Categoría"}</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div><Label>Nombre *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ej: Entradas, Bebidas..." /></div>
          <div><Label>Descripción</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Descripción opcional" /></div>
          <div><Label>Ícono (emoji)</Label><Input value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} placeholder="🍔" /></div>
          <Button onClick={handleSave} className="w-full">Guardar</Button>
        </div>
      </DialogContent>
    </Dialog>
  );

  if (loading) return <OwnerLayout title="Categorías" actions={addButton}><div className="flex items-center justify-center h-64"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" /></div></OwnerLayout>;

  return (
    <OwnerLayout title="Categorías" subtitle={`${categories.length} categoría${categories.length !== 1 ? 's' : ''}`} actions={addButton}>
      {categories.length === 0 ? (
        <Card className="text-center py-12"><CardContent>
          <Tag className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">Sin categorías</h3>
          <p className="text-muted-foreground mb-4">Crea tu primera categoría para organizar tus productos.</p>
          <Button onClick={() => setDialogOpen(true)} className="bg-gradient-to-r from-primary to-accent text-primary-foreground"><Plus className="w-4 h-4 mr-2" /> Crear Categoría</Button>
        </CardContent></Card>
      ) : (
        <Card>
          <Table>
            <TableHeader><TableRow>
              <TableHead>Ícono</TableHead><TableHead>Nombre</TableHead><TableHead className="hidden sm:table-cell">Descripción</TableHead><TableHead>Activa</TableHead><TableHead className="text-right">Acciones</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {categories.map((cat) => (
                <TableRow key={cat.id}>
                  <TableCell className="text-2xl">{cat.icon || "📁"}</TableCell>
                  <TableCell className="font-medium">{cat.name}</TableCell>
                  <TableCell className="text-muted-foreground hidden sm:table-cell">{cat.description || "—"}</TableCell>
                  <TableCell><Switch checked={cat.is_active} onCheckedChange={() => toggleActive(cat.id, cat.is_active)} /></TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(cat)}><Pencil className="w-4 h-4" /></Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="text-destructive"><Trash2 className="w-4 h-4" /></Button></AlertDialogTrigger>
                        <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>¿Eliminar categoría?</AlertDialogTitle><AlertDialogDescription>Esta acción no se puede deshacer.</AlertDialogDescription></AlertDialogHeader>
                        <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => handleDelete(cat.id)}>Eliminar</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </OwnerLayout>
  );
};

export default Categories;
