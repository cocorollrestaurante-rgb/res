import { useEffect, useState, useRef } from "react";
import { getUserFriendlyError } from "@/lib/error-utils";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Save, Store, Upload, X, Clock, CheckCircle2, AlertCircle, Star, BarChart3, Globe, Instagram } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import OwnerLayout from "@/components/OwnerLayout";

const DAYS = [
  { key: "lunes", label: "Lunes" },
  { key: "martes", label: "Martes" },
  { key: "miércoles", label: "Miércoles" },
  { key: "jueves", label: "Jueves" },
  { key: "viernes", label: "Viernes" },
  { key: "sábado", label: "Sábado" },
  { key: "domingo", label: "Domingo" },
];

const defaultHours = DAYS.reduce((acc, d) => {
  acc[d.key] = { open: "09:00", close: "21:00", enabled: true };
  return acc;
}, {} as Record<string, { open: string; close: string; enabled: boolean }>);

const Settings = () => {
  const [restaurant, setRestaurant] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isNew, setIsNew] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [coverPreview, setCoverPreview] = useState<string | null>(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);
  const logoRef = useRef<HTMLInputElement>(null);
  const coverRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState({ name: "", slug: "", description: "", address: "", phone: "", email: "", logo_url: "", cover_url: "", review_link: "", facebook_pixel_id: "", delivery_time: "", instagram_url: "", facebook_url: "", website_url: "", review_widget_id: "" });
  const [openingHours, setOpeningHours] = useState<Record<string, { open: string; close: string; enabled: boolean }>>(defaultHours);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) { navigate("/auth"); return; }
    const { data: rest } = await supabase.from("restaurants").select("*").eq("owner_id", session.user.id).limit(1).maybeSingle();
    if (rest) {
      const restAny = rest as any;
      setRestaurant(restAny);
      setForm({ name: rest.name, slug: rest.slug, description: rest.description || "", address: rest.address || "", phone: rest.phone || "", email: rest.email || "", logo_url: rest.logo_url || "", cover_url: rest.cover_url || "", review_link: (restAny as any).review_link || "", facebook_pixel_id: (restAny as any).facebook_pixel_id || "", delivery_time: (restAny as any).delivery_time || "", instagram_url: (restAny as any).instagram_url || "", facebook_url: (restAny as any).facebook_url || "", website_url: (restAny as any).website_url || "", review_widget_id: (restAny as any).review_widget_id || "" });
      setLogoPreview(rest.logo_url || null);
      setCoverPreview(rest.cover_url || null);
      if (rest.opening_hours && typeof rest.opening_hours === "object" && Object.keys(rest.opening_hours).length > 0) {
        setOpeningHours({ ...defaultHours, ...(rest.opening_hours as any) });
      }
    } else { setIsNew(true); }
    setLoading(false);
  };

  const generateSlug = (name: string) => name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

  const handleUpload = async (file: File, type: "logo" | "cover") => {
    if (!file.type.startsWith("image/")) { toast({ title: "Error", description: "Solo imágenes.", variant: "destructive" }); return; }
    if (file.size > 5 * 1024 * 1024) { toast({ title: "Error", description: "Máximo 5MB.", variant: "destructive" }); return; }
    const setUploading = type === "logo" ? setUploadingLogo : setUploadingCover;
    setUploading(true);
    const ext = file.name.split(".").pop();
    const restId = restaurant?.id || "new";
    const fileName = `${restId}/${type}-${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("product-images").upload(fileName, file);
    if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); setUploading(false); return; }
    const { data: urlData } = supabase.storage.from("product-images").getPublicUrl(fileName);
    const url = urlData.publicUrl;
    if (type === "logo") { setForm((p) => ({ ...p, logo_url: url })); setLogoPreview(url); }
    else { setForm((p) => ({ ...p, cover_url: url })); setCoverPreview(url); }
    setUploading(false);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.slug.trim()) { toast({ title: "Error", description: "Nombre y slug son obligatorios.", variant: "destructive" }); return; }
    setSaving(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) { navigate("/auth"); return; }
    const payload = { name: form.name, slug: form.slug, description: form.description || null, address: form.address || null, phone: form.phone || null, email: form.email || null, logo_url: form.logo_url || null, cover_url: form.cover_url || null, opening_hours: openingHours, review_link: form.review_link || null, facebook_pixel_id: form.facebook_pixel_id || null, delivery_time: form.delivery_time || null, instagram_url: form.instagram_url || null, facebook_url: form.facebook_url || null, website_url: form.website_url || null, review_widget_id: (form as any).review_widget_id || null };

    if (isNew) {
      const { data, error } = await supabase.from("restaurants").insert({ ...payload, owner_id: session.user.id }).select().single();
      if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); setSaving(false); return; }
      setRestaurant(data); setIsNew(false);
      toast({ title: "¡Restaurante creado!", description: "Ya puedes agregar productos y categorías." });
    } else {
      const { error } = await supabase.from("restaurants").update(payload).eq("id", restaurant.id);
      if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); setSaving(false); return; }
      toast({ title: "Configuración guardada" });
    }
    setSaving(false);
  };

  const updateDayHours = (dayKey: string, field: "open" | "close" | "enabled", value: string | boolean) => {
    setOpeningHours(prev => ({ ...prev, [dayKey]: { ...prev[dayKey], [field]: value } }));
  };




  const saveButton = (
    <Button size="sm" onClick={handleSave} disabled={saving} className="bg-gradient-to-r from-primary to-accent text-primary-foreground">
      <Save className="w-4 h-4 mr-1.5" /> {saving ? "Guardando..." : "Guardar"}
    </Button>
  );

  if (loading) return <OwnerLayout title="Configuración" actions={saveButton}><div className="flex items-center justify-center h-64"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" /></div></OwnerLayout>;

  const ImageUploader = ({ label, preview, uploading: isUp, onFile, onRemove, inputRef }: any) => (
    <div>
      <Label>{label}</Label>
      <input type="file" accept="image/*" ref={inputRef} onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} className="hidden" />
      {preview ? (
        <div className="relative mt-2 w-full h-32 rounded-xl overflow-hidden border border-border">
          <img src={preview} alt={label} className="w-full h-full object-cover" />
          <button onClick={onRemove} className="absolute top-2 right-2 w-7 h-7 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button>
        </div>
      ) : (
        <button type="button" onClick={() => inputRef.current?.click()} disabled={isUp} className="mt-2 w-full h-24 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-1.5 text-muted-foreground hover:border-primary hover:text-primary transition-colors">
          {isUp ? <div className="animate-spin w-5 h-5 border-2 border-primary border-t-transparent rounded-full" /> : <><Upload className="w-5 h-5" /><span className="text-xs">Subir imagen</span></>}
        </button>
      )}
    </div>
  );

  return (
    <OwnerLayout title={isNew ? "Crear Restaurante" : "Configuración"} actions={saveButton}>
      <div className="max-w-2xl mx-auto space-y-5 px-1 sm:px-0">
        {isNew && (
          <Card className="bg-gradient-to-br from-primary to-accent text-primary-foreground">
            <CardContent className="p-6">
              <Store className="w-10 h-10 mb-3" />
              <h3 className="text-lg font-bold mb-1">¡Bienvenido!</h3>
              <p className="text-primary-foreground/80 text-sm">Configura tu restaurante para comenzar a crear tu menú digital.</p>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader><CardTitle className="text-base">Información General</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Nombre *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value, slug: generateSlug(e.target.value) })} placeholder="Mi Restaurante" /></div>
            <div><Label>Slug (URL) *</Label><Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} /><p className="text-xs text-muted-foreground mt-1">Tu menú: /menu/{form.slug || "slug"}</p></div>
            <div><Label>Descripción</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Descripción" /></div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Contacto</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Dirección</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Calle, Ciudad" /></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><Label>Teléfono</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+1 234 567" /></div>
              <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="contacto@..." /></div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><Clock className="w-4 h-4 text-primary" /> Tiempo de Envío</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <p className="text-xs text-muted-foreground">Define el tiempo estimado de entrega que verán tus clientes en el menú (ej: "25 - 45 mins").</p>
            <div>
              <Label>Tiempo estimado</Label>
              <Input value={form.delivery_time} onChange={(e) => setForm({ ...form, delivery_time: e.target.value })} placeholder="25 - 45 mins" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" /> Horario de Atención
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-xs text-muted-foreground mb-2">Configura los horarios en que tu restaurante acepta pedidos. Fuera de horario, los clientes podrán ver el menú pero no podrán ordenar.</p>
            {DAYS.map(day => (
              <div key={day.key} className="flex flex-wrap items-center gap-2 sm:gap-3 py-2.5 border-b border-border last:border-0">
                <div className="flex items-center gap-2 min-w-[140px]">
                  <Switch
                    checked={openingHours[day.key]?.enabled ?? true}
                    onCheckedChange={(v) => updateDayHours(day.key, "enabled", v)}
                  />
                  <span className={`text-sm font-medium ${openingHours[day.key]?.enabled ? "text-foreground" : "text-muted-foreground"}`}>{day.label}</span>
                </div>
                {openingHours[day.key]?.enabled ? (
                  <div className="flex items-center gap-2 ml-auto">
                    <Input
                      type="time"
                      value={openingHours[day.key]?.open || "09:00"}
                      onChange={(e) => updateDayHours(day.key, "open", e.target.value)}
                      className="w-[110px] sm:w-28 text-sm"
                    />
                    <span className="text-muted-foreground text-xs">a</span>
                    <Input
                      type="time"
                      value={openingHours[day.key]?.close || "21:00"}
                      onChange={(e) => updateDayHours(day.key, "close", e.target.value)}
                      className="w-[110px] sm:w-28 text-sm"
                    />
                  </div>
                ) : (
                  <span className="text-sm text-muted-foreground italic ml-auto">Cerrado</span>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Imágenes</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <ImageUploader label="Logo" preview={logoPreview} uploading={uploadingLogo} inputRef={logoRef} onFile={(f: File) => handleUpload(f, "logo")} onRemove={() => { setForm((p) => ({ ...p, logo_url: "" })); setLogoPreview(null); }} />
            <ImageUploader label="Portada" preview={coverPreview} uploading={uploadingCover} inputRef={coverRef} onFile={(f: File) => handleUpload(f, "cover")} onRemove={() => { setForm((p) => ({ ...p, cover_url: "" })); setCoverPreview(null); }} />
          </CardContent>
        </Card>

        {/* Review Link */}
        {!isNew && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Star className="w-4 h-4 text-primary" /> Reseñas Automáticas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-xs text-muted-foreground">
                Cuando un pedido a domicilio se marque como entregado, se enviará un email al cliente 2 horas después solicitando una reseña.
              </p>
              <div>
                <Label>Link de Reseñas</Label>
                <Input
                  value={form.review_link}
                  onChange={(e) => setForm({ ...form, review_link: e.target.value })}
                  placeholder="https://g.page/r/tu-negocio/review"
                />
                <p className="text-xs text-muted-foreground mt-1.5">
                  Pega tu enlace de Google Maps, TripAdvisor, o cualquier página de reseñas.
                </p>
              </div>
              {form.review_link && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-primary/5 border border-primary/20">
                  <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                  <p className="text-sm text-foreground">Los emails de reseña se enviarán automáticamente.</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Redes Sociales */}
        {!isNew && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Globe className="w-4 h-4 text-primary" /> Redes Sociales
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-xs text-muted-foreground">
                Agrega tus redes sociales para que aparezcan en tu menú público.
              </p>
              <div>
                <Label>Instagram</Label>
                <Input
                  value={form.instagram_url}
                  onChange={(e) => setForm({ ...form, instagram_url: e.target.value })}
                  placeholder="https://instagram.com/tu-negocio"
                />
              </div>
              <div>
                <Label>Facebook</Label>
                <Input
                  value={form.facebook_url}
                  onChange={(e) => setForm({ ...form, facebook_url: e.target.value })}
                  placeholder="https://facebook.com/tu-negocio"
                />
              </div>
              <div>
                <Label>Sitio Web</Label>
                <Input
                  value={form.website_url}
                  onChange={(e) => setForm({ ...form, website_url: e.target.value })}
                  placeholder="https://tu-negocio.com"
                />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Facebook Pixel */}
        {!isNew && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" /> Facebook Pixel
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-xs text-muted-foreground">
                Agrega tu Pixel de Facebook para rastrear visitas, productos agregados al carrito y pedidos completados.
              </p>
              <div>
                <Label>Pixel ID</Label>
                <Input
                  value={form.facebook_pixel_id}
                  onChange={(e) => setForm({ ...form, facebook_pixel_id: e.target.value })}
                  placeholder="123456789012345"
                />
                <p className="text-xs text-muted-foreground mt-1.5">
                  Obtén tu Pixel ID en <a href="https://business.facebook.com/events_manager" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Meta Business Suite → Eventos</a>
                </p>
              </div>
              {form.facebook_pixel_id && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-primary/5 border border-primary/20">
                  <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                  <p className="text-sm text-foreground">El Pixel se cargará en tu menú público.</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Widget de Reseñas */}
        {!isNew && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Star className="w-4 h-4 text-primary" /> Widget de Reseñas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-xs text-muted-foreground">
                Muestra las reseñas de tus clientes en tu menú digital. Pega el código completo del widget que te proporcionó tu plataforma de reseñas (ej: Rankify, Google Reviews, etc).
              </p>
              <div>
                <Label>Código del Widget</Label>
                <Textarea
                  value={form.review_widget_id}
                  onChange={(e) => setForm({ ...form, review_widget_id: e.target.value })}
                  placeholder={'<!-- Pega aquí el código completo del widget -->'}
                  rows={6}
                  className="font-mono text-xs"
                />
              </div>
              {form.review_widget_id && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-primary/5 border border-primary/20">
                  <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                  <p className="text-sm text-foreground">El widget de reseñas se mostrará en tu menú público.</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

      </div>
    </OwnerLayout>
  );
};

export default Settings;
