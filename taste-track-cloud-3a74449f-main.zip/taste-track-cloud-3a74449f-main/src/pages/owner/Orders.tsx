import { useState, useEffect } from "react";
import { getUserFriendlyError } from "@/lib/error-utils";
import { supabase } from "@/integrations/supabase/client";
import OwnerLayout from "@/components/OwnerLayout";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Clock, CheckCircle2, XCircle, Eye, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

interface Order {
  id: string;
  order_number: number;
  status: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string | null;
  customer_address: string | null;
  notes: string | null;
  subtotal: number;
  delivery_fee: number;
  total: number;
  created_at: string;
  delivery_types: { name: string } | null;
  payment_methods: { name: string } | null;
}

interface OrderItem {
  id: string;
  product_name: string;
  product_price: number;
  quantity: number;
  subtotal: number;
  notes: string | null;
}

const statusConfig: Record<string, { label: string; color: string; icon: any }> = {
  pending: { label: "Pendiente", color: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20", icon: Clock },
  confirmed: { label: "Confirmado", color: "bg-blue-500/10 text-blue-600 border-blue-500/20", icon: CheckCircle2 },
  preparing: { label: "Preparando", color: "bg-orange-500/10 text-orange-600 border-orange-500/20", icon: Clock },
  ready: { label: "Listo", color: "bg-green-500/10 text-green-600 border-green-500/20", icon: CheckCircle2 },
  on_the_way: { label: "En camino", color: "bg-purple-500/10 text-purple-600 border-purple-500/20", icon: Clock },
  delivered: { label: "Entregado", color: "bg-green-600/10 text-green-700 border-green-600/20", icon: CheckCircle2 },
  cancelled: { label: "Cancelado", color: "bg-red-500/10 text-red-600 border-red-500/20", icon: XCircle },
};

const OwnerOrders = () => {
  const { toast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  useEffect(() => {
    const fetchOrders = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;
      const { data: rest } = await supabase.from("restaurants").select("id").eq("owner_id", session.user.id).limit(1).maybeSingle();
      if (!rest) { setLoading(false); return; }

      const { data } = await supabase
        .from("orders")
        .select("*, delivery_types(name), payment_methods(name)")
        .eq("restaurant_id", rest.id)
        .order("created_at", { ascending: false });

      setOrders(data || []);
      setLoading(false);
    };
    fetchOrders();
  }, []);

  const viewOrder = async (order: Order) => {
    setSelectedOrder(order);
    const { data } = await supabase.from("order_items").select("*").eq("order_id", order.id);
    setOrderItems(data || []);
  };

  const updateStatus = async (orderId: string, status: string) => {
    const { error } = await supabase.from("orders").update({ status }).eq("id", orderId);
    if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); return; }
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
    if (selectedOrder?.id === orderId) setSelectedOrder(prev => prev ? { ...prev, status } : null);
    toast({ title: "Estado actualizado" });

    // Send push notification (fire & forget)
    supabase.functions.invoke("send-push-notification", {
      body: { order_id: orderId, new_status: status },
    }).then(({ error: pushErr }) => {
      if (pushErr) console.warn("Push notification failed:", pushErr);
    });
  };

  const filtered = filterStatus === "all" ? orders : orders.filter(o => o.status === filterStatus);

  const formatDate = (d: string) => {
    const date = new Date(d);
    return date.toLocaleDateString("es-MX", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
  };

  return (
    <OwnerLayout title="Pedidos" subtitle="Gestiona los pedidos de tus clientes">
      {/* Filter */}
      <div className="flex items-center gap-3 mb-6 flex-wrap">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Filtrar estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="pending">Pendientes</SelectItem>
            <SelectItem value="confirmed">Confirmados</SelectItem>
            <SelectItem value="preparing">Preparando</SelectItem>
            <SelectItem value="ready">Listos</SelectItem>
            <SelectItem value="on_the_way">En camino</SelectItem>
            <SelectItem value="delivered">Entregados</SelectItem>
            <SelectItem value="cancelled">Cancelados</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-sm text-muted-foreground">{filtered.length} pedido(s)</span>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground">No hay pedidos {filterStatus !== "all" ? "con este estado" : "aún"}</div>
      ) : (
        <div className="space-y-3">
          {filtered.map(order => {
            const sc = statusConfig[order.status] || statusConfig.pending;
            const Icon = sc.icon;
            return (
              <Card key={order.id} className="hover:shadow-soft transition-shadow cursor-pointer" onClick={() => viewOrder(order)}>
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold font-sans text-sm">#{order.order_number}</span>
                      <Badge variant="outline" className={sc.color}>
                        <Icon className="w-3 h-3 mr-1" />{sc.label}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{order.customer_name} · {order.customer_phone}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(order.created_at)}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-lg font-bold text-primary">${order.total}</p>
                    <Eye className="w-4 h-4 text-muted-foreground ml-auto mt-1" />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Order Detail Dialog */}
      <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-sans">Pedido #{selectedOrder?.order_number}</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-5">
              {/* Status update */}
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium">Estado:</span>
                <Select value={selectedOrder.status} onValueChange={v => updateStatus(selectedOrder.id, v)}>
                  <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pendiente</SelectItem>
                    <SelectItem value="confirmed">Confirmado</SelectItem>
                    <SelectItem value="preparing">Preparando</SelectItem>
                    <SelectItem value="ready">Listo</SelectItem>
                    <SelectItem value="on_the_way">En camino</SelectItem>
                    <SelectItem value="delivered">Entregado</SelectItem>
                    <SelectItem value="cancelled">Cancelado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Customer */}
              <div className="p-4 rounded-lg bg-muted/50 space-y-1.5">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Cliente</p>
                <p className="text-sm font-medium">{selectedOrder.customer_name}</p>
                <p className="text-sm text-muted-foreground">{selectedOrder.customer_phone}</p>
                {selectedOrder.customer_email && <p className="text-sm text-muted-foreground">{selectedOrder.customer_email}</p>}
                {selectedOrder.customer_address && <p className="text-sm text-muted-foreground">{selectedOrder.customer_address}</p>}
              </div>

              {/* Items */}
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Productos</p>
                <div className="space-y-2">
                  {orderItems.map(item => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span>{item.quantity}x {item.product_name}</span>
                      <span className="font-medium">${item.subtotal}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Delivery & payment */}
              <div className="flex gap-4 text-sm">
                {selectedOrder.delivery_types && (
                  <div><span className="text-muted-foreground">Envío:</span> <span className="font-medium">{selectedOrder.delivery_types.name}</span></div>
                )}
                {selectedOrder.payment_methods && (
                  <div><span className="text-muted-foreground">Pago:</span> <span className="font-medium">{selectedOrder.payment_methods.name}</span></div>
                )}
              </div>

              {selectedOrder.notes && (
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">Notas</p>
                  <p className="text-sm">{selectedOrder.notes}</p>
                </div>
              )}

              {/* Totals */}
              <div className="border-t pt-3 space-y-1">
                <div className="flex justify-between text-sm text-muted-foreground"><span>Subtotal</span><span>${selectedOrder.subtotal}</span></div>
                {selectedOrder.delivery_fee > 0 && <div className="flex justify-between text-sm text-muted-foreground"><span>Envío</span><span>${selectedOrder.delivery_fee}</span></div>}
                <div className="flex justify-between text-base font-bold"><span>Total</span><span className="text-primary">${selectedOrder.total}</span></div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </OwnerLayout>
  );
};

export default OwnerOrders;
