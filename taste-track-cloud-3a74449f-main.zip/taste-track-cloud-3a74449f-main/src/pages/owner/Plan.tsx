import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import OwnerLayout from "@/components/OwnerLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Package, Receipt, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react";

const PLAN_BASE_PRICE = 299;
const INCLUDED_ORDERS = 300;
const EXTRA_ORDER_PRICE = 1;

const Plan = () => {
  const [orderCount, setOrderCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [restaurantId, setRestaurantId] = useState<string | null>(null);
  const [currentMonth, setCurrentMonth] = useState("");

  useEffect(() => {
    const load = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return;

      const { data: rest } = await supabase
        .from("restaurants")
        .select("id")
        .eq("owner_id", session.user.id)
        .limit(1)
        .maybeSingle();

      if (!rest) return;
      setRestaurantId(rest.id);

      // Get current month range
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59).toISOString();
      
      setCurrentMonth(now.toLocaleDateString("es-MX", { month: "long", year: "numeric" }));

      const { count } = await supabase
        .from("orders")
        .select("id", { count: "exact", head: true })
        .eq("restaurant_id", rest.id)
        .gte("created_at", startOfMonth)
        .lte("created_at", endOfMonth);

      setOrderCount(count || 0);
      setLoading(false);
    };
    load();
  }, []);

  const remaining = Math.max(0, INCLUDED_ORDERS - orderCount);
  const extraOrders = Math.max(0, orderCount - INCLUDED_ORDERS);
  const extraCost = extraOrders * EXTRA_ORDER_PRICE;
  const totalInvoice = PLAN_BASE_PRICE + extraCost;
  const usagePercent = Math.min(100, (orderCount / INCLUDED_ORDERS) * 100);
  const isOverLimit = orderCount > INCLUDED_ORDERS;

  return (
    <OwnerLayout title="Mi Plan" subtitle="Gestión de tu suscripción y uso de pedidos">
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
        </div>
      ) : (
        <div className="space-y-6 max-w-3xl">
          {/* Plan header */}
          <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Package className="w-5 h-5 text-primary" />
                    Plan Menu365
                  </CardTitle>
                  <CardDescription className="mt-1">
                    {currentMonth.charAt(0).toUpperCase() + currentMonth.slice(1)}
                  </CardDescription>
                </div>
                <Badge variant={isOverLimit ? "destructive" : "default"} className="text-sm px-3 py-1">
                  ${PLAN_BASE_PRICE} MXN / mes
                </Badge>
              </div>
            </CardHeader>
          </Card>

          {/* Usage stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <TrendingUp className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{orderCount}</p>
                    <p className="text-xs text-muted-foreground">Pedidos este mes</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${remaining > 0 ? "bg-green-500/10" : "bg-destructive/10"}`}>
                    {remaining > 0 ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-destructive" />
                    )}
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{remaining}</p>
                    <p className="text-xs text-muted-foreground">Pedidos restantes</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${extraOrders > 0 ? "bg-amber-500/10" : "bg-muted"}`}>
                    <Receipt className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{extraOrders}</p>
                    <p className="text-xs text-muted-foreground">Pedidos extra</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Progress bar */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Uso del plan</CardTitle>
              <CardDescription>
                {isOverLimit
                  ? `Has superado tu límite por ${extraOrders} pedido${extraOrders > 1 ? "s" : ""}. Se cobrará $${EXTRA_ORDER_PRICE} MXN por cada pedido extra.`
                  : `Te restan ${remaining} pedido${remaining !== 1 ? "s" : ""} incluidos en tu plan este mes.`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{orderCount} de {INCLUDED_ORDERS} pedidos</span>
                  <span className="font-medium">{Math.round(usagePercent)}%</span>
                </div>
                <Progress value={usagePercent} className={isOverLimit ? "[&>div]:bg-destructive" : ""} />
              </div>
            </CardContent>
          </Card>

          {/* Invoice */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Receipt className="w-4 h-4" />
                Factura del mes — {currentMonth.charAt(0).toUpperCase() + currentMonth.slice(1)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Plan base ({INCLUDED_ORDERS} pedidos incluidos)</span>
                  <span className="font-medium">${PLAN_BASE_PRICE.toFixed(2)} MXN</span>
                </div>
                {extraOrders > 0 && (
                  <div className="flex justify-between text-sm text-amber-600">
                    <span>Pedidos extra ({extraOrders} × ${EXTRA_ORDER_PRICE} MXN)</span>
                    <span className="font-medium">+ ${extraCost.toFixed(2)} MXN</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between text-base font-bold">
                  <span>Total a pagar</span>
                  <span>${totalInvoice.toFixed(2)} MXN</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {isOverLimit && (
            <Card className="border-amber-500/30 bg-amber-50/50 dark:bg-amber-950/20">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-sm">Has superado los {INCLUDED_ORDERS} pedidos incluidos</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      A partir del pedido #{INCLUDED_ORDERS + 1}, se aplica un cargo adicional de ${EXTRA_ORDER_PRICE} MXN por cada pedido extra. 
                      Actualmente llevas {extraOrders} pedido{extraOrders > 1 ? "s" : ""} extra, lo que suma ${extraCost.toFixed(2)} MXN adicionales a tu factura.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </OwnerLayout>
  );
};

export default Plan;
