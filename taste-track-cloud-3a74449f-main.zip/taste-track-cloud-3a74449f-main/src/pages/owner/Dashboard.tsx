import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ShoppingBag, Tag, Truck, CreditCard, ChevronRight, Plus, Eye, Settings, Store,
  DollarSign, ClipboardList, CalendarDays, Calendar,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import OwnerLayout from "@/components/OwnerLayout";

const OwnerDashboard = () => {
  const [stats, setStats] = useState({ products: 0, categories: 0, delivery: 0, payments: 0 });
  const [incomeStats, setIncomeStats] = useState({ totalOrders: 0, todayIncome: 0, weekIncome: 0, monthIncome: 0, todayOrders: 0, weekOrders: 0, monthOrders: 0 });
  const [restaurant, setRestaurant] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) { navigate("/auth"); return; }

      const { data: rest } = await supabase.from("restaurants").select("*").eq("owner_id", session.user.id).limit(1).maybeSingle();
      setRestaurant(rest);

      if (rest) {
        const now = new Date();
        const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
        const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay()).toISOString();
        const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

        const [p, c, d, pm, allOrders, todayOrders, weekOrders, monthOrders] = await Promise.all([
          supabase.from("products").select("id", { count: "exact", head: true }).eq("restaurant_id", rest.id),
          supabase.from("categories").select("id", { count: "exact", head: true }).eq("restaurant_id", rest.id),
          supabase.from("delivery_types").select("id", { count: "exact", head: true }).eq("restaurant_id", rest.id),
          supabase.from("payment_methods").select("id", { count: "exact", head: true }).eq("restaurant_id", rest.id),
          supabase.from("orders").select("id", { count: "exact", head: true }).eq("restaurant_id", rest.id).neq("status", "cancelled"),
          supabase.from("orders").select("total").eq("restaurant_id", rest.id).neq("status", "cancelled").gte("created_at", todayStart),
          supabase.from("orders").select("total").eq("restaurant_id", rest.id).neq("status", "cancelled").gte("created_at", weekStart),
          supabase.from("orders").select("total").eq("restaurant_id", rest.id).neq("status", "cancelled").gte("created_at", monthStart),
        ]);
        setStats({ products: p.count || 0, categories: c.count || 0, delivery: d.count || 0, payments: pm.count || 0 });

        const sumTotal = (data: any[] | null) => (data || []).reduce((s: number, o: any) => s + Number(o.total || 0), 0);
        setIncomeStats({
          totalOrders: allOrders.count || 0,
          todayIncome: sumTotal(todayOrders.data),
          todayOrders: todayOrders.data?.length || 0,
          weekIncome: sumTotal(weekOrders.data),
          weekOrders: weekOrders.data?.length || 0,
          monthIncome: sumTotal(monthOrders.data),
          monthOrders: monthOrders.data?.length || 0,
        });
      }
      setLoading(false);
    };
    load();
  }, [navigate]);

  if (loading) return <OwnerLayout title="Dashboard"><div className="flex items-center justify-center h-64"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" /></div></OwnerLayout>;

  if (!restaurant) {
    return (
      <OwnerLayout title="¡Bienvenido!" subtitle="Configura tu restaurante para empezar">
        <Card className="max-w-lg mx-auto mt-8">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-5">
              <Store className="w-8 h-8 text-primary-foreground" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Crea tu restaurante</h2>
            <p className="text-muted-foreground mb-6">Para empezar a usar Menu365, primero configura la información de tu negocio.</p>
            <Button asChild size="lg" className="bg-gradient-to-r from-primary to-accent text-primary-foreground">
              <Link to="/owner/settings"><Settings className="w-4 h-4 mr-2" /> Configurar ahora</Link>
            </Button>
          </CardContent>
        </Card>
      </OwnerLayout>
    );
  }

  const menuCards = [
    { icon: ShoppingBag, label: "Productos", count: stats.products, href: "/owner/products", color: "from-primary to-accent" },
    { icon: Tag, label: "Categorías", count: stats.categories, href: "/owner/categories", color: "from-accent to-primary" },
    { icon: Truck, label: "Envío", count: stats.delivery, href: "/owner/delivery", color: "from-primary to-warm-amber" },
    { icon: CreditCard, label: "Pagos", count: stats.payments, href: "/owner/payments", color: "from-warm-amber to-primary" },
  ];

  const incomeCards = [
    { icon: DollarSign, label: "Hoy", income: incomeStats.todayIncome, orders: incomeStats.todayOrders, color: "from-green-500 to-emerald-600" },
    { icon: CalendarDays, label: "Esta semana", income: incomeStats.weekIncome, orders: incomeStats.weekOrders, color: "from-blue-500 to-cyan-600" },
    { icon: Calendar, label: "Este mes", income: incomeStats.monthIncome, orders: incomeStats.monthOrders, color: "from-purple-500 to-violet-600" },
    { icon: ClipboardList, label: "Total pedidos", income: null, orders: incomeStats.totalOrders, color: "from-primary to-accent" },
  ];

  return (
    <OwnerLayout
      title="Dashboard"
      subtitle={`Bienvenido · ${restaurant.name}`}
      actions={
        <div className="flex items-center gap-2">
          <Button asChild variant="outline" size="sm">
            <Link to={`/menu/${restaurant.slug}`}><Eye className="w-4 h-4 mr-1.5" /> Ver menú</Link>
          </Button>
          <Button asChild size="sm" className="bg-gradient-to-r from-primary to-accent text-primary-foreground">
            <Link to="/owner/products"><Plus className="w-4 h-4 mr-1.5" /> Producto</Link>
          </Button>
        </div>
      }
    >
      {/* Income Stats */}
      <div className="mb-6">
        <h3 className="text-xs font-semibold tracking-[0.2em] uppercase text-muted-foreground mb-3">Ingresos</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {incomeCards.map((c) => (
            <Card key={c.label} className="overflow-hidden">
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${c.color} flex items-center justify-center`}>
                    <c.icon className="w-5 h-5 text-white" />
                  </div>
                </div>
                {c.income !== null ? (
                  <>
                    <p className="text-2xl font-bold">${c.income.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">{c.orders} pedido{c.orders !== 1 ? "s" : ""} · {c.label}</p>
                  </>
                ) : (
                  <>
                    <p className="text-2xl font-bold">{c.orders}</p>
                    <p className="text-sm text-muted-foreground">{c.label}</p>
                  </>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Menu Stats grid */}
      <div className="mb-6">
        <h3 className="text-xs font-semibold tracking-[0.2em] uppercase text-muted-foreground mb-3">Tu Menú</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {menuCards.map((c) => (
            <Link key={c.href} to={c.href} className="group">
              <Card className="hover:shadow-elevated transition-all duration-300 hover:-translate-y-0.5 h-full">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${c.color} flex items-center justify-center`}>
                      <c.icon className="w-5 h-5 text-primary-foreground" />
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                  <p className="text-3xl font-bold">{c.count}</p>
                  <p className="text-sm text-muted-foreground">{c.label}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid md:grid-cols-2 gap-4">
        <Link to="/owner/orders">
          <Card className="bg-gradient-to-br from-primary to-accent text-primary-foreground hover:shadow-elevated transition-all duration-300 hover:-translate-y-0.5 cursor-pointer">
            <CardContent className="p-6">
              <ClipboardList className="w-8 h-8 mb-3 opacity-80" />
              <h3 className="text-lg font-bold mb-1">Pedidos</h3>
              <p className="text-primary-foreground/70 text-sm mb-4">Revisa y gestiona los pedidos de tus clientes en tiempo real.</p>
              <Button size="sm" className="bg-card text-card-foreground hover:bg-card/90">
                Ver pedidos
              </Button>
            </CardContent>
          </Card>
        </Link>

        <Card>
          <CardContent className="p-6">
            <Settings className="w-8 h-8 mb-3 text-muted-foreground" />
            <h3 className="text-lg font-bold mb-1">Configuración</h3>
            <p className="text-muted-foreground text-sm mb-4">Edita la info de tu restaurante, logo y datos de contacto.</p>
            <Button asChild variant="outline" size="sm">
              <Link to="/owner/settings">Configurar</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </OwnerLayout>
  );
};

export default OwnerDashboard;