import React, { useEffect, useState, useRef } from "react";
import { getUserFriendlyError } from "@/lib/error-utils";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Pencil, Trash2, ShoppingBag, Search, Upload, X, Sparkles, GripVertical, ArrowUp, ArrowDown, Filter } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import OwnerLayout from "@/components/OwnerLayout";
import ProductOptionsManager from "@/components/ProductOptionsManager";
import AIMenuImporter from "@/components/AIMenuImporter";

const Products = () => {
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [restaurant, setRestaurant] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [aiImportOpen, setAiImportOpen] = useState(false);
  const [generatingAiImage, setGeneratingAiImage] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [search, setSearch] = useState("");
  const [uploading, setUploading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [newCategoryName, setNewCategoryName] = useState("");
  const [creatingCategory, setCreatingCategory] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState({ name: "", description: "", price: "", category_id: "", image_url: "", is_featured: false, is_upsell: false });
  const [aiPromptDetails, setAiPromptDetails] = useState("");
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) { navigate("/auth"); return; }
    const { data: rest } = await supabase.from("restaurants").select("*").eq("owner_id", session.user.id).limit(1).maybeSingle();
    if (!rest) { toast({ title: "Sin restaurante", description: "Primero crea tu restaurante.", variant: "destructive" }); navigate("/owner"); return; }
    setRestaurant(rest);
    const [{ data: prods }, { data: cats }] = await Promise.all([
      supabase.from("products").select("*, categories(name)").eq("restaurant_id", rest.id).order("sort_order", { ascending: true, nullsFirst: false }).order("created_at", { ascending: true }),
      supabase.from("categories").select("*").eq("restaurant_id", rest.id).order("name"),
    ]);
    setProducts(prods || []); setCategories(cats || []); setLoading(false);
    setSelectedIds(new Set());
  };

  const resetForm = () => { setForm({ name: "", description: "", price: "", category_id: "", image_url: "", is_featured: false, is_upsell: false }); setImagePreview(null); setAiPromptDetails(""); };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast({ title: "Error", description: "Solo imágenes.", variant: "destructive" }); return; }
    if (file.size > 5 * 1024 * 1024) { toast({ title: "Error", description: "Máximo 5MB.", variant: "destructive" }); return; }
    setUploading(true);
    const ext = file.name.split(".").pop();
    const fileName = `${restaurant.id}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("product-images").upload(fileName, file);
    if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); setUploading(false); return; }
    const { data: urlData } = supabase.storage.from("product-images").getPublicUrl(fileName);
    setForm((prev) => ({ ...prev, image_url: urlData.publicUrl })); setImagePreview(urlData.publicUrl); setUploading(false);
  };

  const removeImage = () => { setForm((prev) => ({ ...prev, image_url: "" })); setImagePreview(null); if (fileInputRef.current) fileInputRef.current.value = ""; };

  const handleGenerateAiImage = async () => {
    if (!form.name.trim()) { toast({ title: "Error", description: "Escribe el nombre del producto primero.", variant: "destructive" }); return; }
    setGeneratingAiImage(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-product-image`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ productName: form.name, restaurantId: restaurant.id, categoryName: categories.find(c => c.id === form.category_id)?.name || null, customDetails: aiPromptDetails.trim() || null }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Error al generar imagen");
      setForm((prev) => ({ ...prev, image_url: data.imageUrl }));
      setImagePreview(data.imageUrl);
      toast({ title: "Imagen generada con IA" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message || "No se pudo generar la imagen.", variant: "destructive" });
    } finally {
      setGeneratingAiImage(false);
    }
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.price) { toast({ title: "Error", description: "Nombre y precio son obligatorios.", variant: "destructive" }); return; }
    const payload: any = { name: form.name, description: form.description || null, price: parseFloat(form.price), category_id: form.category_id || null, image_url: form.image_url || null, is_featured: form.is_featured, is_upsell: form.is_upsell, restaurant_id: restaurant.id };
    if (editingProduct) {
      // Don't change sort_order on edit - preserve original position
      const { error } = await supabase.from("products").update(payload).eq("id", editingProduct.id);
      if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); return; }
      toast({ title: "Producto actualizado" });
    } else {
      const maxSort = products.length > 0 ? Math.max(...products.map(p => p.sort_order || 0)) + 1 : 0;
      const { error } = await supabase.from("products").insert({ ...payload, sort_order: maxSort });
      if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); return; }
      toast({ title: "Producto creado" });
    }
    setDialogOpen(false); setEditingProduct(null); resetForm(); loadData();
  };

  const handleEdit = (p: any) => { setEditingProduct(p); setForm({ name: p.name, description: p.description || "", price: String(p.price), category_id: p.category_id || "", image_url: p.image_url || "", is_featured: p.is_featured || false, is_upsell: p.is_upsell || false }); setImagePreview(p.image_url || null); setDialogOpen(true); };
  const handleDelete = async (id: string) => { await supabase.from("products").delete().eq("id", id); toast({ title: "Producto eliminado" }); loadData(); };
  const toggleAvailable = async (id: string, current: boolean) => {
    await supabase.from("products").update({ is_available: !current }).eq("id", id);
    setProducts(prev => prev.map(p => p.id === id ? { ...p, is_available: !current } : p));
  };

  // Bulk delete
  const handleBulkDelete = async () => {
    const ids = Array.from(selectedIds);
    for (const id of ids) {
      await supabase.from("products").delete().eq("id", id);
    }
    toast({ title: `${ids.length} producto${ids.length !== 1 ? 's' : ''} eliminado${ids.length !== 1 ? 's' : ''}` });
    setSelectedIds(new Set());
    setBulkDeleteOpen(false);
    loadData();
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map(p => p.id)));
    }
  };

  const moveProduct = async (fromIndex: number, toIndex: number) => {
    if (toIndex < 0 || toIndex >= products.length) return;
    const updated = [...products];
    const [moved] = updated.splice(fromIndex, 1);
    updated.splice(toIndex, 0, moved);
    setProducts(updated);

    const updates = updated.map((p, i) => ({ id: p.id, sort_order: i }));
    for (const u of updates) {
      await supabase.from("products").update({ sort_order: u.sort_order }).eq("id", u.id);
    }
  };

  const handleDragStart = (index: number) => { setDragIndex(index); };
  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (dragIndex === null || dragIndex === index) return;
    moveProduct(dragIndex, index);
    setDragIndex(index);
  };
  const handleDragEnd = () => { setDragIndex(null); };

  const filteredByCategory = filterCategory === "all" 
    ? products 
    : filterCategory === "none" 
      ? products.filter(p => !p.category_id) 
      : products.filter(p => p.category_id === filterCategory);
  const filtered = search ? filteredByCategory.filter((p) => p.name.toLowerCase().includes(search.toLowerCase())) : filteredByCategory;
  const isSearching = search.length > 0;

  // Group products by category for display
  const groupedProducts = () => {
    if (filterCategory !== "all" || isSearching) return null; // Don't group when filtering or searching
    const groups: { category: any; products: any[] }[] = [];
    const catMap = new Map<string, any[]>();
    const uncategorized: any[] = [];
    
    for (const p of filtered) {
      if (p.category_id) {
        if (!catMap.has(p.category_id)) catMap.set(p.category_id, []);
        catMap.get(p.category_id)!.push(p);
      } else {
        uncategorized.push(p);
      }
    }
    
    // Sort categories by their sort_order
    const sortedCats = categories.filter(c => catMap.has(c.id)).sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
    for (const cat of sortedCats) {
      groups.push({ category: cat, products: catMap.get(cat.id)! });
    }
    if (uncategorized.length > 0) {
      groups.push({ category: { id: "none", name: "Sin categoría", icon: null }, products: uncategorized });
    }
    return groups;
  };

  const groups = groupedProducts();

  const addButton = (
    <div className="flex items-center gap-2">
      <Button size="sm" variant="outline" onClick={() => setAiImportOpen(true)}>
        <Sparkles className="w-4 h-4 mr-1.5" /> IA
      </Button>
      <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) { setEditingProduct(null); resetForm(); } }}>
        <DialogTrigger asChild>
          <Button size="sm" className="bg-gradient-to-r from-primary to-accent text-primary-foreground"><Plus className="w-4 h-4 mr-1.5" /> Producto</Button>
        </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editingProduct ? "Editar Producto" : "Nuevo Producto"}</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div><Label>Nombre *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ej: Hamburguesa clásica" /></div>
          <div><Label>Descripción</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Descripción del producto" /></div>
          <div><Label>Precio *</Label><Input type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="0.00" /></div>
          <div>
            <Label>Categoría</Label>
            <Select value={form.category_id} onValueChange={(v) => setForm({ ...form, category_id: v === "__none" ? "" : v })}>
              <SelectTrigger><SelectValue placeholder="Sin categoría" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__none">Sin categoría</SelectItem>
                {categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            {/* Inline new category */}
            <div className="flex items-center gap-2 mt-2">
              <Input
                value={newCategoryName}
                onChange={e => setNewCategoryName(e.target.value)}
                placeholder="Nueva categoría..."
                className="flex-1 h-8 text-sm"
              />
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={!newCategoryName.trim() || creatingCategory}
                onClick={async () => {
                  if (!newCategoryName.trim() || !restaurant) return;
                  setCreatingCategory(true);
                  const { data, error } = await supabase.from("categories").insert({
                    name: newCategoryName.trim(),
                    restaurant_id: restaurant.id,
                  }).select().single();
                  if (error) {
                    toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" });
                  } else if (data) {
                    setCategories(prev => [...prev, data].sort((a, b) => a.name.localeCompare(b.name)));
                    setForm(prev => ({ ...prev, category_id: data.id }));
                    setNewCategoryName("");
                    toast({ title: "Categoría creada" });
                  }
                  setCreatingCategory(false);
                }}
                className="h-8 text-xs"
              >
                {creatingCategory ? "..." : <><Plus className="w-3 h-3 mr-1" />Crear</>}
              </Button>
            </div>
          </div>
          <div>
            <Label>Imagen</Label>
            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageUpload} className="hidden" />
            {imagePreview || form.image_url ? (
              <div className="relative mt-2 w-full h-40 rounded-xl overflow-hidden border border-border">
                <img src={imagePreview || form.image_url} alt="Preview" className="w-full h-full object-cover" />
                <button onClick={removeImage} className="absolute top-2 right-2 w-7 h-7 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button>
              </div>
            ) : (
              <div className="mt-2 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => fileInputRef.current?.click()} disabled={uploading || generatingAiImage} className="h-32 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-2 text-muted-foreground hover:border-primary hover:text-primary transition-colors">
                    {uploading ? <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" /> : <><Upload className="w-6 h-6" /><span className="text-xs">Subir imagen</span></>}
                  </button>
                  <button type="button" onClick={handleGenerateAiImage} disabled={generatingAiImage || uploading || !form.name.trim()} className="h-32 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-2 text-muted-foreground hover:border-accent hover:text-accent transition-colors disabled:opacity-50">
                    {generatingAiImage ? <><div className="animate-spin w-6 h-6 border-2 border-accent border-t-transparent rounded-full" /><span className="text-xs">Generando...</span></> : <><Sparkles className="w-6 h-6" /><span className="text-xs">Generar con IA</span></>}
                  </button>
                </div>
                <Input
                  value={aiPromptDetails}
                  onChange={(e) => setAiPromptDetails(e.target.value)}
                  placeholder="Detalles para IA (ej: fondo oscuro, estilo rústico, con guarnición...)"
                  className="text-xs"
                />
              </div>
            )}
          </div>
          <div className="flex items-center gap-2"><Switch checked={form.is_featured} onCheckedChange={(v) => setForm({ ...form, is_featured: v })} /><Label>Destacado</Label></div>
          <div className="flex items-center gap-2"><Switch checked={form.is_upsell} onCheckedChange={(v) => setForm({ ...form, is_upsell: v })} /><Label>Sugerir al finalizar pedido</Label></div>
          {editingProduct && restaurant && (
            <ProductOptionsManager productId={editingProduct.id} restaurantId={restaurant.id} />
          )}
          <Button onClick={handleSave} className="w-full">Guardar</Button>
        </div>
      </DialogContent>
      </Dialog>
    </div>
  );

  if (loading) return <OwnerLayout title="Productos" actions={addButton}><div className="flex items-center justify-center h-64"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" /></div></OwnerLayout>;

  return (
    <OwnerLayout title="Productos" subtitle={`${products.length} producto${products.length !== 1 ? 's' : ''}`} actions={addButton}>
      <div className="mb-4 flex items-center gap-3 flex-wrap">
        <div className="relative max-w-sm flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar productos..." className="pl-9" />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-1.5 text-muted-foreground" />
            <SelectValue placeholder="Categoría" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas las categorías</SelectItem>
            <SelectItem value="none">Sin categoría</SelectItem>
            {categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        {selectedIds.size > 0 && (
          <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 className="w-4 h-4 mr-1.5" /> Eliminar ({selectedIds.size})
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>¿Eliminar {selectedIds.size} producto{selectedIds.size !== 1 ? 's' : ''}?</AlertDialogTitle>
                <AlertDialogDescription>Esta acción no se puede deshacer.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleBulkDelete}>Eliminar</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>

      {filtered.length === 0 ? (
        <Card className="text-center py-12"><CardContent>
          <ShoppingBag className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">{search ? "Sin resultados" : "Sin productos"}</h3>
          <p className="text-muted-foreground mb-4">{search ? "No se encontraron productos." : "Crea tu primer producto."}</p>
          {!search && <Button onClick={() => setDialogOpen(true)} className="bg-gradient-to-r from-primary to-accent text-primary-foreground"><Plus className="w-4 h-4 mr-2" /> Crear Producto</Button>}
        </CardContent></Card>
      ) : (
        <>
          {isSearching && (
            <p className="text-xs text-muted-foreground mb-2">El orden se desactiva durante la búsqueda</p>
          )}

          {/* Desktop table */}
          {(() => {
            const renderProductRow = (p: any, globalIndex: number) => (
              <TableRow
                key={p.id}
                draggable={!isSearching}
                onDragStart={() => !isSearching && handleDragStart(globalIndex)}
                onDragOver={(e) => !isSearching && handleDragOver(e, globalIndex)}
                onDragEnd={handleDragEnd}
                className={`${dragIndex === globalIndex ? 'opacity-50 bg-accent' : ''} ${!isSearching ? 'cursor-grab active:cursor-grabbing' : ''}`}
              >
                <TableCell className="w-10 px-2">
                  <Checkbox checked={selectedIds.has(p.id)} onCheckedChange={() => toggleSelect(p.id)} />
                </TableCell>
                {!isSearching && (
                  <TableCell className="w-10 px-2">
                    <div className="flex flex-col items-center gap-0.5">
                      <button onClick={() => moveProduct(globalIndex, globalIndex - 1)} disabled={globalIndex === 0} className="text-muted-foreground hover:text-foreground disabled:opacity-30 p-0.5"><ArrowUp className="w-3.5 h-3.5" /></button>
                      <GripVertical className="w-4 h-4 text-muted-foreground" />
                      <button onClick={() => moveProduct(globalIndex, globalIndex + 1)} disabled={globalIndex === products.length - 1} className="text-muted-foreground hover:text-foreground disabled:opacity-30 p-0.5"><ArrowDown className="w-3.5 h-3.5" /></button>
                    </div>
                  </TableCell>
                )}
                <TableCell>
                  <div className="flex items-center gap-3">
                    {p.image_url && <img src={p.image_url} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />}
                    <div>
                      <div className="font-medium">{p.name}</div>
                      {p.is_featured && <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full">Destacado</span>}
                      {p.is_upsell && <span className="text-[10px] bg-accent/10 text-accent-foreground px-2 py-0.5 rounded-full ml-1">Sugerido</span>}
                    </div>
                  </div>
                </TableCell>
                {!groups && <TableCell className="text-muted-foreground">{p.categories?.name || "—"}</TableCell>}
                <TableCell className="font-semibold">${p.price.toFixed(2)}</TableCell>
                <TableCell><Switch checked={p.is_available} onCheckedChange={() => toggleAvailable(p.id, p.is_available)} /></TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(p)}><Pencil className="w-4 h-4" /></Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="text-destructive"><Trash2 className="w-4 h-4" /></Button></AlertDialogTrigger>
                      <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>¿Eliminar producto?</AlertDialogTitle><AlertDialogDescription>No se puede deshacer.</AlertDialogDescription></AlertDialogHeader>
                      <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => handleDelete(p.id)}>Eliminar</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
                    </AlertDialog>
                  </div>
                </TableCell>
              </TableRow>
            );

            const renderMobileCard = (p: any, globalIndex: number) => (
              <Card
                key={p.id}
                draggable={!isSearching}
                onDragStart={() => !isSearching && handleDragStart(globalIndex)}
                onDragOver={(e) => !isSearching && handleDragOver(e, globalIndex)}
                onDragEnd={handleDragEnd}
                className={`${dragIndex === globalIndex ? 'opacity-50 bg-accent' : ''} ${!isSearching ? 'cursor-grab active:cursor-grabbing' : ''}`}
              >
                <CardContent className="p-3">
                  <div className="flex items-center gap-3">
                    <Checkbox checked={selectedIds.has(p.id)} onCheckedChange={() => toggleSelect(p.id)} className="shrink-0" />
                    {!isSearching && (
                      <div className="flex flex-col items-center gap-0.5 shrink-0">
                        <button onClick={() => moveProduct(globalIndex, globalIndex - 1)} disabled={globalIndex === 0} className="text-muted-foreground hover:text-foreground disabled:opacity-30 p-0.5"><ArrowUp className="w-3.5 h-3.5" /></button>
                        <GripVertical className="w-4 h-4 text-muted-foreground" />
                        <button onClick={() => moveProduct(globalIndex, globalIndex + 1)} disabled={globalIndex === products.length - 1} className="text-muted-foreground hover:text-foreground disabled:opacity-30 p-0.5"><ArrowDown className="w-3.5 h-3.5" /></button>
                      </div>
                    )}
                    {p.image_url && <img src={p.image_url} alt={p.name} className="w-14 h-14 rounded-lg object-cover shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="font-medium truncate">{p.name}</p>
                          {!groups && <p className="text-xs text-muted-foreground truncate">{p.categories?.name || "Sin categoría"}</p>}
                          {p.is_featured && <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full">Destacado</span>}
                          {p.is_upsell && <span className="text-[10px] bg-accent/10 text-accent-foreground px-2 py-0.5 rounded-full">Sugerido</span>}
                        </div>
                        <p className="font-semibold text-sm shrink-0">${p.price.toFixed(2)}</p>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <Switch checked={p.is_available} onCheckedChange={() => toggleAvailable(p.id, p.is_available)} />
                        <div className="flex items-center gap-0.5">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleEdit(p)}><Pencil className="w-3.5 h-3.5" /></Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="w-3.5 h-3.5" /></Button></AlertDialogTrigger>
                            <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>¿Eliminar producto?</AlertDialogTitle><AlertDialogDescription>No se puede deshacer.</AlertDialogDescription></AlertDialogHeader>
                            <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => handleDelete(p.id)}>Eliminar</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );

            return (
              <>
                <Card className="hidden md:block">
                  <Table>
                    <TableHeader><TableRow>
                      <TableHead className="w-10">
                        <Checkbox checked={filtered.length > 0 && selectedIds.size === filtered.length} onCheckedChange={toggleSelectAll} />
                      </TableHead>
                      {!isSearching && <TableHead className="w-10"></TableHead>}
                      <TableHead>Producto</TableHead>
                      {!groups && <TableHead>Categoría</TableHead>}
                      <TableHead>Precio</TableHead><TableHead>Disponible</TableHead><TableHead className="text-right">Acciones</TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                      {groups ? (
                        groups.map((g) => (
                          <React.Fragment key={`cat-${g.category.id}`}>
                            <TableRow className="bg-muted/50 hover:bg-muted/50">
                              <TableCell colSpan={6} className="py-2">
                                <span className="font-semibold text-sm">{g.category.icon} {g.category.name}</span>
                                <span className="text-xs text-muted-foreground ml-2">({g.products.length})</span>
                              </TableCell>
                            </TableRow>
                            {g.products.map((p) => renderProductRow(p, products.indexOf(p)))}
                          </React.Fragment>
                        ))
                      ) : (
                        filtered.map((p, index) => renderProductRow(p, index))
                      )}
                    </TableBody>
                  </Table>
                </Card>

                <div className="md:hidden space-y-3">
                  {filtered.length > 0 && (
                    <div className="flex items-center gap-2 px-1">
                      <Checkbox checked={filtered.length > 0 && selectedIds.size === filtered.length} onCheckedChange={toggleSelectAll} />
                      <span className="text-sm text-muted-foreground">Seleccionar todos</span>
                    </div>
                  )}
                  {groups ? (
                    groups.map((g) => (
                      <div key={`cat-m-${g.category.id}`}>
                        <div className="px-1 py-2">
                          <span className="font-semibold text-sm">{g.category.icon} {g.category.name}</span>
                          <span className="text-xs text-muted-foreground ml-2">({g.products.length})</span>
                        </div>
                        <div className="space-y-2">
                          {g.products.map((p) => renderMobileCard(p, products.indexOf(p)))}
                        </div>
                      </div>
                    ))
                  ) : (
                    filtered.map((p, index) => renderMobileCard(p, index))
                  )}
                </div>
              </>
            );
          })()}
        </>
      )}
      <AIMenuImporter
        open={aiImportOpen}
        onOpenChange={setAiImportOpen}
        categories={categories}
        restaurantId={restaurant?.id || ""}
        onImported={loadData}
      />
    </OwnerLayout>
  );
};

export default Products;
