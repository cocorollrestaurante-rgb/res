import { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Download, FileSpreadsheet, FileText, TrendingUp, ShoppingBag, Tag, DollarSign, Calendar } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import OwnerLayout from "@/components/OwnerLayout";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

type OrderWithItems = {
  id: string;
  total: number;
  subtotal: number;
  created_at: string;
  status: string;
  order_items: { product_name: string; quantity: number; subtotal: number; product_id: string | null }[];
};

type CategorySales = { name: string; total: number; count: number };
type ProductSales = { name: string; total: number; count: number };
type DailySales = { date: string; total: number; orders: number };

const COLORS = [
  "hsl(24, 95%, 53%)", "hsl(38, 92%, 50%)", "hsl(16, 85%, 57%)",
  "hsl(142, 76%, 36%)", "hsl(221, 83%, 53%)", "hsl(262, 83%, 58%)",
  "hsl(340, 75%, 55%)", "hsl(47, 100%, 50%)",
];

const OwnerReports = () => {
  const [orders, setOrders] = useState<OrderWithItems[]>([]);
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [products, setProducts] = useState<{ id: string; name: string; category_id: string | null }[]>([]);
  const [restaurant, setRestaurant] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState("month");
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) { navigate("/auth"); return; }

      const { data: rest } = await supabase
        .from("restaurants").select("*")
        .eq("owner_id", session.user.id).limit(1).maybeSingle();
      if (!rest) { setLoading(false); return; }
      setRestaurant(rest);

      const now = new Date();
      let startDate: Date;
      if (period === "week") {
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7);
      } else if (period === "month") {
        startDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
      } else if (period === "quarter") {
        startDate = new Date(now.getFullYear(), now.getMonth() - 3, now.getDate());
      } else {
        startDate = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
      }

      const [ordersRes, catsRes, prodsRes] = await Promise.all([
        supabase
          .from("orders")
          .select("id, total, subtotal, created_at, status, order_items(product_name, quantity, subtotal, product_id)")
          .eq("restaurant_id", rest.id)
          .neq("status", "cancelled")
          .gte("created_at", startDate.toISOString())
          .order("created_at", { ascending: true }),
        supabase.from("categories").select("id, name").eq("restaurant_id", rest.id),
        supabase.from("products").select("id, name, category_id").eq("restaurant_id", rest.id),
      ]);

      setOrders((ordersRes.data as any) || []);
      setCategories(catsRes.data || []);
      setProducts(prodsRes.data || []);
      setLoading(false);
    };
    load();
  }, [navigate, period]);

  const totalRevenue = useMemo(() => orders.reduce((s, o) => s + Number(o.total), 0), [orders]);
  const totalOrders = orders.length;
  const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

  // Daily sales trend
  const dailySales: DailySales[] = useMemo(() => {
    const map: Record<string, { total: number; orders: number }> = {};
    orders.forEach((o) => {
      const d = new Date(o.created_at).toLocaleDateString("es-MX", { day: "2-digit", month: "short" });
      if (!map[d]) map[d] = { total: 0, orders: 0 };
      map[d].total += Number(o.total);
      map[d].orders += 1;
    });
    return Object.entries(map).map(([date, v]) => ({ date, ...v }));
  }, [orders]);

  // Top products
  const topProducts: ProductSales[] = useMemo(() => {
    const map: Record<string, { total: number; count: number }> = {};
    orders.forEach((o) =>
      o.order_items.forEach((item) => {
        const k = item.product_name;
        if (!map[k]) map[k] = { total: 0, count: 0 };
        map[k].total += Number(item.subtotal);
        map[k].count += item.quantity;
      })
    );
    return Object.entries(map)
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 10);
  }, [orders]);

  // Sales by category
  const categorySales: CategorySales[] = useMemo(() => {
    const prodCatMap: Record<string, string> = {};
    products.forEach((p) => {
      const cat = categories.find((c) => c.id === p.category_id);
      prodCatMap[p.name] = cat?.name || "Sin categoría";
    });

    const map: Record<string, { total: number; count: number }> = {};
    orders.forEach((o) =>
      o.order_items.forEach((item) => {
        const catName = prodCatMap[item.product_name] || "Sin categoría";
        if (!map[catName]) map[catName] = { total: 0, count: 0 };
        map[catName].total += Number(item.subtotal);
        map[catName].count += item.quantity;
      })
    );
    return Object.entries(map)
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.total - a.total);
  }, [orders, products, categories]);

  const exportExcel = () => {
    const wb = XLSX.utils.book_new();

    // Summary
    const summaryData = [
      ["Reporte de Ventas", ""],
      ["Restaurante", restaurant?.name || ""],
      ["Período", period === "week" ? "Última semana" : period === "month" ? "Último mes" : period === "quarter" ? "Últimos 3 meses" : "Último año"],
      ["Total Ingresos", `$${totalRevenue.toFixed(2)}`],
      ["Total Pedidos", totalOrders],
      ["Ticket Promedio", `$${avgOrderValue.toFixed(2)}`],
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summaryData), "Resumen");

    // Daily
    const dailySheet = XLSX.utils.json_to_sheet(dailySales.map((d) => ({ Fecha: d.date, Ingresos: d.total, Pedidos: d.orders })));
    XLSX.utils.book_append_sheet(wb, dailySheet, "Ventas Diarias");

    // Products
    const prodSheet = XLSX.utils.json_to_sheet(topProducts.map((p) => ({ Producto: p.name, Ingresos: p.total, Unidades: p.count })));
    XLSX.utils.book_append_sheet(wb, prodSheet, "Productos");

    // Categories
    const catSheet = XLSX.utils.json_to_sheet(categorySales.map((c) => ({ Categoría: c.name, Ingresos: c.total, Unidades: c.count })));
    XLSX.utils.book_append_sheet(wb, catSheet, "Categorías");

    XLSX.writeFile(wb, `reporte-${restaurant?.name || "ventas"}-${period}.xlsx`);
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    const title = `Reporte de Ventas - ${restaurant?.name || ""}`;
    doc.setFontSize(18);
    doc.text(title, 14, 22);
    doc.setFontSize(11);
    doc.text(`Período: ${period === "week" ? "Última semana" : period === "month" ? "Último mes" : period === "quarter" ? "Últimos 3 meses" : "Último año"}`, 14, 32);
    doc.text(`Total Ingresos: $${totalRevenue.toFixed(2)} | Pedidos: ${totalOrders} | Ticket Promedio: $${avgOrderValue.toFixed(2)}`, 14, 40);

    autoTable(doc, {
      startY: 50,
      head: [["#", "Producto", "Ingresos", "Unidades"]],
      body: topProducts.map((p, i) => [i + 1, p.name, `$${p.total.toFixed(2)}`, p.count]),
      theme: "striped",
      headStyles: { fillColor: [234, 120, 36] },
    });

    const finalY = (doc as any).lastAutoTable?.finalY || 120;
    autoTable(doc, {
      startY: finalY + 10,
      head: [["Categoría", "Ingresos", "Unidades"]],
      body: categorySales.map((c) => [c.name, `$${c.total.toFixed(2)}`, c.count]),
      theme: "striped",
      headStyles: { fillColor: [234, 120, 36] },
    });

    doc.save(`reporte-${restaurant?.name || "ventas"}-${period}.pdf`);
  };

  if (loading) {
    return (
      <OwnerLayout title="Reportes">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      </OwnerLayout>
    );
  }

  const periodLabel = period === "week" ? "Última semana" : period === "month" ? "Último mes" : period === "quarter" ? "Últimos 3 meses" : "Último año";

  return (
    <OwnerLayout
      title="Reportes"
      subtitle="Análisis de ventas y rendimiento"
      actions={
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={exportExcel}>
            <FileSpreadsheet className="w-4 h-4 mr-1.5" /> Excel
          </Button>
          <Button variant="outline" size="sm" onClick={exportPDF}>
            <FileText className="w-4 h-4 mr-1.5" /> PDF
          </Button>
        </div>
      }
    >
      {/* Period selector */}
      <div className="mb-6">
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-48">
            <Calendar className="w-4 h-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">Última semana</SelectItem>
            <SelectItem value="month">Último mes</SelectItem>
            <SelectItem value="quarter">Últimos 3 meses</SelectItem>
            <SelectItem value="year">Último año</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-sm text-muted-foreground">Ingresos</span>
            </div>
            <p className="text-2xl font-bold">${totalRevenue.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground">{periodLabel}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent to-primary flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-sm text-muted-foreground">Pedidos</span>
            </div>
            <p className="text-2xl font-bold">{totalOrders}</p>
            <p className="text-xs text-muted-foreground">{periodLabel}</p>
          </CardContent>
        </Card>
        <Card className="col-span-2 lg:col-span-1">
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-warm-amber flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-sm text-muted-foreground">Ticket promedio</span>
            </div>
            <p className="text-2xl font-bold">${avgOrderValue.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground">{periodLabel}</p>
          </CardContent>
        </Card>
      </div>

      {/* Sales Trend Chart */}
      <Card className="mb-6">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold font-sans">Tendencia de ventas</CardTitle>
        </CardHeader>
        <CardContent>
          {dailySales.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={dailySales}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    fontSize: "13px",
                  }}
                  formatter={(value: number) => [`$${value.toFixed(2)}`, "Ingresos"]}
                />
                <Line type="monotone" dataKey="total" stroke="hsl(24, 95%, 53%)" strokeWidth={2.5} dot={{ fill: "hsl(24, 95%, 53%)", r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-center text-muted-foreground py-12">No hay datos para este período</p>
          )}
        </CardContent>
      </Card>

      {/* Two column: Top Products + Category Pie */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Top Products */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold font-sans">Productos más vendidos</CardTitle>
          </CardHeader>
          <CardContent>
            {topProducts.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={topProducts.slice(0, 7)} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={100} stroke="hsl(var(--muted-foreground))" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      fontSize: "13px",
                    }}
                    formatter={(value: number) => [`$${value.toFixed(2)}`, "Ingresos"]}
                  />
                  <Bar dataKey="total" fill="hsl(24, 95%, 53%)" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-center text-muted-foreground py-12">No hay datos</p>
            )}
          </CardContent>
        </Card>

        {/* Category Pie */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold font-sans">Ventas por categoría</CardTitle>
          </CardHeader>
          <CardContent>
            {categorySales.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={categorySales}
                    dataKey="total"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={{ stroke: "hsl(var(--muted-foreground))" }}
                  >
                    {categorySales.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      fontSize: "13px",
                    }}
                    formatter={(value: number) => [`$${value.toFixed(2)}`, "Ingresos"]}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-center text-muted-foreground py-12">No hay datos</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Product ranking table */}
      <Card className="mt-6">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold font-sans">Ranking de productos</CardTitle>
        </CardHeader>
        <CardContent>
          {topProducts.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 px-3 text-muted-foreground font-medium">#</th>
                    <th className="text-left py-2 px-3 text-muted-foreground font-medium">Producto</th>
                    <th className="text-right py-2 px-3 text-muted-foreground font-medium">Unidades</th>
                    <th className="text-right py-2 px-3 text-muted-foreground font-medium">Ingresos</th>
                  </tr>
                </thead>
                <tbody>
                  {topProducts.map((p, i) => (
                    <tr key={p.name} className="border-b border-border/50 last:border-0">
                      <td className="py-2.5 px-3 font-semibold text-muted-foreground">{i + 1}</td>
                      <td className="py-2.5 px-3 font-medium">{p.name}</td>
                      <td className="py-2.5 px-3 text-right">{p.count}</td>
                      <td className="py-2.5 px-3 text-right font-semibold">${p.total.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">No hay datos para este período</p>
          )}
        </CardContent>
      </Card>
    </OwnerLayout>
  );
};

export default OwnerReports;
