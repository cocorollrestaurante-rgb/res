import { useEffect, useState } from "react";
import { getUserFriendlyError } from "@/lib/error-utils";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Truck, Store, UtensilsCrossed, MapPin, DollarSign, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import OwnerLayout from "@/components/OwnerLayout";

const FIXED_DELIVERY_TYPES = [
  { name: "Domicilio", icon: <Truck className="w-6 h-6" />, description: "Entrega a domicilio del cliente" },
  { name: "Para Recoger", icon: <Store className="w-6 h-6" />, description: "El cliente recoge en el local" },
  { name: "Consumo en Mesa", icon: <UtensilsCrossed className="w-6 h-6" />, description: "El cliente consume en el restaurante" },
];

const Delivery = () => {
  const [items, setItems] = useState<any[]>([]);
  const [restaurant, setRestaurant] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [baseFee, setBaseFee] = useState(0);
  const [pricePerKm, setPricePerKm] = useState(0);
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [savingConfig, setSavingConfig] = useState(false);
  const [gettingLocation, setGettingLocation] = useState(false);
  const [deliveryFeeType, setDeliveryFeeType] = useState<"fixed" | "distance">("distance");
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) { navigate("/auth"); return; }
    const { data: rest } = await supabase.from("restaurants").select("*").eq("owner_id", session.user.id).limit(1).maybeSingle();
    if (!rest) { navigate("/owner"); return; }
    setRestaurant(rest);
    setBaseFee((rest as any).delivery_base_fee || 0);
    setPricePerKm((rest as any).delivery_price_per_km || 0);
    setLatitude((rest as any).latitude || null);
    setLongitude((rest as any).longitude || null);
    setDeliveryFeeType((rest as any).delivery_fee_type || "distance");

    const { data } = await supabase.from("delivery_types").select("*").eq("restaurant_id", rest.id);
    const existing = data || [];

    const missing = FIXED_DELIVERY_TYPES.filter(ft => !existing.some(e => e.name === ft.name));
    if (missing.length > 0) {
      const toInsert = missing.map(m => ({ name: m.name, description: m.description, price: 0, restaurant_id: rest.id, is_active: false }));
      await supabase.from("delivery_types").insert(toInsert);
      const { data: refreshed } = await supabase.from("delivery_types").select("*").eq("restaurant_id", rest.id);
      setItems(refreshed || []);
    } else {
      setItems(existing);
    }
    setLoading(false);
  };

  const toggleActive = async (id: string, current: boolean) => {
    const { error } = await supabase.from("delivery_types").update({ is_active: !current }).eq("id", id);
    if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); return; }
    setItems(prev => prev.map(i => i.id === id ? { ...i, is_active: !current } : i));
  };

  const saveDeliveryConfig = async () => {
    if (!restaurant) return;
    setSavingConfig(true);
    const { error } = await supabase.from("restaurants").update({
      delivery_fee_type: deliveryFeeType,
      delivery_base_fee: baseFee,
      delivery_price_per_km: deliveryFeeType === "distance" ? pricePerKm : 0,
      latitude: deliveryFeeType === "distance" ? latitude : null,
      longitude: deliveryFeeType === "distance" ? longitude : null,
    } as any).eq("id", restaurant.id);
    if (error) {
      toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" });
    } else {
      toast({ title: "Configuración guardada" });
    }
    setSavingConfig(false);
  };

  const getMyLocation = () => {
    if (!navigator.geolocation) {
      toast({ title: "Error", description: "Tu navegador no soporta geolocalización", variant: "destructive" });
      return;
    }
    setGettingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(pos.coords.latitude);
        setLongitude(pos.coords.longitude);
        setGettingLocation(false);
        toast({ title: "Ubicación obtenida", description: `${pos.coords.latitude.toFixed(6)}, ${pos.coords.longitude.toFixed(6)}` });
      },
      () => {
        setGettingLocation(false);
        toast({ title: "Error", description: "No se pudo obtener tu ubicación", variant: "destructive" });
      },
      { enableHighAccuracy: true }
    );
  };

  const getIcon = (name: string) => {
    const found = FIXED_DELIVERY_TYPES.find(ft => ft.name === name);
    return found?.icon || <Truck className="w-6 h-6" />;
  };

  const fixedItems = items.filter(i => FIXED_DELIVERY_TYPES.some(ft => ft.name === i.name));
  const domicilioItem = fixedItems.find(i => i.name === "Domicilio");
  const isDomicilioActive = domicilioItem?.is_active;

  if (loading) return <OwnerLayout title="Tipos de Envío"><div className="flex items-center justify-center h-64"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" /></div></OwnerLayout>;

  return (
    <OwnerLayout title="Tipos de Envío" subtitle="Activa o desactiva las opciones de envío">
      <div className="grid gap-4">
        {fixedItems.map((item) => (
          <Card key={item.id} className={`transition-all ${item.is_active ? 'ring-2 ring-primary/30' : 'opacity-70'}`}>
            <CardContent className="flex items-center gap-4 p-4 sm:p-6">
              <div className={`p-3 rounded-xl ${item.is_active ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                {getIcon(item.name)}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-base">{item.name}</h3>
                <p className="text-sm text-muted-foreground">{item.description || "—"}</p>
              </div>
              <Switch checked={item.is_active} onCheckedChange={() => toggleActive(item.id, item.is_active)} />
            </CardContent>
          </Card>
        ))}

        {/* Distance-based delivery config - only shown when Domicilio is active */}
        {isDomicilioActive && (
          <Card className="ring-2 ring-primary/20">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <MapPin className="w-4 h-4 text-primary" />
                Configuración de Envío a Domicilio
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {/* Fee type selector */}
              <div className="space-y-3">
                <Label className="text-sm font-semibold">Tipo de cobro</Label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setDeliveryFeeType("fixed")}
                    className={`p-3 rounded-xl border-2 text-left transition-all ${deliveryFeeType === "fixed" ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}
                  >
                    <DollarSign className="w-5 h-5 mb-1 text-primary" />
                    <p className="text-sm font-semibold">Precio fijo</p>
                    <p className="text-xs text-muted-foreground">Mismo costo sin importar la distancia</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeliveryFeeType("distance")}
                    className={`p-3 rounded-xl border-2 text-left transition-all ${deliveryFeeType === "distance" ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}
                  >
                    <MapPin className="w-5 h-5 mb-1 text-primary" />
                    <p className="text-sm font-semibold">Por distancia</p>
                    <p className="text-xs text-muted-foreground">Tarifa base + costo por km</p>
                  </button>
                </div>
              </div>

              {deliveryFeeType === "fixed" ? (
                <div>
                  <Label className="text-sm">Precio fijo de envío ($)</Label>
                  <div className="relative mt-1">
                    <DollarSign className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      type="number"
                      step="0.5"
                      min="0"
                      className="pl-8"
                      value={baseFee}
                      onChange={e => setBaseFee(parseFloat(e.target.value) || 0)}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Este monto se cobrará en todos los envíos a domicilio</p>
                </div>
              ) : (
                <>
                  <p className="text-sm text-muted-foreground">
                    <strong className="text-foreground">Fórmula:</strong> Tarifa base + (Precio por km × distancia)
                  </p>

                  {/* Restaurant location */}
                  <div className="space-y-3">
                    <Label className="text-sm font-semibold">📍 Ubicación de tu negocio</Label>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={getMyLocation}
                        disabled={gettingLocation}
                        className="flex items-center gap-2"
                      >
                        <Navigation className={`w-4 h-4 ${gettingLocation ? 'animate-spin' : ''}`} />
                        {gettingLocation ? "Obteniendo..." : "Usar mi ubicación actual"}
                      </Button>
                    </div>
                    {latitude && longitude ? (
                      <div className="flex items-center gap-2 p-3 rounded-xl bg-primary/5 border border-primary/20">
                        <MapPin className="w-4 h-4 text-primary shrink-0" />
                        <span className="text-sm text-foreground">
                          {latitude.toFixed(6)}, {longitude.toFixed(6)}
                        </span>
                      </div>
                    ) : (
                      <p className="text-xs text-destructive font-medium">⚠️ Debes configurar la ubicación de tu negocio para calcular distancias.</p>
                    )}
                  </div>

                  {/* Pricing */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm">Tarifa base ($)</Label>
                      <div className="relative mt-1">
                        <DollarSign className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          type="number"
                          step="0.5"
                          min="0"
                          className="pl-8"
                          value={baseFee}
                          onChange={e => setBaseFee(parseFloat(e.target.value) || 0)}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Costo mínimo de envío</p>
                    </div>
                    <div>
                      <Label className="text-sm">Precio por km ($)</Label>
                      <div className="relative mt-1">
                        <DollarSign className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          type="number"
                          step="0.5"
                          min="0"
                          className="pl-8"
                          value={pricePerKm}
                          onChange={e => setPricePerKm(parseFloat(e.target.value) || 0)}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Se multiplica por la distancia</p>
                    </div>
                  </div>

                  {/* Example calculation */}
                  {pricePerKm > 0 && (
                    <div className="p-3 rounded-xl bg-muted/50 border border-border">
                      <p className="text-xs font-semibold text-foreground mb-1">Ejemplo de cálculo:</p>
                      <p className="text-xs text-muted-foreground">
                        A 3 km → ${(baseFee + pricePerKm * 3).toFixed(2)} &nbsp;|&nbsp;
                        A 5 km → ${(baseFee + pricePerKm * 5).toFixed(2)} &nbsp;|&nbsp;
                        A 10 km → ${(baseFee + pricePerKm * 10).toFixed(2)}
                      </p>
                    </div>
                  )}
                </>
              )}

              <Button onClick={saveDeliveryConfig} disabled={savingConfig} className="w-full sm:w-auto">
                {savingConfig ? "Guardando..." : "Guardar configuración de envío"}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </OwnerLayout>
  );
};

export default Delivery;
