import { useEffect, useState } from "react";
import { getUserFriendlyError } from "@/lib/error-utils";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Banknote, ArrowLeftRight, CreditCard } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import OwnerLayout from "@/components/OwnerLayout";

const FIXED_PAYMENT_METHODS = [
  { name: "Efectivo", icon: <Banknote className="w-6 h-6" />, description: "Pago en efectivo al recibir" },
  { name: "Transferencia", icon: <ArrowLeftRight className="w-6 h-6" />, description: "Pago por transferencia bancaria" },
  { name: "Tarjeta", icon: <CreditCard className="w-6 h-6" />, description: "Pago con tarjeta de crédito o débito" },
];

const Payments = () => {
  const [items, setItems] = useState<any[]>([]);
  const [restaurant, setRestaurant] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) { navigate("/auth"); return; }
    const { data: rest } = await supabase.from("restaurants").select("*").eq("owner_id", session.user.id).limit(1).maybeSingle();
    if (!rest) { navigate("/owner"); return; }
    setRestaurant(rest);

    const { data } = await supabase.from("payment_methods").select("*").eq("restaurant_id", rest.id);
    const existing = data || [];

    // Auto-seed missing fixed types
    const missing = FIXED_PAYMENT_METHODS.filter(ft => !existing.some(e => e.name === ft.name));
    if (missing.length > 0) {
      const toInsert = missing.map(m => ({ name: m.name, description: m.description, icon: null, restaurant_id: rest.id, is_active: false }));
      await supabase.from("payment_methods").insert(toInsert);
      const { data: refreshed } = await supabase.from("payment_methods").select("*").eq("restaurant_id", rest.id);
      setItems(refreshed || []);
    } else {
      setItems(existing);
    }
    setLoading(false);
  };

  const toggleActive = async (id: string, current: boolean) => {
    const { error } = await supabase.from("payment_methods").update({ is_active: !current }).eq("id", id);
    if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); return; }
    setItems(prev => prev.map(i => i.id === id ? { ...i, is_active: !current } : i));
  };

  const updateTransferDetails = async (id: string, details: string) => {
    const { error } = await supabase.from("payment_methods").update({ transfer_details: details } as any).eq("id", id);
    if (error) { toast({ title: "Error", description: getUserFriendlyError(error), variant: "destructive" }); return; }
    setItems(prev => prev.map(i => i.id === id ? { ...i, transfer_details: details } : i));
  };

  const getIcon = (name: string) => {
    const found = FIXED_PAYMENT_METHODS.find(ft => ft.name === name);
    return found?.icon || <Banknote className="w-6 h-6" />;
  };

  // Only show fixed types
  const fixedItems = items.filter(i => FIXED_PAYMENT_METHODS.some(ft => ft.name === i.name));

  if (loading) return <OwnerLayout title="Métodos de Pago"><div className="flex items-center justify-center h-64"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" /></div></OwnerLayout>;

  return (
    <OwnerLayout title="Métodos de Pago" subtitle="Activa o desactiva las formas de pago">
      <div className="grid gap-4">
        {fixedItems.map((item) => (
          <Card key={item.id} className={`transition-all ${item.is_active ? 'ring-2 ring-primary/30' : 'opacity-70'}`}>
            <CardContent className="flex items-start gap-4 p-4 sm:p-6">
              <div className={`p-3 rounded-xl mt-0.5 ${item.is_active ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                {getIcon(item.name)}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-base">{item.name}</h3>
                <p className="text-sm text-muted-foreground">{item.description || "—"}</p>
                {item.name === "Transferencia" && item.is_active && (
                  <div className="mt-3">
                    <Label className="text-sm">Detalles de transferencia</Label>
                    <Textarea
                      className="mt-1.5 text-sm"
                      placeholder="Ej: Banco XYZ, CLABE: 1234..., Nombre: Juan Pérez"
                      defaultValue={item.transfer_details || ""}
                      onBlur={(e) => updateTransferDetails(item.id, e.target.value)}
                      rows={3}
                    />
                  </div>
                )}
              </div>
              <Switch checked={item.is_active} onCheckedChange={() => toggleActive(item.id, item.is_active)} className="mt-1" />
            </CardContent>
          </Card>
        ))}
      </div>
    </OwnerLayout>
  );
};

export default Payments;
