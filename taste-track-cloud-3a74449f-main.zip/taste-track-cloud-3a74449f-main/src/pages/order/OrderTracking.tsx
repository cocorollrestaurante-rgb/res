import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, Clock, Truck, Package, XCircle, ChefHat, Loader2 } from "lucide-react";

interface OrderTracking {
  id: string;
  order_number: number;
  status: string;
  customer_name: string;
  total: number;
  delivery_fee: number;
  subtotal: number;
  created_at: string;
  updated_at: string;
  restaurant_id: string;
}

interface Restaurant {
  name: string;
  logo_url: string | null;
  slug: string;
}

const steps = [
  { key: "pending", label: "Pendiente", icon: Clock, color: "text-yellow-500" },
  { key: "confirmed", label: "Confirmado", icon: CheckCircle2, color: "text-blue-500" },
  { key: "preparing", label: "Preparando", icon: ChefHat, color: "text-orange-500" },
  { key: "ready", label: "Listo", icon: Package, color: "text-green-500" },
  { key: "on_the_way", label: "En camino", icon: Truck, color: "text-purple-500" },
  { key: "delivered", label: "Entregado", icon: CheckCircle2, color: "text-green-600" },
];

const OrderTracking = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const [order, setOrder] = useState<OrderTracking | null>(null);
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!orderId) return;

    const fetchOrder = async () => {
      const { data, error: err } = await supabase
        .from("orders")
        .select("id, order_number, status, customer_name, total, delivery_fee, subtotal, created_at, updated_at, restaurant_id")
        .eq("id", orderId)
        .maybeSingle();

      if (err || !data) {
        setError("Pedido no encontrado");
        setLoading(false);
        return;
      }

      setOrder(data);

      const { data: rest } = await supabase
        .from("restaurants")
        .select("name, logo_url, slug")
        .eq("id", data.restaurant_id)
        .maybeSingle();

      setRestaurant(rest);
      setLoading(false);
    };

    fetchOrder();

    // Realtime subscription
    const channel = supabase
      .channel(`order-tracking-${orderId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "orders",
          filter: `id=eq.${orderId}`,
        },
        (payload) => {
          setOrder((prev) =>
            prev ? { ...prev, ...payload.new as Partial<OrderTracking> } : prev
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [orderId]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background gap-4 px-4">
        <XCircle className="w-16 h-16 text-destructive" />
        <h1 className="text-xl font-bold text-foreground">Pedido no encontrado</h1>
        <p className="text-muted-foreground text-center">Verifica el enlace e intenta de nuevo.</p>
      </div>
    );
  }

  const isCancelled = order.status === "cancelled";
  const currentStepIndex = steps.findIndex((s) => s.key === order.status);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary/5 border-b border-border px-4 py-6">
        <div className="max-w-md mx-auto text-center">
          {restaurant?.logo_url && (
            <img
              src={restaurant.logo_url}
              alt={restaurant.name}
              className="w-14 h-14 rounded-full object-cover mx-auto mb-3 border-2 border-primary/20"
            />
          )}
          <h1 className="text-lg font-bold text-foreground font-sans">
            Pedido #{order.order_number}
          </h1>
          {restaurant && (
            <p className="text-sm text-muted-foreground mt-1">{restaurant.name}</p>
          )}
          <p className="text-xs text-muted-foreground mt-1">
            {order.customer_name} · {new Date(order.created_at).toLocaleDateString("es-MX", {
              day: "2-digit",
              month: "short",
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-8">
        {isCancelled ? (
          <div className="text-center py-8">
            <XCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
            <h2 className="text-xl font-bold text-destructive mb-2">Pedido cancelado</h2>
            <p className="text-muted-foreground">
              Este pedido ha sido cancelado. Contacta al restaurante para más información.
            </p>
          </div>
        ) : (
          /* Progress tracker */
          <div className="space-y-0">
            {steps.map((step, index) => {
              const isActive = index <= currentStepIndex;
              const isCurrent = index === currentStepIndex;
              const Icon = step.icon;

              return (
                <div key={step.key} className="flex items-start gap-4">
                  {/* Line + Icon */}
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-all duration-500 ${
                        isCurrent
                          ? "bg-primary text-primary-foreground scale-110 shadow-lg ring-4 ring-primary/20"
                          : isActive
                          ? "bg-primary/80 text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    {index < steps.length - 1 && (
                      <div
                        className={`w-0.5 h-12 transition-colors duration-500 ${
                          isActive ? "bg-primary/60" : "bg-muted"
                        }`}
                      />
                    )}
                  </div>

                  {/* Label */}
                  <div className="pt-2 pb-6">
                    <p
                      className={`font-semibold text-sm transition-colors ${
                        isCurrent
                          ? "text-primary"
                          : isActive
                          ? "text-foreground"
                          : "text-muted-foreground"
                      }`}
                    >
                      {step.label}
                    </p>
                    {isCurrent && (
                      <p className="text-xs text-muted-foreground mt-0.5 animate-pulse">
                        Estado actual
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Order summary */}
        <div className="mt-8 p-4 rounded-xl bg-muted/50 border border-border space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Subtotal</span>
            <span>${order.subtotal}</span>
          </div>
          {order.delivery_fee > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Envío</span>
              <span>${order.delivery_fee}</span>
            </div>
          )}
          <div className="flex justify-between font-bold border-t border-border pt-2">
            <span>Total</span>
            <span className="text-primary">${order.total}</span>
          </div>
        </div>

        {/* Link back to menu */}
        {restaurant?.slug && (
          <div className="mt-6 text-center">
            <Link
              to={`/menu/${restaurant.slug}`}
              className="text-sm text-primary hover:underline font-medium"
            >
              ← Volver al menú
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrderTracking;
