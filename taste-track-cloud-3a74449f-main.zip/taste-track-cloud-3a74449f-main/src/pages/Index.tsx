import { Button } from "@/components/ui/button";
import { UtensilsCrossed, ArrowRight, Smartphone, Palette, BarChart3, Clock, Globe, ChevronRight, Star, CheckCircle2, Camera, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import { useEffect, useRef } from "react";
import featureAiImport from "@/assets/feature-ai-import.jpg";
import featureUpsell from "@/assets/feature-upsell.jpg";

const Index = () => {
  return (
    <div className="min-h-screen bg-[hsl(220,20%,4%)] text-[hsl(0,0%,95%)] overflow-hidden">
      {/* Noise texture overlay */}
      <div className="fixed inset-0 pointer-events-none z-50 opacity-[0.03]" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 256 256\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noise\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noise)\'/%3E%3C/svg%3E")' }} />

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-40">
        <div className="mx-4 mt-4">
          <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between rounded-2xl bg-[hsl(220,20%,8%)/0.7] backdrop-blur-xl border border-[hsl(220,20%,20%)/0.5]">
            <Link to="/" className="flex items-center gap-2.5 group">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[hsl(24,95%,53%)] to-[hsl(340,80%,55%)] flex items-center justify-center">
                <UtensilsCrossed className="w-4 h-4 text-white" />
              </div>
              <span className="font-sans text-base font-bold tracking-tight">Menu365</span>
            </Link>
            <nav className="hidden md:flex items-center gap-1">
              <a href="#features" className="px-3 py-1.5 text-sm text-[hsl(0,0%,60%)] hover:text-white transition-colors rounded-lg hover:bg-[hsl(220,20%,15%)/0.5]">Funciones</a>
              <a href="#steps" className="px-3 py-1.5 text-sm text-[hsl(0,0%,60%)] hover:text-white transition-colors rounded-lg hover:bg-[hsl(220,20%,15%)/0.5]">Cómo funciona</a>
              <a href="#pricing" className="px-3 py-1.5 text-sm text-[hsl(0,0%,60%)] hover:text-white transition-colors rounded-lg hover:bg-[hsl(220,20%,15%)/0.5]">Precios</a>
              <Link to="/auth" className="px-3 py-1.5 text-sm text-[hsl(0,0%,60%)] hover:text-white transition-colors rounded-lg hover:bg-[hsl(220,20%,15%)/0.5]">Entrar</Link>
              <Link to="/auth?mode=signup" className="ml-2 px-4 py-1.5 text-sm font-medium bg-gradient-to-r from-[hsl(24,95%,53%)] to-[hsl(340,80%,55%)] rounded-lg hover:opacity-90 transition-opacity text-white">
                Empezar
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center px-4 pt-20">
        {/* Background effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-[20%] left-[50%] -translate-x-1/2 w-[800px] h-[600px] bg-[hsl(24,95%,53%)/0.08] rounded-full blur-[120px]" />
          <div className="absolute top-[30%] left-[30%] w-[400px] h-[400px] bg-[hsl(260,80%,60%)/0.06] rounded-full blur-[100px]" />
          <div className="absolute top-[40%] right-[20%] w-[300px] h-[300px] bg-[hsl(340,80%,55%)/0.05] rounded-full blur-[100px]" />
          {/* Grid */}
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(hsl(220,20%,15%)/0.3 1px, transparent 1px), linear-gradient(90deg, hsl(220,20%,15%)/0.3 1px, transparent 1px)`,
            backgroundSize: '80px 80px'
          }} />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[hsl(220,20%,4%)]" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[hsl(24,95%,53%)/0.3] bg-[hsl(24,95%,53%)/0.08] mb-10 animate-fade-in">
            <div className="w-1.5 h-1.5 rounded-full bg-[hsl(24,95%,53%)] animate-pulse" />
            <span className="text-xs font-medium text-[hsl(24,95%,65%)] tracking-wide uppercase">Nuevo — Menús con IA integrada</span>
          </div>

          {/* Heading */}
          <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] font-sans font-black leading-[0.95] tracking-tight mb-8 animate-fade-in" style={{ animationDelay: '0.1s' }}>
            El futuro de tu
            <br />
            <span className="relative inline-block mt-2">
              <span className="bg-gradient-to-r from-[hsl(24,95%,60%)] via-[hsl(340,80%,60%)] to-[hsl(260,80%,65%)] bg-clip-text text-transparent">
                menú digital
              </span>
              <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 300 12" fill="none">
                <path d="M2 8 C50 2, 100 2, 150 6 S250 10, 298 4" stroke="url(#underline-grad)" strokeWidth="3" strokeLinecap="round" />
                <defs>
                  <linearGradient id="underline-grad" x1="0" y1="0" x2="300" y2="0">
                    <stop offset="0%" stopColor="hsl(24,95%,60%)" />
                    <stop offset="100%" stopColor="hsl(340,80%,60%)" />
                  </linearGradient>
                </defs>
              </svg>
            </span>
            <br />
            <span className="text-[hsl(0,0%,40%)]">empieza aquí.</span>
          </h1>

          <p className="text-lg md:text-xl text-[hsl(0,0%,50%)] max-w-2xl mx-auto mb-12 animate-fade-in leading-relaxed" style={{ animationDelay: '0.2s' }}>
            Crea, personaliza y comparte tu carta en minutos. 
            Sin código. Sin complicaciones. Resultados inmediatos.
          </p>

          {/* CTA */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <Link
              to="/auth?mode=signup"
              className="group relative px-8 py-4 bg-gradient-to-r from-[hsl(24,95%,53%)] to-[hsl(340,80%,55%)] rounded-xl font-semibold text-white text-base hover:shadow-[0_0_40px_hsl(24,95%,53%/0.4)] transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] flex items-center gap-2">

              Crear mi menú gratis
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              to="/menu/demo"
              className="px-8 py-4 rounded-xl font-medium text-[hsl(0,0%,60%)] border border-[hsl(220,20%,18%)] hover:border-[hsl(220,20%,30%)] hover:text-white transition-all duration-300 text-base">

              Ver demostración →
            </Link>
          </div>

          {/* Social proof */}
          <div className="mt-16 flex flex-wrap items-center justify-center gap-8 animate-fade-in" style={{ animationDelay: '0.5s' }}>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-black bg-gradient-to-r from-[hsl(24,95%,60%)] to-[hsl(340,80%,60%)] bg-clip-text text-transparent">1,000+</span>
              <span className="text-sm text-[hsl(0,0%,50%)]">clientes ya confían</span>
            </div>
            <div className="h-5 w-px bg-[hsl(220,20%,20%)]" />
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 fill-[hsl(45,93%,58%)] text-[hsl(45,93%,58%)]" />
                <span className="text-lg font-black text-white">4.8</span>
              </div>
              <span className="text-sm text-[hsl(0,0%,50%)]">en Google</span>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Showcase: AI Import */}
      <section className="relative py-24 px-4 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-[40%] left-[20%] w-[500px] h-[500px] bg-[hsl(280,80%,60%)/0.06] rounded-full blur-[120px]" />
        </div>
        <div className="max-w-6xl mx-auto relative">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Text */}
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[hsl(280,80%,60%)/0.3] bg-[hsl(280,80%,60%)/0.08] mb-6">
                <Camera className="w-3.5 h-3.5 text-[hsl(280,80%,65%)]" />
                <span className="text-xs font-semibold text-[hsl(280,80%,70%)] uppercase tracking-wider">Inteligencia Artificial</span>
              </div>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-sans font-black tracking-tight mb-6 leading-[1.1]">
                Sube una foto,
                <br />
                <span className="bg-gradient-to-r from-[hsl(280,80%,65%)] to-[hsl(24,95%,60%)] bg-clip-text text-transparent">
                  la IA hace el resto
                </span>
              </h2>
              <p className="text-[hsl(0,0%,50%)] text-lg leading-relaxed mb-8 max-w-lg">
                Toma una foto de tu menú físico y nuestra IA extrae <strong className="text-[hsl(0,0%,70%)]">todos los productos, precios y descripciones</strong> automáticamente. Lo que antes tomaba horas, ahora son segundos.
              </p>
              <div className="space-y-3">
                {[
                  "Extrae nombres, precios y descripciones al instante",
                  "Revisa y asigna categorías antes de publicar",
                  "Importa menús completos en menos de 1 minuto"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-[hsl(280,80%,60%)/0.15] flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[hsl(280,80%,65%)]" />
                    </div>
                    <span className="text-sm text-[hsl(0,0%,60%)]">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            {/* Image */}
            <div className="relative group">
              <div className="absolute -inset-4 bg-gradient-to-br from-[hsl(280,80%,60%)/0.15] to-[hsl(24,95%,53%)/0.1] rounded-3xl blur-2xl opacity-60 group-hover:opacity-100 transition-opacity duration-700" />
              <div className="relative rounded-2xl overflow-hidden border border-[hsl(220,20%,15%)] shadow-2xl shadow-[hsl(280,80%,50%)/0.08]">
                <img src={featureAiImport} alt="Importación de menú con IA" className="w-full h-auto" />
                <div className="absolute inset-0 bg-gradient-to-t from-[hsl(220,20%,4%)/0.6] via-transparent to-transparent" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Showcase: Upsell */}
      <section className="relative py-24 px-4 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-[30%] right-[20%] w-[500px] h-[500px] bg-[hsl(24,95%,53%)/0.06] rounded-full blur-[120px]" />
        </div>
        <div className="max-w-6xl mx-auto relative">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Image (left on desktop) */}
            <div className="relative group order-2 lg:order-1">
              <div className="absolute -inset-4 bg-gradient-to-br from-[hsl(24,95%,53%)/0.15] to-[hsl(340,80%,55%)/0.1] rounded-3xl blur-2xl opacity-60 group-hover:opacity-100 transition-opacity duration-700" />
              <div className="relative rounded-2xl overflow-hidden border border-[hsl(220,20%,15%)] shadow-2xl shadow-[hsl(24,95%,50%)/0.08] max-w-sm mx-auto lg:max-w-none">
                <img src={featureUpsell} alt="Sugerencia de productos para aumentar ticket" className="w-full h-auto" />
                <div className="absolute inset-0 bg-gradient-to-t from-[hsl(220,20%,4%)/0.6] via-transparent to-transparent" />
              </div>
            </div>
            {/* Text */}
            <div className="order-1 lg:order-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[hsl(24,95%,53%)/0.3] bg-[hsl(24,95%,53%)/0.08] mb-6">
                <TrendingUp className="w-3.5 h-3.5 text-[hsl(24,95%,60%)]" />
                <span className="text-xs font-semibold text-[hsl(24,95%,65%)] uppercase tracking-wider">Más ventas</span>
              </div>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-sans font-black tracking-tight mb-6 leading-[1.1]">
                Aumenta tu ticket
                <br />
                <span className="bg-gradient-to-r from-[hsl(24,95%,60%)] to-[hsl(340,80%,60%)] bg-clip-text text-transparent">
                  con cada pedido
                </span>
              </h2>
              <p className="text-[hsl(0,0%,50%)] text-lg leading-relaxed mb-8 max-w-lg">
                Sugiere productos irresistibles justo antes de que el cliente finalice su compra. <strong className="text-[hsl(0,0%,70%)]">Tú eliges qué recomendar</strong> y tu ticket promedio sube sin esfuerzo.
              </p>
              <div className="space-y-3">
                {[
                  "Elige qué productos sugerir al finalizar el pedido",
                  "Se muestra automáticamente en el carrito del cliente",
                  "Incrementa el ticket promedio de forma natural"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-[hsl(24,95%,53%)/0.15] flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[hsl(24,95%,60%)]" />
                    </div>
                    <span className="text-sm text-[hsl(0,0%,60%)]">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="relative py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-20">
            <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[hsl(24,95%,60%)] mb-4 block">Más funciones</span>
            <h2 className="text-4xl md:text-5xl font-sans font-black tracking-tight">
              Todo en un solo lugar
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
            { icon: Smartphone, title: "Menú responsive", desc: "Optimizado para cualquier dispositivo. Tus clientes ven tu carta perfecta desde el celular.", color: "24,95%,53%" },
            { icon: Palette, title: "Personalización total", desc: "Colores, categorías, fotos HD. Haz que tu menú refleje la identidad de tu marca.", color: "340,80%,55%" },
            { icon: Clock, title: "Cambios al instante", desc: "Modifica precios, agrega productos o desactiva platos. Todo se actualiza en tiempo real.", color: "260,80%,65%" },
            { icon: BarChart3, title: "Analíticas", desc: "Conoce qué platos son los más vistos, cuántas visitas recibes y optimiza tu carta.", color: "170,80%,45%" },
            { icon: Globe, title: "QR & Link único", desc: "Genera un código QR y un enlace personalizado para compartir tu menú en segundos.", color: "45,93%,55%" },
            { icon: CheckCircle2, title: "Panel intuitivo", desc: "Sin curva de aprendizaje. Gestiona todo desde un dashboard limpio y moderno.", color: "140,70%,45%" }].
            map((feature, i) =>
            <div
              key={i}
              className="group relative p-7 rounded-2xl border border-[hsl(220,20%,12%)] bg-[hsl(220,20%,6%)] hover:border-[hsl(220,20%,20%)] transition-all duration-500 hover:-translate-y-1">

                <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
              style={{ background: `radial-gradient(400px at 50% 0%, hsl(${feature.color}/0.08), transparent)` }} />

                <div className="relative">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-5"
                style={{ background: `hsl(${feature.color}/0.12)`, color: `hsl(${feature.color})` }}>
                    <feature.icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold mb-2 font-sans">{feature.title}</h3>
                  <p className="text-sm text-[hsl(0,0%,45%)] leading-relaxed">{feature.desc}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Steps */}
      <section id="steps" className="relative py-32 px-4">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[hsl(260,80%,60%)/0.04] rounded-full blur-[120px]" />
        </div>
        <div className="max-w-4xl mx-auto relative">
          <div className="text-center mb-20">
            <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[hsl(24,95%,60%)] mb-4 block">Cómo funciona</span>
            <h2 className="text-4xl md:text-5xl font-sans font-black tracking-tight">
              Tres pasos. Cero estrés.
            </h2>
          </div>

          <div className="space-y-6">
            {[
            { num: "01", title: "Regístrate gratis", desc: "Crea tu cuenta en 30 segundos. Sin tarjeta de crédito. Sin trucos." },
            { num: "02", title: "Arma tu menú", desc: "Agrega categorías, platos, precios y fotos. Personaliza los colores y el diseño." },
            { num: "03", title: "Comparte con el mundo", desc: "Obtén tu QR y link único. Ponlo en mesas, redes sociales o donde quieras." }].
            map((step, i) =>
            <div key={i} className="group flex items-start gap-6 p-6 rounded-2xl border border-[hsl(220,20%,10%)] bg-[hsl(220,20%,6%)/0.5] hover:border-[hsl(24,95%,53%)/0.3] hover:bg-[hsl(220,20%,7%)] transition-all duration-300">
                <span className="text-4xl font-black bg-gradient-to-b from-[hsl(24,95%,53%)] to-[hsl(340,80%,55%)] bg-clip-text text-transparent shrink-0 w-16">
                  {step.num}
                </span>
                <div>
                  <h3 className="text-xl font-bold font-sans mb-1">{step.title}</h3>
                  <p className="text-[hsl(0,0%,45%)]">{step.desc}</p>
                </div>
                <ChevronRight className="w-5 h-5 text-[hsl(0,0%,25%)] group-hover:text-[hsl(24,95%,53%)] group-hover:translate-x-1 transition-all ml-auto mt-2 shrink-0" />
              </div>
            )}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section id="pricing" className="relative py-32 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="relative p-12 md:p-16 rounded-3xl border border-[hsl(220,20%,12%)] bg-[hsl(220,20%,6%)] overflow-hidden">
            {/* Glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[400px] h-[200px] bg-gradient-to-b from-[hsl(24,95%,53%)/0.15] to-transparent blur-[60px]" />
            <div className="absolute inset-0 bg-gradient-to-b from-[hsl(24,95%,53%)/0.02] to-transparent" />
            
            <div className="relative">
              <h2 className="text-4xl md:text-5xl font-sans font-black tracking-tight mb-4">
                ¿Listo para
                <span className="bg-gradient-to-r from-[hsl(24,95%,60%)] to-[hsl(340,80%,60%)] bg-clip-text text-transparent"> empezar</span>?
              </h2>
              <p className="text-[hsl(0,0%,45%)] text-lg mb-10 max-w-lg mx-auto">
                Únete a más de 500 restaurantes que ya digitalizaron su carta. 
                Comienza gratis, sin límite de tiempo.
              </p>
              <Link
                to="/auth?mode=signup"
                className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-[hsl(24,95%,53%)] to-[hsl(340,80%,55%)] rounded-xl font-semibold text-white hover:shadow-[0_0_50px_hsl(24,95%,53%/0.4)] transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] text-base">

                Comenzar ahora — es gratis
                <ArrowRight className="w-4 h-4" />
              </Link>
              <p className="mt-6 text-xs text-[hsl(0,0%,35%)]">Sin tarjeta de crédito · Cancela cuando quieras</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[hsl(220,20%,10%)] py-10 px-4">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-md bg-gradient-to-br from-[hsl(24,95%,53%)] to-[hsl(340,80%,55%)] flex items-center justify-center">
              <UtensilsCrossed className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-sans text-sm font-bold">Menu365</span>
          </div>
          <div className="flex items-center gap-6 text-sm text-[hsl(0,0%,40%)]">
            <Link to="/auth" className="hover:text-white transition-colors">Entrar</Link>
            <Link to="/auth?mode=signup" className="hover:text-white transition-colors">Registrarse</Link>
          </div>
          <p className="text-xs text-[hsl(0,0%,30%)]">© 2025 Menu365</p>
        </div>
      </footer>
    </div>);

};

export default Index;