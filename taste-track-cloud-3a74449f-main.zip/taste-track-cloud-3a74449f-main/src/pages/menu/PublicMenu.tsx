import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { 
  UtensilsCrossed, Search, MapPin, Phone, Loader2,
  ShoppingBag, Plus, Minus, Trash2, X, ArrowLeft, ArrowRight, CheckCircle2,
  User, MapPinned, CreditCard, Clock, Share2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

function haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

interface Restaurant {
  id: string; name: string; description: string | null; logo_url: string | null;
  cover_url: string | null; address: string | null; phone: string | null;
  email: string | null; opening_hours: any; facebook_pixel_id?: string | null;
  delivery_time?: string | null; instagram_url?: string | null;
  facebook_url?: string | null; website_url?: string | null;
  review_widget_id?: string | null;
  latitude?: number | null; longitude?: number | null;
  delivery_base_fee?: number | null; delivery_price_per_km?: number | null;
  delivery_fee_type?: string | null;
}
interface Category { id: string; name: string; icon: string | null; sort_order: number | null; }
interface Product {
  id: string; name: string; description: string | null; price: number;
  image_url: string | null; category_id: string | null; is_featured: boolean | null; sort_order: number | null;
  is_available: boolean | null; is_upsell: boolean | null;
}
interface OptionGroup {
  id: string; product_id: string; name: string; is_required: boolean;
  min_selections: number; max_selections: number; sort_order: number;
  product_options: ProductOption[];
}
interface ProductOption {
  id: string; name: string; price_adjustment: number; is_available: boolean;
}
interface SelectedOption { optionId: string; name: string; priceAdjustment: number; groupName: string; isRequired: boolean; quantity: number; }
interface CartItem { product: Product; quantity: number; notes?: string; selectedOptions: SelectedOption[]; cartKey: string; }
interface DeliveryType { id: string; name: string; description: string | null; price: number | null; }
interface PaymentMethod { id: string; name: string; description: string | null; icon: string | null; }

type CheckoutStep = "cart" | "delivery" | "info" | "confirm";

// Global flag to avoid loading review scripts multiple times
let reviewScriptsExecuted = false;

// Component to render review widget HTML and execute scripts after mount
const ReviewWidgetEmbed = ({ code }: { code: string }) => {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    // Strip script tags and insert only HTML elements
    const htmlOnly = code.replace(/<script[\s\S]*?<\/script>/gi, '');
    ref.current.innerHTML = htmlOnly;

    // Execute scripts only once (first instance handles it)
    if (!reviewScriptsExecuted) {
      reviewScriptsExecuted = true;
      // Small delay to ensure custom elements are in the DOM
      setTimeout(() => {
        const temp = document.createElement("div");
        temp.innerHTML = code;
        const scripts = temp.querySelectorAll("script");
        scripts.forEach(originalScript => {
          const script = document.createElement("script");
          Array.from(originalScript.attributes).forEach(attr => {
            script.setAttribute(attr.name, attr.value);
          });
          if (originalScript.textContent) {
            script.textContent = originalScript.textContent;
          }
          document.head.appendChild(script);
        });
      }, 500);
    }
  }, [code]);
  return <div ref={ref} className="mt-4" />;
};

const PublicMenu = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [optionGroups, setOptionGroups] = useState<OptionGroup[]>([]);
  const [deliveryTypes, setDeliveryTypes] = useState<DeliveryType[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [deliveryMode, setDeliveryMode] = useState<"delivery" | "pickup">("delivery");

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(`cart_${slug}`);
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<CheckoutStep>("cart");

  // Product options modal
  const [optionsModalProduct, setOptionsModalProduct] = useState<Product | null>(null);
  const [modalSelectedOptions, setModalSelectedOptions] = useState<Record<string, string[]>>({});
  const [modalOptionQuantities, setModalOptionQuantities] = useState<Record<string, number>>({});
  const [modalQuantity, setModalQuantity] = useState(1);
  const [modalNotes, setModalNotes] = useState("");

  const savedCustomer = (() => {
    try { const s = localStorage.getItem(`customer_${slug}`); return s ? JSON.parse(s) : null; } catch { return null; }
  })();
  const [customerName, setCustomerName] = useState(savedCustomer?.name || "");
  const [customerPhone, setCustomerPhone] = useState(savedCustomer?.phone || "");
  const [customerEmail, setCustomerEmail] = useState(savedCustomer?.email || "");
  const [customerStreet, setCustomerStreet] = useState(savedCustomer?.street || "");
  const [customerColonia, setCustomerColonia] = useState(savedCustomer?.colonia || "");
  const [customerZip, setCustomerZip] = useState(savedCustomer?.zip || "");
  const [customerReferences, setCustomerReferences] = useState(savedCustomer?.references || "");
  const [customerLocationUrl, setCustomerLocationUrl] = useState("");
  const [selectedDelivery, setSelectedDelivery] = useState<string | null>(null);
  const [selectedPayment, setSelectedPayment] = useState<string | null>(null);
  const [orderNotes, setOrderNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [cashAmount, setCashAmount] = useState("");
  const [tipAmount, setTipAmount] = useState<number>(0);
  const [customTipAmount, setCustomTipAmount] = useState("");
  const [orderConfirmed, setOrderConfirmed] = useState<string | null>(null);
  const [confirmedOrderId, setConfirmedOrderId] = useState<string | null>(null);
  const [showSchedule, setShowSchedule] = useState(false);
  const [customerLat, setCustomerLat] = useState<number | null>(null);
  const [customerLng, setCustomerLng] = useState<number | null>(null);
  const [gettingLocation, setGettingLocation] = useState(false);
  const [deliveryDistance, setDeliveryDistance] = useState<number | null>(null);
  const [confirmedItems, setConfirmedItems] = useState<CartItem[]>([]);
  const [confirmedTotal, setConfirmedTotal] = useState(0);
  const [confirmedSubtotal, setConfirmedSubtotal] = useState(0);
  const [confirmedDeliveryFee, setConfirmedDeliveryFee] = useState(0);
  const [mostOrderedIds, setMostOrderedIds] = useState<string[]>([]);
  const [trendingIds, setTrendingIds] = useState<string[]>([]);

  // Persist cart to localStorage
  useEffect(() => {
    try {
      if (cart.length > 0) {
        localStorage.setItem(`cart_${slug}`, JSON.stringify(cart));
      } else {
        localStorage.removeItem(`cart_${slug}`);
      }
    } catch {}
  }, [cart, slug]);

  useEffect(() => {
    const fetchMenu = async () => {
      if (!slug) return;
      const { data: rest, error: restErr } = await supabase
        .from("restaurants").select("id, name, description, logo_url, cover_url, address, phone, email, opening_hours, facebook_pixel_id, delivery_time, instagram_url, facebook_url, website_url, review_widget_id, latitude, longitude, delivery_base_fee, delivery_price_per_km, delivery_fee_type")
        .eq("slug", slug).eq("is_active", true).single();
      if (restErr || !rest) { setError("Restaurante no encontrado"); setLoading(false); return; }
      setRestaurant(rest);
      const [catRes, prodRes, delRes, payRes, optRes] = await Promise.all([
        supabase.from("categories").select("id, name, icon, sort_order").eq("restaurant_id", rest.id).eq("is_active", true).order("sort_order"),
        supabase.from("products").select("id, name, description, price, image_url, category_id, is_featured, sort_order, is_available, is_upsell").eq("restaurant_id", rest.id).order("sort_order"),
        supabase.from("delivery_types").select("id, name, description, price").eq("restaurant_id", rest.id).eq("is_active", true),
        supabase.from("payment_methods").select("id, name, description, icon").eq("restaurant_id", rest.id).eq("is_active", true),
        supabase.from("product_option_groups").select("*, product_options(*)").eq("restaurant_id", rest.id).order("sort_order"),
      ]);
      setCategories(catRes.data || []); setProducts(prodRes.data || []);
      setDeliveryTypes(delRes.data || []); setPaymentMethods(payRes.data || []);
      const groups = (optRes.data || []).map((g: any) => ({
        ...g,
        product_options: (g.product_options || []).filter((o: any) => o.is_available).sort((a: any, b: any) => a.sort_order - b.sort_order),
      }));
      setOptionGroups(groups);

      // Fetch real sales data for popular sections
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      const [allTimeSales, recentSales] = await Promise.all([
        supabase.from("order_items").select("product_id, quantity").in(
          "order_id",
          (await supabase.from("orders").select("id").eq("restaurant_id", rest.id)).data?.map((o: any) => o.id) || []
        ),
        supabase.from("order_items").select("product_id, quantity").in(
          "order_id",
          (await supabase.from("orders").select("id").eq("restaurant_id", rest.id).gte("created_at", sevenDaysAgo.toISOString())).data?.map((o: any) => o.id) || []
        ),
      ]);

      const countSales = (items: any[]) => {
        const counts: Record<string, number> = {};
        for (const item of items) {
          if (item.product_id) counts[item.product_id] = (counts[item.product_id] || 0) + (item.quantity || 1);
        }
        return Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([id]) => id);
      };

      setMostOrderedIds(countSales(allTimeSales.data || []).slice(0, 8));
      setTrendingIds(countSales(recentSales.data || []).slice(0, 8));

      setLoading(false);
    };
    fetchMenu();
  }, [slug]);



  // Facebook Pixel initialization
  useEffect(() => {
    const pixelId = (restaurant as any)?.facebook_pixel_id;
    if (!pixelId) return;
    // Avoid duplicate init
    if ((window as any).fbq) return;
    (function(f: any,b: any,e: any,v: any,n?: any,t?: any,s?: any){
      if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s);
    })(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
    (window as any).fbq('init', pixelId);
    (window as any).fbq('track', 'PageView');
  }, [restaurant]);

  // OneSignal SDK initialization
  useEffect(() => {
    if ((window as any).OneSignalDeferred) return;
    
    const initOneSignal = async () => {
      try {
        const { data } = await supabase.functions.invoke("onesignal-config");
        const appId = data?.app_id;
        if (!appId) return;

        (window as any).OneSignalDeferred = (window as any).OneSignalDeferred || [];
        const script = document.createElement("script");
        script.src = "https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js";
        script.defer = true;
        document.head.appendChild(script);
        (window as any).OneSignalDeferred.push(async function(OneSignal: any) {
          await OneSignal.init({
            appId,
            allowLocalhostAsSecureOrigin: true,
          });
        });
      } catch (e) {
        console.warn("OneSignal init error:", e);
      }
    };
    
    initOneSignal();
  }, []);

  const getOneSignalPlayerId = (): Promise<string | null> => {
    return new Promise((resolve) => {
      try {
        const w = window as any;
        if (!w.OneSignalDeferred) { resolve(null); return; }
        w.OneSignalDeferred.push(async function(OneSignal: any) {
          let playerId = OneSignal.User?.PushSubscription?.id || null;
          if (!playerId) {
            for (let i = 0; i < 10; i++) {
              await new Promise(r => setTimeout(r, 500));
              playerId = OneSignal.User?.PushSubscription?.id || null;
              if (playerId) break;
            }
          }
          console.log("✅ OneSignal player ID:", playerId);
          resolve(playerId);
        });
        // Timeout fallback
        setTimeout(() => resolve(null), 6000);
      } catch (e) {
        console.warn("OneSignal ID error:", e);
        resolve(null);
      }
    });
  };

  const fbTrack = (event: string, data?: any) => {
    if ((window as any).fbq) (window as any).fbq('track', event, data);
  };

  const getProductOptionGroups = (productId: string) => optionGroups.filter(g => g.product_id === productId);

  const getItemOptionsCost = (selectedOpts: SelectedOption[]) =>
    selectedOpts.filter(o => !o.isRequired).reduce((sum, o) => sum + o.priceAdjustment * o.quantity, 0);

  const getRequiredOptionPrice = (selectedOpts: SelectedOption[]) => {
    const requiredOpts = selectedOpts.filter(o => o.isRequired);
    if (requiredOpts.length > 0) return requiredOpts.reduce((sum, o) => sum + o.priceAdjustment, 0);
    return null; // no required option selected yet
  };

  const getItemTotalPrice = (item: CartItem) => {
    const requiredPrice = getRequiredOptionPrice(item.selectedOptions);
    const basePrice = requiredPrice !== null ? requiredPrice : item.product.price;
    return (basePrice + getItemOptionsCost(item.selectedOptions)) * item.quantity;
  };

  const openOptionsModal = (product: Product) => {
    setOptionsModalProduct(product);
    setModalSelectedOptions({});
    setModalOptionQuantities({});
    setModalQuantity(1);
    setModalNotes("");
  };

  const addToCartDirect = (product: Product) => {
    const cartKey = product.id;
    setCart(prev => {
      const existing = prev.find(i => i.cartKey === cartKey);
      if (existing) return prev.map(i => i.cartKey === cartKey ? { ...i, quantity: i.quantity + 1 } : i);
      return [...prev, { product, quantity: 1, selectedOptions: [], cartKey }];
    });
    fbTrack('AddToCart', { content_name: product.name, content_ids: [product.id], value: product.price, currency: 'MXN' });
    toast({ title: "Agregado", description: `${product.name} añadido al carrito`, duration: 1000 });
  };

  const toggleModalOption = (groupId: string, optionId: string, maxSelections: number) => {
    setModalSelectedOptions(prev => {
      const current = prev[groupId] || [];
      if (current.includes(optionId)) {
        return { ...prev, [groupId]: current.filter(id => id !== optionId) };
      }
      if (maxSelections === 1) {
        return { ...prev, [groupId]: [optionId] };
      }
      if (current.length >= maxSelections) return prev;
      return { ...prev, [groupId]: [...current, optionId] };
    });
  };

  const updateExtraOptionQty = (groupId: string, optionId: string, delta: number) => {
    const key = `${groupId}__${optionId}`;
    setModalOptionQuantities(prev => {
      const current = prev[key] || 0;
      const next = Math.max(0, current + delta);
      // Also update selected options
      setModalSelectedOptions(prevSel => {
        const currentSel = prevSel[groupId] || [];
        if (next > 0 && !currentSel.includes(optionId)) {
          return { ...prevSel, [groupId]: [...currentSel, optionId] };
        }
        if (next <= 0) {
          return { ...prevSel, [groupId]: currentSel.filter(id => id !== optionId) };
        }
        return prevSel;
      });
      return { ...prev, [key]: next };
    });
  };

  const confirmOptionsAndAdd = () => {
    if (!optionsModalProduct) return;
    const groups = getProductOptionGroups(optionsModalProduct.id);
    // Validate required groups
    for (const g of groups) {
      if (g.is_required) {
        const selected = modalSelectedOptions[g.id] || [];
        if (selected.length < Math.max(1, g.min_selections)) {
          toast({ title: "Selección requerida", description: `Selecciona al menos una opción en "${g.name}"`, variant: "destructive" });
          return;
        }
      }
    }
    const selectedOpts: SelectedOption[] = [];
    for (const g of groups) {
      const selectedIds = modalSelectedOptions[g.id] || [];
      for (const optId of selectedIds) {
        const opt = g.product_options.find(o => o.id === optId);
        if (opt) {
          const qty = g.is_required ? 1 : (modalOptionQuantities[`${g.id}__${optId}`] || 1);
          selectedOpts.push({ optionId: opt.id, name: opt.name, priceAdjustment: Number(opt.price_adjustment), groupName: g.name, isRequired: g.is_required, quantity: qty });
        }
      }
    }
    // Create unique cart key based on product + selected options
    const optKey = selectedOpts.map(o => `${o.optionId}x${o.quantity}`).sort().join("-");
    const cartKey = `${optionsModalProduct.id}__${optKey}`;

    setCart(prev => {
      const existing = prev.find(i => i.cartKey === cartKey);
      if (existing) return prev.map(i => i.cartKey === cartKey ? { ...i, quantity: i.quantity + modalQuantity } : i);
      return [...prev, { product: optionsModalProduct, quantity: modalQuantity, selectedOptions: selectedOpts, notes: modalNotes.trim() || undefined, cartKey }];
    });
    fbTrack('AddToCart', { content_name: optionsModalProduct.name, content_ids: [optionsModalProduct.id], value: optionsModalProduct.price, currency: 'MXN' });
    toast({ title: "Agregado", description: `${optionsModalProduct.name} añadido al carrito`, duration: 1000 });
    setOptionsModalProduct(null);
  };

  const updateQuantity = (cartKey: string, delta: number) => {
    setCart(prev => prev.map(i => i.cartKey === cartKey ? { ...i, quantity: Math.max(0, i.quantity + delta) } : i).filter(i => i.quantity > 0));
  };
  const removeFromCart = (cartKey: string) => setCart(prev => prev.filter(i => i.cartKey !== cartKey));

  const cartCount = cart.reduce((sum, i) => sum + i.quantity, 0);
  const cartSubtotal = cart.reduce((sum, i) => sum + getItemTotalPrice(i), 0);
  const selectedDeliveryType = deliveryTypes.find(d => d.id === selectedDelivery);
  const isDomicilioSelected = selectedDeliveryType?.name?.toLowerCase().includes("domicilio");
  
  // Distance-based fee for Domicilio
  const computedDistance = (isDomicilioSelected && restaurant?.latitude && restaurant?.longitude && customerLat && customerLng)
    ? haversineDistance(restaurant.latitude, restaurant.longitude, customerLat, customerLng)
    : null;

  const deliveryFee = (() => {
    if (!selectedDeliveryType) return 0;
    if (isDomicilioSelected) {
      const feeType = (restaurant as any)?.delivery_fee_type || 'distance';
      const baseFee = (restaurant as any)?.delivery_base_fee || 0;
      if (feeType === 'fixed') {
        return baseFee;
      }
      // Distance-based
      if (computedDistance !== null) {
        const perKm = (restaurant as any)?.delivery_price_per_km || 0;
        return Math.round((baseFee + perKm * computedDistance) * 100) / 100;
      }
      return 0;
    }
    return selectedDeliveryType.price || 0;
  })();
  const cartTotal = cartSubtotal + deliveryFee + tipAmount;
  const getCartItemQuantity = (productId: string) => cart.filter(i => i.product.id === productId).reduce((s, i) => s + i.quantity, 0);

  const submitOrder = async () => {
    if (!restaurant) return;
    if (!customerName.trim() || !customerPhone.trim() || !customerStreet.trim() || !customerColonia.trim() || !customerZip.trim()) {
      toast({ title: "Error", description: "Nombre, teléfono, calle, colonia y código postal son obligatorios", variant: "destructive" }); return;
    }
    if (customerEmail.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail.trim())) {
      toast({ title: "Error", description: "El email ingresado no es válido. Déjalo vacío si no deseas proporcionarlo.", variant: "destructive" }); return;
    }
    const selPay = paymentMethods.find(p => p.id === selectedPayment);
    if (selPay?.name?.toLowerCase().includes("efectivo") && (!cashAmount || parseFloat(cashAmount) < cartTotal)) {
      toast({ title: "Monto requerido", description: "Indica con cuánto pagarás (debe ser igual o mayor al total)", variant: "destructive" }); return;
    }
    const fullAddress = [customerStreet, customerColonia, `CP ${customerZip}`, customerReferences].filter(Boolean).join(", ");
    setSubmitting(true);
    try {
      // Get OneSignal player ID before creating order
      const playerId = await getOneSignalPlayerId();
      console.log("📱 Player ID for order:", playerId);

      const cartItemsPayload = cart.map(i => {
        const optionsText = i.selectedOptions.length > 0
          ? ` (${i.selectedOptions.map(o => o.quantity > 1 ? `${o.name} x${o.quantity}` : o.name).join(", ")})`
          : "";
        const rp = getRequiredOptionPrice(i.selectedOptions);
        const bp = rp !== null ? rp : i.product.price;
        return {
          product_id: i.product.id,
          product_name: (i.product.name + optionsText).substring(0, 300),
          product_price: bp + getItemOptionsCost(i.selectedOptions),
          quantity: i.quantity,
          option_ids: i.selectedOptions.map(o => o.optionId),
        };
      });

      const { data: orderResult, error: fnError } = await supabase.functions.invoke("create-order", {
        body: {
          restaurant_id: restaurant.id,
          customer_name: customerName.trim(),
          customer_phone: customerPhone.trim(),
          customer_email: customerEmail.trim() || null,
          customer_address: fullAddress,
          delivery_type_id: selectedDelivery || null,
          payment_method_id: selectedPayment || null,
          notes: orderNotes.trim() || null,
          cart_items: cartItemsPayload,
          customer_latitude: customerLat,
          customer_longitude: customerLng,
          onesignal_player_id: playerId,
        },
      });
      if (fnError) throw fnError;
      if (orderResult?.error) throw new Error(orderResult.error);
      const order = orderResult;

      setConfirmedItems([...cart]); setConfirmedSubtotal(cartSubtotal); setConfirmedDeliveryFee(deliveryFee); setConfirmedTotal(cartTotal);
      setConfirmedOrderId(order.id);
      setOrderConfirmed(`#${order.order_number}`); setCart([]); setCheckoutStep("confirm");
      // Save customer data for auto-fill on next visit
      try {
        localStorage.setItem(`customer_${slug}`, JSON.stringify({
          name: customerName.trim(), phone: customerPhone.trim(), email: customerEmail.trim(),
          street: customerStreet.trim(), colonia: customerColonia.trim(), zip: customerZip.trim(),
          references: customerReferences.trim(),
        }));
      } catch {}
      fbTrack('Purchase', { value: cartTotal, currency: 'MXN', content_ids: cart.map(i => i.product.id) });

      // Prompt for push notification permission (for future orders)
      try {
        const w = window as any;
        if (w.OneSignalDeferred) {
          w.OneSignalDeferred.push(async function(OneSignal: any) {
            const permission = await OneSignal.Notifications.permission;
            if (!permission) {
              await OneSignal.Notifications.requestPermission();
            }
          });
        }
      } catch (e) {
        console.warn("OneSignal permission error:", e);
      }
    } catch (err: any) {
      toast({ title: "Error al enviar pedido", description: err.message, variant: "destructive" });
    } finally { setSubmitting(false); }
  };

  const resetCheckout = () => {
    setCartOpen(false); setCheckoutStep("cart"); setOrderConfirmed(null);
    // Keep customer data for auto-fill, only reset order-specific fields
    setSelectedDelivery(null); setSelectedPayment(null); setOrderNotes("");
    setCashAmount(""); setTipAmount(0); setCustomTipAmount("");
    setCustomerLat(null); setCustomerLng(null); setCustomerLocationUrl("");
  };

  const filteredProducts = products.filter(p => {
    const matchCat = !selectedCategory || p.category_id === selectedCategory;
    const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || (p.description || "").toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });
  const featuredProducts = products.filter(p => p.is_featured && p.is_available !== false);

  // Check if restaurant is currently closed based on opening_hours
  const isRestaurantClosed = (() => {
    if (!restaurant?.opening_hours) return false;
    const hours = restaurant.opening_hours as Record<string, { open: string; close: string; enabled: boolean }>;
    const days = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
    const now = new Date();
    const dayKey = days[now.getDay()];
    const todayHours = hours[dayKey];
    if (!todayHours || !todayHours.enabled) return true;
    const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    return currentTime < todayHours.open || currentTime > todayHours.close;
  })();

  if (loading) {
    return (<div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>);
  }
  if (error || !restaurant) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background gap-4">
        <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center"><UtensilsCrossed className="w-8 h-8 text-muted-foreground" /></div>
        <h1 className="text-xl font-bold font-sans text-foreground">{error || "Restaurante no encontrado"}</h1>
        <p className="text-muted-foreground">Verifica el enlace e intenta de nuevo.</p>
      </div>
    );
  }

  // ===== OPTIONS MODAL =====
  const renderOptionsModal = () => {
    if (!optionsModalProduct) return null;
    const groups = getProductOptionGroups(optionsModalProduct.id);
    const selectedOpts: SelectedOption[] = [];
    for (const g of groups) {
      for (const optId of (modalSelectedOptions[g.id] || [])) {
        const opt = g.product_options.find(o => o.id === optId);
        if (opt) {
          const qty = g.is_required ? 1 : (modalOptionQuantities[`${g.id}__${optId}`] || 1);
          selectedOpts.push({ optionId: opt.id, name: opt.name, priceAdjustment: Number(opt.price_adjustment), groupName: g.name, isRequired: g.is_required, quantity: qty });
        }
      }
    }
    const requiredPrice = getRequiredOptionPrice(selectedOpts);
    const basePrice = requiredPrice !== null ? requiredPrice : optionsModalProduct.price;
    const unitPrice = basePrice + getItemOptionsCost(selectedOpts);
    const totalPrice = unitPrice * modalQuantity;

    return (
      <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center">
        <div className="absolute inset-0 bg-foreground/20 backdrop-blur-sm" onClick={() => setOptionsModalProduct(null)} />
        <div className="relative w-full max-w-md max-h-[85vh] bg-background rounded-t-2xl sm:rounded-2xl border border-border overflow-hidden flex flex-col animate-fade-in">
          <div className="p-0 flex-1 overflow-y-auto">
          {/* Header */}
          {optionsModalProduct.image_url && (
            <div className="relative">
              <img src={optionsModalProduct.image_url} alt={optionsModalProduct.name} className="w-full max-h-72 object-contain bg-muted/30" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
              <button onClick={() => setOptionsModalProduct(null)} className="absolute top-3 right-3 w-8 h-8 rounded-full bg-background/80 flex items-center justify-center">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
          <div className="p-5">
            <div className="flex items-start justify-between mb-1">
              <h3 className="text-lg font-black font-sans text-foreground">{optionsModalProduct.name}</h3>
              {!optionsModalProduct.image_url && (
                <button onClick={() => setOptionsModalProduct(null)} className="p-1 rounded-lg hover:bg-muted"><X className="w-4 h-4" /></button>
              )}
            </div>
            {optionsModalProduct.description && <p className="text-sm text-muted-foreground mb-4">{optionsModalProduct.description}</p>}
            <p className="text-xl font-black text-primary mb-5">${optionsModalProduct.price.toFixed(2)}</p>

            {/* Option Groups */}
            <div className="space-y-5">
              {groups.map(group => (
                <div key={group.id}>
                  <div className="flex items-center gap-2 mb-2.5">
                    <span className="text-sm font-bold text-foreground">{group.name}</span>
                    {group.is_required && <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">Obligatorio</span>}
                    {group.max_selections > 1 && <span className="text-[10px] text-muted-foreground">Máx. {group.max_selections}</span>}
                  </div>
                  <div className="space-y-1.5">
                    {group.product_options.map(opt => {
                      const isSelected = (modalSelectedOptions[group.id] || []).includes(opt.id);
                      const extraQty = modalOptionQuantities[`${group.id}__${opt.id}`] || 0;

                      if (group.is_required) {
                        // Required: radio-style selection
                        return (
                          <button key={opt.id} onClick={() => toggleModalOption(group.id, opt.id, group.max_selections)}
                            className={`w-full flex items-center justify-between p-3 rounded-xl border text-left transition-all duration-200 ${isSelected ? "border-primary/50 bg-primary/5" : "border-border hover:border-primary/20"}`}>
                            <div className="flex items-center gap-3">
                              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${isSelected ? "border-primary bg-primary" : "border-muted-foreground/30"}`}>
                                {isSelected && <CheckCircle2 className="w-3 h-3 text-primary-foreground" />}
                              </div>
                              <span className="text-sm font-medium text-foreground">{opt.name}</span>
                            </div>
                            {Number(opt.price_adjustment) !== 0 && (
                              <span className="text-sm font-semibold text-primary">${Number(opt.price_adjustment).toFixed(2)}</span>
                            )}
                          </button>
                        );
                      }

                      // Non-required: quantity selector
                      return (
                        <div key={opt.id}
                          className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all duration-200 ${extraQty > 0 ? "border-primary/50 bg-primary/5" : "border-border"}`}>
                          <div className="flex-1 min-w-0">
                            <span className="text-sm font-medium text-foreground">{opt.name}</span>
                            {Number(opt.price_adjustment) !== 0 && (
                              <span className="text-sm font-semibold text-primary ml-2">+${Number(opt.price_adjustment).toFixed(2)}</span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            {extraQty > 0 && (
                              <button onClick={() => updateExtraOptionQty(group.id, opt.id, -1)}
                                className="w-7 h-7 rounded-lg bg-muted border border-border flex items-center justify-center">
                                <Minus className="w-3 h-3" />
                              </button>
                            )}
                            {extraQty > 0 && <span className="w-5 text-center text-sm font-bold text-foreground">{extraQty}</span>}
                            <button onClick={() => updateExtraOptionQty(group.id, opt.id, 1)}
                              className="w-7 h-7 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center text-primary">
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {/* Comentarios */}
            <div className="mt-5">
              <label className="text-sm font-bold text-foreground block mb-2">Comentarios</label>
              <textarea
                value={modalNotes}
                onChange={e => setModalNotes(e.target.value)}
                placeholder="Instrucciones especiales del producto."
                className="w-full rounded-xl border border-border bg-background p-3 text-sm text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-2 focus:ring-primary/30"
                rows={3}
              />
            </div>

            {/* Cantidad del producto */}
            <div className="mt-5">
              <div className="flex items-center gap-3">
                <button onClick={() => setModalQuantity(Math.max(1, modalQuantity - 1))} className="w-9 h-9 rounded-full bg-muted border border-border flex items-center justify-center"><Minus className="w-4 h-4" /></button>
                <span className="text-lg font-bold w-8 text-center">{modalQuantity}</span>
                <button onClick={() => setModalQuantity(modalQuantity + 1)} className="w-9 h-9 rounded-full bg-muted border border-border flex items-center justify-center"><Plus className="w-4 h-4" /></button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Cantidad del producto</p>
            </div>
          </div>
          </div>

          {/* Footer */}
          <div className="p-5 border-t border-border shrink-0">
            <button onClick={confirmOptionsAndAdd}
              className="w-full py-3.5 rounded-xl font-semibold text-primary-foreground bg-gradient-to-r from-primary to-accent hover:shadow-glow transition-all duration-300 hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2">
              <Plus className="w-4 h-4" /> Agregar — ${totalPrice.toFixed(2)}
            </button>
          </div>
        </div>
      </div>
    );
  };

  // ===== DRAWER =====
  const renderCartDrawer = () => (
    <div className={`fixed inset-0 z-[60] transition-all duration-300 ${cartOpen ? "visible" : "invisible"}`}>
      <div className={`absolute inset-0 bg-foreground/20 backdrop-blur-sm transition-opacity ${cartOpen ? "opacity-100" : "opacity-0"}`} onClick={() => { if (checkoutStep === "cart") setCartOpen(false); }} />
      <div className={`absolute right-0 top-0 bottom-0 w-full max-w-md bg-background border-l border-border transition-transform duration-300 ${cartOpen ? "translate-x-0" : "translate-x-full"} flex flex-col`}>
        <div className="p-5 border-b border-border flex items-center justify-between shrink-0">
          {checkoutStep !== "cart" && checkoutStep !== "confirm" && (
            <button onClick={() => setCheckoutStep(checkoutStep === "info" ? "delivery" : "cart")} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
              <ArrowLeft className="w-5 h-5 text-muted-foreground" />
            </button>
          )}
          <h2 className="text-lg font-bold font-sans flex-1 text-center text-foreground">
            {checkoutStep === "cart" && "Tu Pedido"}
            {checkoutStep === "delivery" && "Envío y Pago"}
            {checkoutStep === "info" && "Tus Datos"}
            {checkoutStep === "confirm" && "¡Pedido Confirmado!"}
          </h2>
          <button onClick={resetCheckout} className="p-1.5 rounded-lg hover:bg-muted transition-colors"><X className="w-5 h-5 text-muted-foreground" /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-5">
          {checkoutStep === "cart" && renderCartStep()}
          {checkoutStep === "delivery" && renderDeliveryStep()}
          {checkoutStep === "info" && renderInfoStep()}
          {checkoutStep === "confirm" && renderConfirmStep()}
        </div>
        {checkoutStep !== "confirm" && cart.length > 0 && (
          <div className="p-5 border-t border-border shrink-0 space-y-3">
            <div className="flex justify-between text-sm text-muted-foreground"><span>Subtotal</span><span>${cartSubtotal.toFixed(2)}</span></div>
            {deliveryFee > 0 && <div className="flex justify-between text-sm text-muted-foreground"><span>Envío</span><span>${deliveryFee.toFixed(2)}</span></div>}
            {tipAmount > 0 && <div className="flex justify-between text-sm text-muted-foreground"><span>Propina</span><span>${tipAmount.toFixed(2)}</span></div>}
            <div className="flex justify-between text-lg font-bold text-foreground"><span>Total</span><span className="text-primary">${cartTotal.toFixed(2)}</span></div>
            <button onClick={() => {
              if (checkoutStep === "cart") { fbTrack('InitiateCheckout', { value: cartTotal, currency: 'MXN' }); setCheckoutStep("delivery"); }
              else if (checkoutStep === "delivery") {
                if (!selectedDelivery) {
                  toast({ title: "Tipo de envío requerido", description: "Selecciona una opción de envío (Domicilio, Recoger, etc.)", variant: "destructive" });
                  return;
                }
                if (!selectedPayment) {
                  toast({ title: "Método de pago requerido", description: "Selecciona un método de pago", variant: "destructive" });
                  return;
                }
                const feeType = (restaurant as any)?.delivery_fee_type || 'distance';
                if (isDomicilioSelected && feeType === 'distance' && !customerLat) {
                  toast({ title: "Ubicación requerida", description: "Debes compartir tu ubicación para envío a domicilio", variant: "destructive" });
                  return;
                }
                const selPay = paymentMethods.find(p => p.id === selectedPayment);
                if (selPay?.name?.toLowerCase().includes("efectivo") && (!cashAmount || parseFloat(cashAmount) < cartTotal)) {
                  toast({ title: "Monto requerido", description: "Indica con cuánto pagarás (debe ser igual o mayor al total)", variant: "destructive" });
                  return;
                }
                setCheckoutStep("info");
              }
              else if (checkoutStep === "info") submitOrder();
            }}
              disabled={submitting}
              className="w-full py-3.5 rounded-xl font-semibold text-primary-foreground bg-gradient-to-r from-primary to-accent hover:shadow-glow transition-all duration-300 hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50">
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {checkoutStep === "cart" && "Continuar"}{checkoutStep === "delivery" && "Siguiente"}{checkoutStep === "info" && (submitting ? "Enviando..." : "Confirmar Pedido")}
              {checkoutStep !== "info" && <ArrowRight className="w-4 h-4" />}
            </button>
          </div>
        )}
      </div>
    </div>
  );

  const renderCartStep = () => {
    if (cart.length === 0) return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <ShoppingBag className="w-12 h-12 text-muted-foreground/40" />
        <p className="text-muted-foreground">Tu carrito está vacío</p>
        <button onClick={() => setCartOpen(false)} className="text-sm text-primary hover:underline">Explorar menú</button>
      </div>
    );
    const upsellProducts = products.filter(p => p.is_upsell && p.is_available !== false && !cart.some(c => c.product.id === p.id));
    return (
      <div className="space-y-4">
        <div className="space-y-3">
          {cart.map(item => (
            <div key={item.cartKey} className="flex items-start gap-3 p-3 rounded-xl border border-border bg-muted/30">
              {item.product.image_url && <img src={item.product.image_url} alt={item.product.name} className="w-14 h-14 rounded-lg object-cover shrink-0" />}
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-bold font-sans truncate text-foreground">{item.product.name}</h4>
                {item.selectedOptions.length > 0 && (
                  <p className="text-[11px] text-muted-foreground mt-0.5">{item.selectedOptions.map(o => o.quantity > 1 ? `${o.name} x${o.quantity}` : o.name).join(", ")}</p>
                )}
                <p className="text-sm text-primary font-semibold mt-0.5">${getItemTotalPrice(item).toFixed(2)}</p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button onClick={() => updateQuantity(item.cartKey, -1)} className="w-7 h-7 rounded-lg bg-muted border border-border flex items-center justify-center hover:bg-muted/80 transition-colors"><Minus className="w-3 h-3 text-foreground" /></button>
                <span className="w-6 text-center text-sm font-bold text-foreground">{item.quantity}</span>
                <button onClick={() => updateQuantity(item.cartKey, 1)} className="w-7 h-7 rounded-lg bg-muted border border-border flex items-center justify-center hover:bg-muted/80 transition-colors"><Plus className="w-3 h-3 text-foreground" /></button>
                <button onClick={() => removeFromCart(item.cartKey)} className="w-7 h-7 rounded-lg flex items-center justify-center text-destructive hover:bg-destructive/10 transition-colors ml-1"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          ))}
        </div>

        {/* Upsell suggestions */}
        {upsellProducts.length > 0 && (
          <div className="pt-3">
            <div className="relative border-2 border-dashed border-primary/40 rounded-2xl p-4 bg-gradient-to-br from-primary/5 via-primary/[0.02] to-transparent">
              <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 animate-boing z-10">
                <span className="text-xs font-bold tracking-[0.1em] uppercase text-primary-foreground bg-primary px-4 py-1 rounded-full shadow-md whitespace-nowrap">🎯 ¿Te gustaría añadir?</span>
              </div>
              <div className="space-y-2 mt-1">
                {upsellProducts.slice(0, 3).map(p => (
                  <button key={p.id} onClick={() => {
                    const groups = getProductOptionGroups(p.id);
                    if (groups.length > 0) { openOptionsModal(p); setCartOpen(false); } else { addToCartDirect(p); }
                  }}
                    className="w-full flex items-center gap-3 p-3 rounded-xl border border-primary/20 bg-background hover:bg-primary/10 hover:border-primary/40 transition-all duration-200 text-left shadow-sm">
                    {p.image_url && <img src={p.image_url} alt={p.name} className="w-12 h-12 rounded-lg object-cover shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-foreground truncate">{p.name}</p>
                      {p.description && <p className="text-[11px] text-muted-foreground truncate">{p.description}</p>}
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-sm font-bold text-primary">${p.price.toFixed(2)}</span>
                      <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center">
                        <Plus className="w-3.5 h-3.5 text-primary" />
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const requestGeolocation = () => {
    if (!navigator.geolocation) {
      toast({ title: "No disponible", description: "Tu navegador no soporta geolocalización", variant: "destructive" });
      return;
    }
    setGettingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCustomerLat(pos.coords.latitude);
        setCustomerLng(pos.coords.longitude);
        const url = `https://maps.google.com/maps?q=${pos.coords.latitude},${pos.coords.longitude}`;
        setCustomerLocationUrl(url);
        setGettingLocation(false);
        toast({ title: "Ubicación obtenida", description: "Tu ubicación se usará para calcular el envío" });
      },
      () => {
        setGettingLocation(false);
        toast({ title: "Error", description: "No se pudo obtener tu ubicación. Es obligatoria para envío a domicilio.", variant: "destructive" });
      },
      { enableHighAccuracy: true }
    );
  };

  const renderDeliveryStep = () => (
    <div className="space-y-6">
      {deliveryTypes.length > 0 && (
        <div>
          <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-3 block">Tipo de Envío</label>
          <div className="space-y-2">
            {deliveryTypes.map(dt => (
              <button key={dt.id} onClick={() => setSelectedDelivery(dt.id)}
                className={`w-full p-4 rounded-xl border text-left transition-all duration-300 ${selectedDelivery === dt.id ? "border-primary/50 bg-primary/5 shadow-soft" : "border-border bg-card hover:border-primary/20"}`}>
                <div className="flex justify-between items-center">
                  <div><p className="font-bold font-sans text-sm text-foreground">{dt.name}</p>{dt.description && <p className="text-xs text-muted-foreground mt-0.5">{dt.description}</p>}</div>
                  {dt.name.toLowerCase().includes("domicilio") ? (
                    (restaurant as any)?.delivery_fee_type === 'fixed'
                      ? <span className="text-sm font-bold text-primary">{(restaurant as any)?.delivery_base_fee ? `$${(restaurant as any).delivery_base_fee}` : "Gratis"}</span>
                      : <span className="text-xs font-medium text-muted-foreground">Según distancia</span>
                  ) : (
                    <span className="text-sm font-bold text-primary">{dt.price ? `$${dt.price}` : "Gratis"}</span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Geolocation for Domicilio - only for distance-based */}
      {isDomicilioSelected && (restaurant as any)?.delivery_fee_type !== 'fixed' && (
        <div className="space-y-3">
          <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-2 block">📍 Tu Ubicación (obligatoria)</label>
          <p className="text-xs text-muted-foreground">Necesitamos tu ubicación para calcular el costo de envío.</p>
          <button
            type="button"
            onClick={requestGeolocation}
            disabled={gettingLocation}
            className={`w-full py-3.5 rounded-xl border-2 border-dashed text-sm font-semibold transition-all duration-300 flex items-center justify-center gap-2.5 ${
              customerLat
                ? "border-[hsl(142,70%,40%)] bg-[hsl(142,70%,40%)]/10 text-[hsl(142,70%,40%)] shadow-[0_0_20px_hsl(142,70%,40%/0.15)]"
                : "border-primary/40 bg-gradient-to-r from-primary/5 to-accent/5 text-primary hover:border-primary hover:shadow-[0_0_20px_hsl(var(--primary)/0.2)] hover:scale-[1.01] active:scale-[0.99]"
            }`}
          >
            <MapPin className={`w-5 h-5 ${!customerLat && !gettingLocation ? "animate-bounce" : ""} ${gettingLocation ? "animate-spin" : ""}`} />
            {gettingLocation ? "Obteniendo ubicación..." : customerLat ? "✓ Ubicación compartida" : "📍 Compartir mi ubicación"}
          </button>
          {customerLat && computedDistance !== null && (
            <div className="p-3 rounded-xl bg-primary/5 border border-primary/20 space-y-1">
              <p className="text-sm font-semibold text-foreground">
                Distancia: <span className="text-primary">{computedDistance.toFixed(1)} km</span>
              </p>
              <p className="text-sm font-semibold text-foreground">
                Costo de envío: <span className="text-primary">${deliveryFee.toFixed(2)}</span>
              </p>
            </div>
          )}
          {!customerLat && (
            <p className="text-xs text-destructive font-medium">⚠️ Debes compartir tu ubicación para continuar</p>
          )}
        </div>
      )}
      {/* Fixed delivery fee info */}
      {isDomicilioSelected && (restaurant as any)?.delivery_fee_type === 'fixed' && (
        <div className="p-3 rounded-xl bg-primary/5 border border-primary/20">
          <p className="text-sm font-semibold text-foreground">
            Costo de envío: <span className="text-primary">${deliveryFee.toFixed(2)}</span>
          </p>
        </div>
      )}
      {paymentMethods.length > 0 && (
        <div>
          <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-3 block">Método de Pago</label>
          <div className="space-y-2">
            {paymentMethods.map(pm => (
              <button key={pm.id} onClick={() => setSelectedPayment(pm.id)}
                className={`w-full p-4 rounded-xl border text-left transition-all duration-300 ${selectedPayment === pm.id ? "border-primary/50 bg-primary/5 shadow-soft" : "border-border bg-card hover:border-primary/20"}`}>
                <div className="flex items-center gap-3">
                  <CreditCard className="w-5 h-5 text-muted-foreground" />
                  <div><p className="font-bold font-sans text-sm text-foreground">{pm.name}</p>{pm.description && <p className="text-xs text-muted-foreground mt-0.5">{pm.description}</p>}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Cash payment amount - only when "Efectivo" is selected */}
      {(() => {
        const selPay = paymentMethods.find(p => p.id === selectedPayment);
        if (selPay?.name?.toLowerCase().includes("efectivo")) {
          const change = cashAmount ? parseFloat(cashAmount) - cartTotal : 0;
          return (
            <div className="p-4 rounded-xl bg-accent/10 border-2 border-accent/30">
              <label className="text-xs font-bold tracking-[0.15em] uppercase text-accent mb-3 block">💵 ¿Con cuánto pagarás? *</label>
              <input
                type="number"
                inputMode="decimal"
                value={cashAmount}
                onChange={e => setCashAmount(e.target.value)}
                placeholder={`Total: $${cartTotal.toFixed(2)}`}
                className="w-full px-4 py-3 rounded-xl bg-background border-2 border-accent/40 text-sm font-semibold text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-accent focus:ring-2 focus:ring-accent/30 transition-all"
              />
              {cashAmount && parseFloat(cashAmount) >= cartTotal && (
                <div className="mt-2 p-3 rounded-xl bg-primary/5 border border-primary/20">
                  <p className="text-sm font-semibold text-foreground">Tu cambio: <span className="text-primary">${change.toFixed(2)}</span></p>
                </div>
              )}
              {cashAmount && parseFloat(cashAmount) < cartTotal && (
                <p className="mt-2 text-xs text-destructive font-medium">El monto debe ser igual o mayor al total</p>
              )}
            </div>
          );
        }
        return null;
      })()}

      {/* Tip selector */}
      <div>
        <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-3 block">Propina (opcional)</label>
        <div className="grid grid-cols-4 gap-2">
          {[10, 15, 30].map(amount => (
            <button
              key={amount}
              onClick={() => { setTipAmount(amount); setCustomTipAmount(""); }}
              className={`py-3 rounded-xl border text-sm font-bold transition-all duration-300 ${tipAmount === amount && !customTipAmount ? "border-primary/50 bg-primary/10 text-primary shadow-soft" : "border-border bg-card text-foreground hover:border-primary/20"}`}
            >
              ${amount}
            </button>
          ))}
          <button
            onClick={() => { setTipAmount(0); setCustomTipAmount(""); }}
            className={`py-3 rounded-xl border text-sm font-bold transition-all duration-300 ${tipAmount === 0 && !customTipAmount ? "border-primary/50 bg-primary/10 text-primary shadow-soft" : "border-border bg-card text-foreground hover:border-primary/20"}`}
          >
            $0
          </button>
        </div>
        <div className="mt-2">
          <input
            type="number"
            inputMode="decimal"
            value={customTipAmount}
            onChange={e => {
              setCustomTipAmount(e.target.value);
              const val = parseFloat(e.target.value);
              setTipAmount(val > 0 ? val : 0);
            }}
            placeholder="Otro monto..."
            className="w-full px-4 py-3 rounded-xl bg-muted/50 border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-all"
          />
        </div>
      </div>
    </div>
  );

  const inputClass = "w-full pl-10 pr-4 py-3 rounded-xl bg-muted/50 border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-all";
  const inputClassNoIcon = "w-full px-4 py-3 rounded-xl bg-muted/50 border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-all";

  const renderInfoStep = () => (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-2 block">Nombre *</label>
        <div className="relative"><User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="Tu nombre completo" maxLength={100} className={inputClass} /></div>
      </div>
      <div>
        <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-2 block">Teléfono *</label>
        <div className="relative"><Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} placeholder="Tu número de teléfono" type="tel" maxLength={20} className={inputClass} /></div>
      </div>
      <div>
        <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-2 block">Email (opcional)</label>
        <input value={customerEmail} onChange={e => setCustomerEmail(e.target.value)} placeholder="correo@ejemplo.com" type="email" maxLength={255} className={inputClassNoIcon} />
      </div>
      <div>
        <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-2 block">Calle y Número *</label>
        <div className="relative"><MapPinned className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={customerStreet} onChange={e => setCustomerStreet(e.target.value)} placeholder="Ej: Av. Reforma #123" maxLength={200} className={inputClass} /></div>
      </div>
      <div>
        <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-2 block">Colonia *</label>
        <input value={customerColonia} onChange={e => setCustomerColonia(e.target.value)} placeholder="Ej: Centro" maxLength={100} className={inputClassNoIcon} />
      </div>
      <div>
        <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-2 block">Código Postal *</label>
        <input value={customerZip} onChange={e => setCustomerZip(e.target.value)} placeholder="Ej: 06600" maxLength={10} inputMode="numeric" className={inputClassNoIcon} />
      </div>
      <div>
        <label className="text-xs font-semibold tracking-[0.15em] uppercase text-primary mb-2 block">Referencias (opcional)</label>
        <textarea value={customerReferences} onChange={e => setCustomerReferences(e.target.value)} placeholder="Ej: Casa azul, entre calle 5 y 7" rows={2} maxLength={300}
          className="w-full px-4 py-3 rounded-xl bg-muted/50 border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-all resize-none" />
      </div>
      {/* Location already shared from delivery step */}
      {customerLocationUrl && (
        <div className="flex items-center gap-2 p-3 rounded-xl bg-primary/5 border border-primary/20">
          <MapPin className="w-4 h-4 text-primary shrink-0" />
          <span className="text-sm text-foreground">✓ Ubicación compartida</span>
        </div>
      )}
    </div>
  );

  const buildWhatsAppMessage = () => {
    if (!restaurant || !orderConfirmed) return "";
    const lines = [`🛒 *Nuevo Pedido ${orderConfirmed}*`, `📍 *${restaurant.name}*`, ``, `👤 *Cliente:* ${customerName}`, `📱 *Tel:* ${customerPhone}`];
    if (customerEmail) lines.push(`📧 *Email:* ${customerEmail}`);
    const fullAddr = [customerStreet, customerColonia, `CP ${customerZip}`, customerReferences].filter(Boolean).join(", ");
    if (fullAddr) lines.push(`📍 *Dirección:* ${fullAddr}`);
    if (customerLocationUrl) lines.push(`📌 *Ubicación:* ${customerLocationUrl}`);
    lines.push(``, `📋 *Productos:*`);
    confirmedItems.forEach(i => {
      const optText = i.selectedOptions.length > 0 ? ` (${i.selectedOptions.map(o => o.quantity > 1 ? `${o.name} x${o.quantity}` : o.name).join(", ")})` : "";
      lines.push(`  • ${i.quantity}x ${i.product.name}${optText} — $${getItemTotalPrice(i).toFixed(2)}`);
    });
    lines.push(``, `💰 Subtotal: $${confirmedSubtotal.toFixed(2)}`);
    if (confirmedDeliveryFee > 0) lines.push(`🚚 Envío: $${confirmedDeliveryFee.toFixed(2)}`);
    if (tipAmount > 0) lines.push(`🎁 Propina: $${tipAmount.toFixed(2)}`);
    lines.push(`🔥 *Total: $${confirmedTotal.toFixed(2)}*`);
    const selDel = deliveryTypes.find(d => d.id === selectedDelivery);
    const selPay = paymentMethods.find(p => p.id === selectedPayment);
    if (selDel) lines.push(`\n🚚 *Envío:* ${selDel.name}`);
    if (selPay) {
      lines.push(`💳 *Pago:* ${selPay.name}`);
      if (selPay.name.toLowerCase().includes("efectivo") && cashAmount) {
        lines.push(`💵 *Paga con:* $${parseFloat(cashAmount).toFixed(2)}`);
        const change = parseFloat(cashAmount) - confirmedTotal;
        if (change > 0) lines.push(`💱 *Cambio:* $${change.toFixed(2)}`);
      }
    }
    return lines.join("\n");
  };

  const sendToWhatsApp = () => {
    if (!restaurant?.phone) { toast({ title: "Sin número", description: "El restaurante no tiene número de WhatsApp configurado", variant: "destructive" }); return; }
    const phone = restaurant.phone.replace(/\D/g, "");
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(buildWhatsAppMessage())}`, "_blank");
  };

  const renderConfirmStep = () => (
    <div className="flex flex-col items-center justify-center py-12 gap-5 text-center">
      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[hsl(142,76%,36%)] to-[hsl(170,80%,40%)] flex items-center justify-center shadow-[0_0_40px_hsl(142,76%,36%/0.2)]">
        <CheckCircle2 className="w-10 h-10 text-white" />
      </div>
      <h3 className="text-2xl font-black font-sans text-foreground">
        ¡Confirma tu pedido!
      </h3>
      <p className="text-muted-foreground text-sm max-w-xs">
        Tu pedido <span className="text-foreground font-bold">{orderConfirmed}</span> ha sido recibido. Envíalo por WhatsApp para confirmación inmediata.
      </p>
      <button onClick={sendToWhatsApp}
        className="animate-bounce-boing flex items-center gap-3 px-7 py-3.5 rounded-xl font-semibold text-white bg-[hsl(142,70%,40%)] hover:bg-[hsl(142,70%,35%)] hover:shadow-[0_0_20px_hsl(142,70%,40%/0.3)] transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]">
        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
        Enviar por WhatsApp
      </button>
      {confirmedOrderId && (
        <button onClick={() => navigate(`/order/tracking/${confirmedOrderId}`)}
          className="flex items-center gap-2 px-7 py-3 rounded-xl font-semibold text-primary border-2 border-primary hover:bg-primary/5 transition-all duration-300">
          📍 Seguir mi pedido
        </button>
      )}
      <button onClick={resetCheckout} className="mt-2 px-6 py-3 rounded-xl font-medium text-muted-foreground border border-border hover:border-foreground/20 hover:text-foreground transition-all">Volver al menú</button>
    </div>
  );

  // Helper to render add button for product cards
  const renderProductAddButton = (product: Product) => {
    if (product.is_available === false || isRestaurantClosed) {
      return (
        <span className="px-3 py-1.5 rounded-lg bg-muted text-muted-foreground text-xs font-semibold">
          {product.is_available === false ? "Agotado" : "Cerrado"}
        </span>
      );
    }
    const qty = getCartItemQuantity(product.id);
    const hasOptions = getProductOptionGroups(product.id).length > 0;

    if (hasOptions) {
      return (
        <button onClick={() => openOptionsModal(product)} className="w-9 h-9 rounded-xl bg-gradient-to-r from-primary to-accent flex items-center justify-center hover:shadow-soft hover:scale-105 transition-all relative">
          <Plus className="w-4 h-4 text-primary-foreground" />
          {qty > 0 && (
            <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-foreground text-background text-[10px] font-bold flex items-center justify-center">{qty}</span>
          )}
        </button>
      );
    }

    if (qty > 0) {
      return (
        <div className="flex items-center gap-1.5">
          <button onClick={() => updateQuantity(product.id, -1)} className="w-8 h-8 rounded-lg bg-muted border border-border flex items-center justify-center hover:bg-muted/80 transition-colors"><Minus className="w-3.5 h-3.5" /></button>
          <span className="w-6 text-center text-sm font-bold">{qty}</span>
          <button onClick={() => updateQuantity(product.id, 1)} className="w-8 h-8 rounded-lg bg-muted border border-border flex items-center justify-center hover:bg-muted/80 transition-colors"><Plus className="w-3.5 h-3.5" /></button>
        </div>
      );
    }

    return (
      <button onClick={() => openOptionsModal(product)} className="w-9 h-9 rounded-xl bg-gradient-to-r from-primary to-accent flex items-center justify-center hover:shadow-soft hover:scale-105 transition-all">
        <Plus className="w-4 h-4 text-primary-foreground" />
      </button>
    );
  };

  return (
    <div className="min-h-screen bg-muted/30 text-foreground">
      {renderOptionsModal()}
      {renderCartDrawer()}

      {/* Schedule Modal */}
      {showSchedule && (
        <div className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center">
          <div className="absolute inset-0 bg-foreground/20 backdrop-blur-sm" onClick={() => setShowSchedule(false)} />
          <div className="relative w-full max-w-sm bg-background rounded-t-2xl sm:rounded-2xl border border-border p-5 animate-fade-in">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold font-sans text-foreground">Horario</h3>
              <button onClick={() => setShowSchedule(false)} className="p-1 rounded-lg hover:bg-muted"><X className="w-4 h-4" /></button>
            </div>
            {restaurant.opening_hours ? (
              <div className="space-y-2">
                {["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"].map(day => {
                  const h = (restaurant.opening_hours as Record<string, { open: string; close: string; enabled: boolean }>)?.[day];
                  const isToday = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"][new Date().getDay()] === day;
                  return (
                    <div key={day} className={`flex items-center justify-between py-2 px-3 rounded-lg ${isToday ? "bg-primary/5 border border-primary/20" : ""}`}>
                      <span className={`text-sm capitalize ${isToday ? "font-bold text-foreground" : "text-muted-foreground"}`}>{day}</span>
                      <span className={`text-sm ${isToday ? "font-bold text-foreground" : "text-muted-foreground"}`}>
                        {h?.enabled ? `${h.open} - ${h.close}` : "Cerrado"}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">No hay horario configurado</p>
            )}
          </div>
        </div>
      )}

      {/* Header with cover + rounded card overlay */}
      <div className="relative">
        {/* Cover Photo */}
        <div className="w-full h-44 sm:h-60 overflow-hidden bg-muted relative">
          {restaurant.cover_url ? (
            <img src={restaurant.cover_url} alt="" className="w-full h-full object-cover object-center" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-muted to-muted-foreground/10" />
          )}
          {/* Social media icons - left side */}
          {(restaurant.instagram_url || restaurant.facebook_url || restaurant.website_url) && (
            <div className="absolute top-3 left-3 flex items-center gap-2">
              {restaurant.instagram_url && (
                <a
                  href={restaurant.instagram_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 flex items-center justify-center hover:bg-background transition-colors shadow-sm"
                  aria-label="Instagram"
                >
                  <svg className="w-5 h-5 text-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>
                </a>
              )}
              {restaurant.facebook_url && (
                <a
                  href={restaurant.facebook_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 flex items-center justify-center hover:bg-background transition-colors shadow-sm"
                  aria-label="Facebook"
                >
                  <svg className="w-5 h-5 text-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                </a>
              )}
              {restaurant.website_url && (
                <a
                  href={restaurant.website_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 flex items-center justify-center hover:bg-background transition-colors shadow-sm"
                  aria-label="Sitio Web"
                >
                  <svg className="w-5 h-5 text-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                </a>
              )}
            </div>
          )}
          {/* Cover action icons - right side */}
          <div className="absolute top-3 right-3 flex items-center gap-2">
            <button
              onClick={() => setShowSchedule(true)}
              className="w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 flex items-center justify-center hover:bg-background transition-colors shadow-sm"
              aria-label="Horario"
            >
              <Clock className="w-5 h-5 text-foreground" />
            </button>
            {restaurant.address && (
              <button
                onClick={() => {
                  window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(restaurant.address!)}`, "_blank");
                }}
                className="w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 flex items-center justify-center hover:bg-background transition-colors shadow-sm"
                aria-label="Ubicación"
              >
                <MapPin className="w-5 h-5 text-foreground" />
              </button>
            )}
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: restaurant.name, url: window.location.href });
                } else {
                  navigator.clipboard.writeText(window.location.href);
                  toast({ title: "Enlace copiado", description: "El enlace del menú se copió al portapapeles" });
                }
              }}
              className="w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 flex items-center justify-center hover:bg-background transition-colors shadow-sm"
              aria-label="Compartir"
            >
              <Share2 className="w-5 h-5 text-foreground" />
            </button>
          </div>
        </div>

        {/* Rounded white card overlapping the cover */}
        <div className="relative -mt-6 mx-0 sm:mx-auto sm:max-w-3xl">
          <div className="bg-background rounded-t-3xl pt-1 pb-4 px-4">
            {/* Centered Logo */}
            <div className="flex flex-col items-center -mt-14">
              <div className="w-28 h-28 rounded-full bg-background flex items-center justify-center overflow-hidden shadow-elevated border-4 border-background shrink-0">
                {restaurant.logo_url ? (
                  <img src={restaurant.logo_url} alt={restaurant.name} className="w-full h-full object-cover" />
                ) : (
                  <UtensilsCrossed className="w-8 h-8 text-primary" />
                )}
              </div>
              <h1 className="text-lg md:text-2xl font-sans font-black tracking-tight text-foreground mt-3 text-center">{restaurant.name}</h1>
              {restaurant.description && <p className="text-xs text-muted-foreground mt-1 text-center max-w-xs">{restaurant.description}</p>}
            </div>

            {/* Delivery / Pickup toggle */}
            {deliveryTypes.length > 0 && (
              <div className="flex items-center justify-center gap-0 mt-4 mb-3 border border-border rounded-full overflow-hidden w-fit mx-auto">
                <button
                  onClick={() => setDeliveryMode("delivery")}
                  className={`px-5 py-2 text-sm font-medium transition-all duration-200 ${deliveryMode === "delivery" ? "text-primary bg-primary/5" : "text-muted-foreground hover:text-foreground"}`}
                >
                  A domicilio
                </button>
                <div className="w-px h-5 bg-border" />
                <button
                  onClick={() => setDeliveryMode("pickup")}
                  className={`px-5 py-2 text-sm font-medium transition-all duration-200 ${deliveryMode === "pickup" ? "text-primary bg-primary/5" : "text-muted-foreground hover:text-foreground"}`}
                >
                  Para recoger
                </button>
              </div>
            )}

            {/* Delivery time + cost info */}
            {deliveryMode === "delivery" && (
              <div className="flex items-center justify-center gap-6 text-center mb-2">
                {(restaurant as any).delivery_time && (
                  <div>
                    <p className="text-[11px] text-muted-foreground">Tiempo envío</p>
                    <p className="text-sm font-bold text-foreground">{(restaurant as any).delivery_time}</p>
                  </div>
                )}
                {(restaurant as any).delivery_time && deliveryTypes.length > 0 && (
                  <div className="w-px h-8 bg-border" />
                )}
                {deliveryTypes.length > 0 && (
                  <div>
                    <p className="text-[11px] text-muted-foreground">Costo envío</p>
                    <p className="text-sm font-bold text-foreground">
                      {(restaurant as any)?.delivery_fee_type === 'fixed'
                        ? ((restaurant as any)?.delivery_base_fee ? `$${Number((restaurant as any).delivery_base_fee).toFixed(2)}` : "Gratis")
                        : restaurant?.delivery_price_per_km && restaurant.delivery_price_per_km > 0
                          ? "Según distancia"
                          : (() => {
                              const prices = deliveryTypes.map(d => d.price || 0);
                              const min = Math.min(...prices);
                              const max = Math.max(...prices);
                              if (min === 0 && max === 0) return "Gratis";
                              if (min === max) return `$${min.toFixed(2)}`;
                              return `$${min.toFixed(2)} - $${max.toFixed(2)}`;
                            })()
                      }
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Closed Banner */}
      {isRestaurantClosed && (
        <div className="bg-destructive/10 border-b border-destructive/20 px-4 py-3 text-center">
          <p className="text-sm font-semibold text-destructive">🕐 Estamos cerrados en este momento. Puedes ver el menú pero no realizar pedidos.</p>
        </div>
      )}

      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-xl border-b border-border sm:max-w-3xl sm:mx-auto">
        <div className="max-w-3xl mx-auto px-4 py-3 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input placeholder="Buscar en el menú..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-all" />
          </div>
          {categories.length > 0 && (
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              <button onClick={() => setSelectedCategory(null)}
                className={`shrink-0 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${selectedCategory === null ? "bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-soft" : "bg-muted/50 border border-border text-muted-foreground hover:text-foreground hover:border-foreground/20"}`}>
                Todos
              </button>
              {categories.map(c => (
                <button key={c.id} onClick={() => setSelectedCategory(c.id)}
                  className={`shrink-0 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${selectedCategory === c.id ? "bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-soft" : "bg-muted/50 border border-border text-muted-foreground hover:text-foreground hover:border-foreground/20"}`}>
                  {c.icon && <span className="mr-1.5">{c.icon}</span>}{c.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <main className="max-w-3xl mx-auto px-4 py-8">
        {/* Más pedidos - based on real all-time sales */}
        {!selectedCategory && !searchQuery && mostOrderedIds.length > 0 && (() => {
          const mostOrderedProducts = mostOrderedIds.map(id => products.find(p => p.id === id)).filter((p): p is Product => !!p && p.is_available !== false);
          if (mostOrderedProducts.length === 0) return null;
          return (
            <section className="mb-8">
              <span className="text-xs font-semibold tracking-[0.2em] uppercase text-primary mb-4 block">⭐ Más pedidos</span>
              <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
                {mostOrderedProducts.map(product => (
                  <div key={product.id} className="group shrink-0 w-60 rounded-2xl border border-border bg-card overflow-hidden hover:shadow-elevated transition-all duration-500 hover:-translate-y-1">
                    {product.image_url && (
                      <div className="relative h-36 overflow-hidden cursor-pointer" onClick={() => openOptionsModal(product)}>
                        <img src={product.image_url} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md bg-foreground/70 text-[10px] font-bold uppercase tracking-wider text-background">⭐ Top</div>
                      </div>
                    )}
                    <div className="p-4">
                      <h3 className="font-bold font-sans text-sm mb-1 text-foreground">{product.name}</h3>
                      {product.description && <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{product.description}</p>}
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-black text-primary">${product.price}</span>
                        {renderProductAddButton(product)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          );
        })()}

        {/* Lo más popular - based on recent 7-day sales */}
        {!selectedCategory && !searchQuery && trendingIds.length > 0 && (() => {
          const trendingProducts = trendingIds.map(id => products.find(p => p.id === id)).filter((p): p is Product => !!p && p.is_available !== false);
          if (trendingProducts.length === 0) return null;
          return (
            <section className="mb-8">
              <span className="text-xs font-semibold tracking-[0.2em] uppercase text-primary mb-4 block">🔥 Lo más popular</span>
              <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
                {trendingProducts.map(product => (
                  <div key={product.id} className="group shrink-0 w-60 rounded-2xl border border-border bg-card overflow-hidden hover:shadow-elevated transition-all duration-500 hover:-translate-y-1">
                    {product.image_url && (
                      <div className="relative h-36 overflow-hidden cursor-pointer" onClick={() => openOptionsModal(product)}>
                        <img src={product.image_url} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md bg-destructive/80 text-[10px] font-bold uppercase tracking-wider text-destructive-foreground">🔥 Popular</div>
                      </div>
                    )}
                    <div className="p-4">
                      <h3 className="font-bold font-sans text-sm mb-1 text-foreground">{product.name}</h3>
                      {product.description && <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{product.description}</p>}
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-black text-primary">${product.price}</span>
                        {renderProductAddButton(product)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          );
        })()}

        {/* Featured */}
        {!selectedCategory && !searchQuery && featuredProducts.length > 0 && (
          <section className="mb-10">
            <span className="text-xs font-semibold tracking-[0.2em] uppercase text-primary mb-4 block">⭐ Destacados</span>
            <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
              {featuredProducts.map(product => (
                <div key={product.id} className="group shrink-0 w-60 rounded-2xl border border-border bg-card overflow-hidden hover:shadow-elevated transition-all duration-500 hover:-translate-y-1">
                  {product.image_url && (
                    <div className="relative h-36 overflow-hidden cursor-pointer" onClick={() => openOptionsModal(product)}>
                      <img src={product.image_url} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md bg-gradient-to-r from-primary to-accent text-[10px] font-bold uppercase tracking-wider text-primary-foreground">Destacado</div>
                    </div>
                  )}
                  <div className="p-4">
                    <h3 className="font-bold font-sans text-sm mb-1 text-foreground">{product.name}</h3>
                    {product.description && <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{product.description}</p>}
                    {getProductOptionGroups(product.id).length > 0 && (
                      <p className="text-[10px] text-accent font-semibold mb-2">Personalizable</p>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-black text-primary">${product.price}</span>
                      {renderProductAddButton(product)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* All Products */}
        <section>
          <span className="text-xs font-semibold tracking-[0.2em] uppercase text-primary mb-2 block">Menú</span>
          <h2 className="text-2xl font-sans font-black tracking-tight mb-6 text-foreground">
            {selectedCategory ? categories.find(c => c.id === selectedCategory)?.name : "Todo el Menú"}
          </h2>
          {filteredProducts.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4"><UtensilsCrossed className="w-8 h-8 text-muted-foreground" /></div>
              <p className="text-muted-foreground">{products.length === 0 ? "Este restaurante aún no ha agregado productos." : "No se encontraron productos"}</p>
            </div>
          ) : (
            (() => {
              // Group products by category
              const categoriesToShow = selectedCategory 
                ? categories.filter(c => c.id === selectedCategory)
                : categories;
              const uncategorized = filteredProducts.filter(p => !p.category_id);
              
              return (
                <div className="space-y-8">
                  {categoriesToShow.map(cat => {
                    const catProducts = filteredProducts.filter(p => p.category_id === cat.id);
                    if (catProducts.length === 0) return null;
                    return (
                      <div key={cat.id}>
                        <div className="space-y-3">
                          {catProducts.map((product, index) => (
                            <div key={product.id}
                              className={`group flex items-center gap-4 p-4 rounded-2xl border border-border bg-card hover:shadow-soft transition-all duration-300 animate-fade-in ${product.is_available === false ? "opacity-50" : ""}`}
                              style={{ animationDelay: `${index * 0.04}s` }}>
                              {product.image_url && (
                                <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0 cursor-pointer" onClick={() => openOptionsModal(product)}>
                                  <img src={product.image_url} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                </div>
                              )}
                              <div className="flex-1 min-w-0">
                                <h3 className="font-bold font-sans text-sm mb-0.5 text-foreground">{product.name}</h3>
                                {(() => { const c = categories.find(c => c.id === product.category_id); return c ? <p className="text-[11px] text-accent font-medium mb-0.5">{c.icon && <span className="mr-1">{c.icon}</span>}{c.name}</p> : null; })()}
                                {product.description && <p className="text-xs text-muted-foreground line-clamp-2 mb-1">{product.description}</p>}
                                {getProductOptionGroups(product.id).length > 0 && (
                                  <p className="text-[10px] text-accent font-semibold mb-1">Personalizable</p>
                                )}
                                <span className="text-base font-black text-primary">${product.price}</span>
                              </div>
                              <div className="shrink-0">
                                {renderProductAddButton(product)}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                  {uncategorized.length > 0 && (
                    <div>
                      <div className="space-y-3">
                        {uncategorized.map((product, index) => (
                          <div key={product.id}
                            className={`group flex items-center gap-4 p-4 rounded-2xl border border-border bg-card hover:shadow-soft transition-all duration-300 animate-fade-in ${product.is_available === false ? "opacity-50" : ""}`}
                            style={{ animationDelay: `${index * 0.04}s` }}>
                            {product.image_url && (
                              <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0 cursor-pointer" onClick={() => openOptionsModal(product)}>
                                <img src={product.image_url} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <h3 className="font-bold font-sans text-sm mb-0.5 text-foreground">{product.name}</h3>
                              {product.description && <p className="text-xs text-muted-foreground line-clamp-2 mb-1">{product.description}</p>}
                              {getProductOptionGroups(product.id).length > 0 && (
                                <p className="text-[10px] text-accent font-semibold mb-1">Personalizable</p>
                              )}
                              <span className="text-base font-black text-primary">${product.price}</span>
                            </div>
                            <div className="shrink-0">
                              {renderProductAddButton(product)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })()
          )}
        </section>

        {/* Review Widget - once at the bottom */}
        {restaurant?.review_widget_id && (
          <div className="px-4 py-6">
            <ReviewWidgetEmbed code={restaurant.review_widget_id} />
          </div>
        )}
      </main>

      {/* Floating Cart Button */}
      {cartCount > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-[55] animate-fade-in p-4 bg-gradient-to-t from-background via-background to-transparent pb-5">
          <button onClick={() => { setCartOpen(true); setCheckoutStep("cart"); }}
            className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-2xl bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold shadow-elevated hover:shadow-glow active:scale-[0.98] transition-all duration-300">
            <ShoppingBag className="w-5 h-5" />
            <span>Ver Pedido ({cartCount})</span>
            <span className="w-px h-5 bg-primary-foreground/30" />
            <span className="font-black">${cartTotal.toFixed(2)}</span>
          </button>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 mt-12 mb-24">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <UtensilsCrossed className="w-3 h-3 text-primary-foreground" />
            </div>
            <span className="text-xs font-bold font-sans text-muted-foreground">Menu365</span>
          </div>
          <p className="text-xs text-muted-foreground/60">Menú digital por Menu365</p>
        </div>
      </footer>
    </div>
  );
};

export default PublicMenu;
