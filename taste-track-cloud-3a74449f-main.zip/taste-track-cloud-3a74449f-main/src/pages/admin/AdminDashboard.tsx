import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  UtensilsCrossed, 
  Store, 
  Users, 
  TrendingUp,
  Settings,
  LogOut,
  Search,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
  AlertCircle,
  Check,
  X,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { Tables } from "@/integrations/supabase/types";

type Restaurant = Tables<"restaurants"> & {
  productCount?: number;
  ownerName?: string;
};

const AdminDashboard = () => {
  const [user, setUser] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [stats, setStats] = useState({
    restaurants: 0,
    products: 0,
    users: 0,
  });
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [restaurantToDelete, setRestaurantToDelete] = useState<Restaurant | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.user) {
        navigate("/auth");
        return;
      }
      
      setUser(session.user);
      
      // Check if user is admin
      const { data: roleData, error: roleError } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", session.user.id)
        .eq("role", "admin")
        .maybeSingle();
      
      if (roleError) {
        console.error("Error checking admin role:", roleError);
      }
      
      if (!roleData) {
        toast({
          variant: "destructive",
          title: "Acceso denegado",
          description: "No tienes permisos de administrador.",
        });
        navigate("/owner");
        return;
      }
      
      setIsAdmin(true);
      await fetchData();
      setLoading(false);
    };

    checkSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session?.user) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate, toast]);

  const fetchData = async () => {
    try {
      // Fetch all restaurants (admin sees all via RLS policy)
      const { data: restaurantsData, error: restaurantsError } = await supabase
        .from("restaurants")
        .select("*")
        .order("created_at", { ascending: false });
      
      if (restaurantsError) throw restaurantsError;

      // Fetch product counts for each restaurant
      const restaurantsWithCounts = await Promise.all(
        (restaurantsData || []).map(async (restaurant) => {
          const { count } = await supabase
            .from("products")
            .select("*", { count: "exact", head: true })
            .eq("restaurant_id", restaurant.id);
          
          // Get owner profile
          const { data: profile } = await supabase
            .from("profiles")
            .select("full_name")
            .eq("user_id", restaurant.owner_id)
            .maybeSingle();
          
          return {
            ...restaurant,
            productCount: count || 0,
            ownerName: profile?.full_name || "Sin nombre",
          };
        })
      );

      setRestaurants(restaurantsWithCounts);

      // Fetch stats
      const { count: productsCount } = await supabase
        .from("products")
        .select("*", { count: "exact", head: true });
      
      const { count: usersCount } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true });
      
      setStats({
        restaurants: restaurantsData?.length || 0,
        products: productsCount || 0,
        users: usersCount || 0,
      });
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudieron cargar los datos.",
      });
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
    toast({
      title: "Sesión cerrada",
      description: "Has cerrado sesión correctamente.",
    });
  };

  const handleToggleActive = async (restaurant: Restaurant) => {
    try {
      const { error } = await supabase
        .from("restaurants")
        .update({ is_active: !restaurant.is_active })
        .eq("id", restaurant.id);
      
      if (error) throw error;
      
      toast({
        title: restaurant.is_active ? "Restaurante desactivado" : "Restaurante activado",
        description: `${restaurant.name} ha sido ${restaurant.is_active ? "desactivado" : "activado"}.`,
      });
      
      await fetchData();
    } catch (error) {
      console.error("Error toggling restaurant:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo cambiar el estado del restaurante.",
      });
    }
  };

  const handleDeleteRestaurant = async () => {
    if (!restaurantToDelete) return;
    
    try {
      // Delete related records first
      await supabase.from("products").delete().eq("restaurant_id", restaurantToDelete.id);
      await supabase.from("categories").delete().eq("restaurant_id", restaurantToDelete.id);
      await supabase.from("delivery_types").delete().eq("restaurant_id", restaurantToDelete.id);
      await supabase.from("payment_methods").delete().eq("restaurant_id", restaurantToDelete.id);
      
      // Delete restaurant
      const { error } = await supabase
        .from("restaurants")
        .delete()
        .eq("id", restaurantToDelete.id);
      
      if (error) throw error;
      
      toast({
        title: "Restaurante eliminado",
        description: `${restaurantToDelete.name} ha sido eliminado permanentemente.`,
      });
      
      setDeleteDialogOpen(false);
      setRestaurantToDelete(null);
      await fetchData();
    } catch (error) {
      console.error("Error deleting restaurant:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo eliminar el restaurante.",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Acceso Denegado</h2>
            <p className="text-muted-foreground mb-4">
              No tienes permisos para acceder al panel de administración.
            </p>
            <Button onClick={() => navigate("/owner")}>
              Ir al Panel de Propietario
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredRestaurants = restaurants.filter(r => 
    r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.ownerName?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const statsDisplay = [
    { label: "Restaurantes", value: stats.restaurants.toString(), icon: Store, trend: "+12%" },
    { label: "Productos Totales", value: stats.products.toString(), icon: UtensilsCrossed, trend: "+8%" },
    { label: "Usuarios", value: stats.users.toString(), icon: Users, trend: "+15%" },
    { label: "Ingresos", value: "$0", icon: TrendingUp, trend: "N/A" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-card border-r border-border hidden lg:block">
        <div className="p-6">
          <div className="flex items-center gap-2 mb-8">
            <div className="w-10 h-10 gradient-warm rounded-xl flex items-center justify-center">
              <UtensilsCrossed className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <span className="font-serif text-lg font-bold block">Menu365</span>
              <span className="text-xs text-muted-foreground">Panel Admin</span>
            </div>
          </div>

          <nav className="space-y-2">
            <Link
              to="/admin"
              className="flex items-center gap-3 px-4 py-3 rounded-lg bg-secondary text-foreground"
            >
              <Store className="w-5 h-5" />
              <span>Restaurantes</span>
            </Link>
            <Link
              to="/admin/users"
              className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
            >
              <Users className="w-5 h-5" />
              <span>Usuarios</span>
            </Link>
            <Link
              to="/admin/settings"
              className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
            >
              <Settings className="w-5 h-5" />
              <span>Configuración</span>
            </Link>
          </nav>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-border">
          <Button
            variant="ghost"
            className="w-full justify-start gap-2 text-muted-foreground"
            onClick={handleSignOut}
          >
            <LogOut className="w-5 h-5" />
            Cerrar Sesión
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64">
        {/* Header */}
        <header className="sticky top-0 bg-background/80 backdrop-blur-lg border-b border-border z-10">
          <div className="px-6 py-4 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-serif font-bold">Panel de Administración</h1>
              <p className="text-muted-foreground text-sm">
                Gestiona todos los restaurantes de la plataforma
              </p>
            </div>
            <Button variant="ghost" className="lg:hidden" onClick={handleSignOut}>
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </header>

        {/* Stats */}
        <div className="p-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {statsDisplay.map((stat) => (
              <Card key={stat.label}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <stat.icon className="w-5 h-5 text-primary" />
                    <Badge variant="secondary" className="text-xs">
                      {stat.trend}
                    </Badge>
                  </div>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Restaurants Table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Restaurantes ({restaurants.length})</CardTitle>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar restaurante..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {filteredRestaurants.length === 0 ? (
                <div className="text-center py-12">
                  <Store className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No hay restaurantes</h3>
                  <p className="text-muted-foreground">
                    {searchQuery ? "No se encontraron restaurantes con ese criterio." : "Aún no hay restaurantes registrados en la plataforma."}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                          Restaurante
                        </th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                          Propietario
                        </th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                          Productos
                        </th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                          Estado
                        </th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                          Fecha
                        </th>
                        <th className="text-right py-3 px-4 font-medium text-muted-foreground">
                          Acciones
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRestaurants.map((restaurant) => (
                        <tr key={restaurant.id} className="border-b border-border hover:bg-secondary/50 transition-colors">
                          <td className="py-4 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 gradient-warm rounded-lg flex items-center justify-center text-primary-foreground">
                                <Store className="w-5 h-5" />
                              </div>
                              <div>
                                <span className="font-medium block">{restaurant.name}</span>
                                <span className="text-xs text-muted-foreground">{restaurant.slug}</span>
                              </div>
                            </div>
                          </td>
                          <td className="py-4 px-4 text-muted-foreground">
                            {restaurant.ownerName}
                          </td>
                          <td className="py-4 px-4">
                            {restaurant.productCount}
                          </td>
                          <td className="py-4 px-4">
                            <Badge variant={restaurant.is_active ? "default" : "secondary"}>
                              {restaurant.is_active ? "Activo" : "Inactivo"}
                            </Badge>
                          </td>
                          <td className="py-4 px-4 text-muted-foreground">
                            {new Date(restaurant.created_at).toLocaleDateString("es-ES")}
                          </td>
                          <td className="py-4 px-4 text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreVertical className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => navigate(`/menu/${restaurant.slug}`)}>
                                  <Eye className="w-4 h-4 mr-2" />
                                  Ver Menú
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleToggleActive(restaurant)}>
                                  {restaurant.is_active ? (
                                    <>
                                      <X className="w-4 h-4 mr-2" />
                                      Desactivar
                                    </>
                                  ) : (
                                    <>
                                      <Check className="w-4 h-4 mr-2" />
                                      Activar
                                    </>
                                  )}
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="text-destructive"
                                  onClick={() => {
                                    setRestaurantToDelete(restaurant);
                                    setDeleteDialogOpen(true);
                                  }}
                                >
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Eliminar
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar restaurante?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción eliminará permanentemente <strong>{restaurantToDelete?.name}</strong> y todos sus productos, categorías y configuraciones. Esta acción no se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteRestaurant} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AdminDashboard;
