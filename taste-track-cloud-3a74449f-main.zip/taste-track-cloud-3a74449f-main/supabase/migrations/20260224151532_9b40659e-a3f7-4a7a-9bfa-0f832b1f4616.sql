
-- Add Stripe secret key to restaurants (each owner has their own Stripe account)
ALTER TABLE public.restaurants 
ADD COLUMN stripe_secret_key text;

-- Add payment tracking columns to orders
ALTER TABLE public.orders 
ADD COLUMN payment_status text NOT NULL DEFAULT 'pending',
ADD COLUMN stripe_session_id text;
