
-- Option groups for products (e.g., "Tamaño", "Extras", "Ingredientes")
CREATE TABLE public.product_option_groups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  restaurant_id UUID NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  is_required BOOLEAN NOT NULL DEFAULT false,
  min_selections INTEGER NOT NULL DEFAULT 0,
  max_selections INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Individual options within a group (e.g., "Chica $80", "Mediana $120", "Grande $150")
CREATE TABLE public.product_options (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  option_group_id UUID NOT NULL REFERENCES public.product_option_groups(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  price_adjustment NUMERIC NOT NULL DEFAULT 0,
  is_available BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- RLS for product_option_groups
ALTER TABLE public.product_option_groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view option groups" ON public.product_option_groups
  FOR SELECT USING (true);

CREATE POLICY "Owners can manage their option groups" ON public.product_option_groups
  FOR ALL USING (
    EXISTS (SELECT 1 FROM restaurants WHERE restaurants.id = product_option_groups.restaurant_id AND restaurants.owner_id = auth.uid())
  );

CREATE POLICY "Admins can manage all option groups" ON public.product_option_groups
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS for product_options
ALTER TABLE public.product_options ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view available options" ON public.product_options
  FOR SELECT USING (true);

CREATE POLICY "Owners can manage their options" ON public.product_options
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM product_option_groups pog
      JOIN restaurants r ON r.id = pog.restaurant_id
      WHERE pog.id = product_options.option_group_id AND r.owner_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all options" ON public.product_options
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
