
-- Fix: Restrict product-images storage to restaurant owners only
-- Files are stored as {restaurant_id}/{filename}, so we scope by foldername

-- Drop overly permissive policies
DROP POLICY IF EXISTS "Authenticated users can upload product images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can update product images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete product images" ON storage.objects;

-- Keep public read access (unchanged)
-- "Anyone can view product images" remains

-- Create ownership-scoped write policies
CREATE POLICY "Restaurant owners can upload their images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'product-images' AND
  (storage.foldername(name))[1] IN (
    SELECT id::text FROM public.restaurants WHERE owner_id = auth.uid()
  )
);

CREATE POLICY "Restaurant owners can update their images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'product-images' AND
  (storage.foldername(name))[1] IN (
    SELECT id::text FROM public.restaurants WHERE owner_id = auth.uid()
  )
);

CREATE POLICY "Restaurant owners can delete their images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'product-images' AND
  (storage.foldername(name))[1] IN (
    SELECT id::text FROM public.restaurants WHERE owner_id = auth.uid()
  )
);

-- Also allow admins to manage all images
CREATE POLICY "Admins can manage all product images"
ON storage.objects FOR ALL
USING (
  bucket_id = 'product-images' AND
  public.has_role(auth.uid(), 'admin')
)
WITH CHECK (
  bucket_id = 'product-images' AND
  public.has_role(auth.uid(), 'admin')
);
