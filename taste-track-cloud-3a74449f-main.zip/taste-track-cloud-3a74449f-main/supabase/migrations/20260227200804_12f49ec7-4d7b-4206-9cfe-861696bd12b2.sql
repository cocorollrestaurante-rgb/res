ALTER TABLE public.restaurants
ADD COLUMN IF NOT EXISTS delivery_fee_type text NOT NULL DEFAULT 'distance';