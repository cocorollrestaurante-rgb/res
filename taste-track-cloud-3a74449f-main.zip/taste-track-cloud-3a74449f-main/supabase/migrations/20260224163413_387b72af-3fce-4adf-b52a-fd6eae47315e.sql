
-- Add review tracking to orders
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS review_email_sent boolean NOT NULL DEFAULT false;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivered_at timestamp with time zone;

-- Add review link to restaurants
ALTER TABLE public.restaurants ADD COLUMN IF NOT EXISTS review_link text;
