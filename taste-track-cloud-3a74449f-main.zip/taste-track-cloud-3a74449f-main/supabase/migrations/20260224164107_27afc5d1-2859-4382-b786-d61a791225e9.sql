
-- Trigger to auto-set delivered_at when order status changes to 'delivered'
CREATE OR REPLACE FUNCTION public.set_order_delivered_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.status = 'delivered' AND (OLD.status IS DISTINCT FROM 'delivered') THEN
    NEW.delivered_at = now();
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_set_order_delivered_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.set_order_delivered_at();
