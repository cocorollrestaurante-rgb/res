
-- Fix 1: Restrict order SELECT policies to owners and admins only
DROP POLICY "Anyone can view orders" ON public.orders;
DROP POLICY "Anyone can view order items" ON public.order_items;

CREATE POLICY "Owners can view their orders"
  ON public.orders FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM restaurants
      WHERE restaurants.id = orders.restaurant_id
      AND restaurants.owner_id = auth.uid()
    ) OR
    has_role(auth.uid(), 'admin'::app_role)
  );

CREATE POLICY "Owners can view their order items"
  ON public.order_items FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM orders
      JOIN restaurants ON restaurants.id = orders.restaurant_id
      WHERE orders.id = order_items.order_id
      AND restaurants.owner_id = auth.uid()
    ) OR
    has_role(auth.uid(), 'admin'::app_role)
  );
