-- Enable realtime for orders table so tracking page can use it
ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;