-- Allow anyone to SELECT a single order by ID (for public tracking page)
CREATE POLICY "Anyone can view order for tracking"
ON public.orders
FOR SELECT
USING (true);
