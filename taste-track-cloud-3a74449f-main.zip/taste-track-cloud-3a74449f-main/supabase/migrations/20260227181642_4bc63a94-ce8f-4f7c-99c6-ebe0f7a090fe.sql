
-- Add geolocation and distance-based delivery pricing to restaurants
ALTER TABLE public.restaurants
  ADD COLUMN IF NOT EXISTS latitude double precision DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS longitude double precision DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS delivery_base_fee numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS delivery_price_per_km numeric DEFAULT 0;
