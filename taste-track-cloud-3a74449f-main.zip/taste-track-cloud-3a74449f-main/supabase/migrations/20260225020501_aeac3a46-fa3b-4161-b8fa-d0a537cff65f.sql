
-- Remove stripe_secret_key column from restaurants (no longer needed)
ALTER TABLE public.restaurants DROP COLUMN IF EXISTS stripe_secret_key;

-- Remove stripe_session_id from orders (no longer needed)
ALTER TABLE public.orders DROP COLUMN IF EXISTS stripe_session_id;
