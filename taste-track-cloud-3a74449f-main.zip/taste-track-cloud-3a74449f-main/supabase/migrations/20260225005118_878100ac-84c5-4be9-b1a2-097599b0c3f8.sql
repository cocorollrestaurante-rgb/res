-- Add is_upsell flag to products
ALTER TABLE public.products ADD COLUMN is_upsell boolean DEFAULT false;