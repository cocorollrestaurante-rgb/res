
ALTER TABLE public.restaurants ADD COLUMN instagram_url text DEFAULT NULL;
ALTER TABLE public.restaurants ADD COLUMN facebook_url text DEFAULT NULL;
ALTER TABLE public.restaurants ADD COLUMN website_url text DEFAULT NULL;
