
-- Add transfer_details column to payment_methods for bank transfer info
ALTER TABLE public.payment_methods ADD COLUMN transfer_details text;
