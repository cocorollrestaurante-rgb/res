import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = 10;
const RATE_WINDOW_MS = 60 * 60 * 1000;

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_WINDOW_MS });
    return false;
  }
  entry.count++;
  return entry.count > RATE_LIMIT;
}

function haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const clientIp = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      req.headers.get("cf-connecting-ip") || "unknown";
    if (isRateLimited(clientIp)) {
      return res(429, "Demasiadas solicitudes. Intenta de nuevo más tarde.");
    }

    const body = await req.json();

    const { restaurant_id, customer_name, customer_phone, customer_email, customer_address,
      delivery_type_id, payment_method_id, notes, cart_items, customer_latitude, customer_longitude,
      onesignal_player_id } = body;

    if (!restaurant_id || typeof restaurant_id !== "string" || restaurant_id.length > 50) {
      return res(400, "restaurant_id inválido");
    }
    if (!customer_name || typeof customer_name !== "string" || customer_name.trim().length < 1 || customer_name.length > 100) {
      return res(400, "Nombre inválido (máx 100 caracteres)");
    }
    if (!customer_phone || typeof customer_phone !== "string" || customer_phone.trim().length < 5 || customer_phone.length > 20) {
      return res(400, "Teléfono inválido (5-20 caracteres)");
    }
    if (customer_email && typeof customer_email === "string" && customer_email.length > 0) {
      if (customer_email.length > 255 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer_email)) {
        return res(400, "Email inválido");
      }
    }
    if (customer_address && typeof customer_address === "string" && customer_address.length > 500) {
      return res(400, "Dirección demasiado larga (máx 500)");
    }
    if (notes && typeof notes === "string" && notes.length > 1000) {
      return res(400, "Notas demasiado largas (máx 1000)");
    }
    if (!Array.isArray(cart_items) || cart_items.length === 0 || cart_items.length > 100) {
      return res(400, "El carrito debe tener entre 1 y 100 productos");
    }

    for (const item of cart_items) {
      if (!item.product_id || typeof item.product_id !== "string") return res(400, "product_id inválido en carrito");
      if (!Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 100) return res(400, "Cantidad inválida");
      if (typeof item.product_name !== "string" || item.product_name.length > 300) return res(400, "Nombre de producto inválido");
      if (item.option_ids !== undefined && item.option_ids !== null) {
        if (!Array.isArray(item.option_ids) || item.option_ids.some((id: any) => typeof id !== "string")) {
          return res(400, "option_ids inválido");
        }
        if (item.option_ids.length > 50) return res(400, "Demasiadas opciones seleccionadas");
      }
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    // Verify restaurant exists - include delivery pricing fields
    const { data: restaurant, error: restErr } = await supabase
      .from("restaurants").select("id, latitude, longitude, delivery_base_fee, delivery_price_per_km, delivery_fee_type")
      .eq("id", restaurant_id).eq("is_active", true).single();
    if (restErr || !restaurant) return res(404, "Restaurante no encontrado");

    // Verify delivery_type belongs to restaurant if provided
    let deliveryTypeName = "";
    if (delivery_type_id) {
      const { data: dt } = await supabase.from("delivery_types")
        .select("id, price, name").eq("id", delivery_type_id).eq("restaurant_id", restaurant_id).eq("is_active", true).single();
      if (!dt) return res(400, "Tipo de entrega inválido para este restaurante");
      deliveryTypeName = dt.name || "";
    }

    if (payment_method_id) {
      const { data: pm } = await supabase.from("payment_methods")
        .select("id").eq("id", payment_method_id).eq("restaurant_id", restaurant_id).eq("is_active", true).single();
      if (!pm) return res(400, "Método de pago inválido para este restaurante");
    }

    const productIds = cart_items.map((i: any) => i.product_id);
    const { data: products, error: prodErr } = await supabase
      .from("products").select("id, price, name, is_available")
      .in("id", productIds).eq("restaurant_id", restaurant_id);
    if (prodErr) throw prodErr;

    const productMap = new Map((products || []).map((p: any) => [p.id, p]));

    for (const item of cart_items) {
      const product = productMap.get(item.product_id);
      if (!product) return res(400, `Producto no encontrado: ${item.product_id}`);
      if (!product.is_available) return res(400, `Producto no disponible: ${product.name}`);
    }

    // Calculate delivery fee - distance-based for Domicilio
    let deliveryFee = 0;
    const isDomicilio = deliveryTypeName.toLowerCase().includes("domicilio");

    if (delivery_type_id && isDomicilio) {
      const feeType = restaurant.delivery_fee_type || 'distance';
      const baseFee = restaurant.delivery_base_fee || 0;

      if (feeType === 'fixed') {
        deliveryFee = baseFee;
      } else if (restaurant.latitude && restaurant.longitude && customer_latitude && customer_longitude) {
        // Distance-based calculation
        const distanceKm = haversineDistance(
          restaurant.latitude, restaurant.longitude,
          customer_latitude, customer_longitude
        );
        const perKm = restaurant.delivery_price_per_km || 0;
        deliveryFee = Math.round((baseFee + perKm * distanceKm) * 100) / 100;
      } else {
        // Fallback to flat price from delivery_types table
        const { data: dt } = await supabase.from("delivery_types")
          .select("price").eq("id", delivery_type_id).single();
        deliveryFee = dt?.price || 0;
      }
    } else if (delivery_type_id) {
      const { data: dt } = await supabase.from("delivery_types")
        .select("price").eq("id", delivery_type_id).single();
      deliveryFee = dt?.price || 0;
    }

    // Collect all option IDs
    const allOptionIds: string[] = [];
    for (const item of cart_items) {
      if (Array.isArray(item.option_ids)) {
        allOptionIds.push(...item.option_ids);
      }
    }

    const optionMap = new Map<string, number>();
    if (allOptionIds.length > 0) {
      const { data: options } = await supabase
        .from("product_options")
        .select("id, price_adjustment, is_available")
        .in("id", allOptionIds);
      for (const opt of options || []) {
        if (opt.is_available) {
          optionMap.set(opt.id, opt.price_adjustment || 0);
        }
      }
    }

    let subtotal = 0;
    const orderItems: any[] = [];
    for (const item of cart_items) {
      const dbProduct = productMap.get(item.product_id)!;
      let optionTotal = 0;
      if (Array.isArray(item.option_ids)) {
        for (const optId of item.option_ids) {
          optionTotal += optionMap.get(optId) || 0;
        }
      }
      const itemPrice = dbProduct.price + optionTotal;
      const itemSubtotal = itemPrice * item.quantity;
      subtotal += itemSubtotal;
      orderItems.push({
        product_id: item.product_id,
        product_name: item.product_name.substring(0, 300),
        product_price: itemPrice,
        quantity: item.quantity,
        subtotal: itemSubtotal,
      });
    }

    const total = subtotal + deliveryFee;

    const { data: order, error: orderErr } = await supabase.from("orders").insert({
      restaurant_id,
      customer_name: customer_name.trim().substring(0, 100),
      customer_phone: customer_phone.trim().substring(0, 20),
      customer_email: customer_email?.trim()?.substring(0, 255) || null,
      customer_address: customer_address?.substring(0, 500) || null,
      delivery_type_id: delivery_type_id || null,
      payment_method_id: payment_method_id || null,
      notes: notes?.trim()?.substring(0, 1000) || null,
      subtotal,
      delivery_fee: deliveryFee,
      total,
      onesignal_player_id: (typeof onesignal_player_id === "string" && onesignal_player_id.length < 100) ? onesignal_player_id : null,
    }).select("id, order_number").single();

    if (orderErr) throw orderErr;

    const itemsToInsert = orderItems.map((item: any) => ({
      ...item,
      order_id: order.id,
    }));
    const { error: itemsErr } = await supabase.from("order_items").insert(itemsToInsert);
    if (itemsErr) throw itemsErr;

    return new Response(
      JSON.stringify({ id: order.id, order_number: order.order_number, delivery_fee: deliveryFee }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("create-order error:", e instanceof Error ? { message: e.message, name: e.name } : "Unknown error");
    return new Response(
      JSON.stringify({ error: "Error al procesar el pedido" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function res(status: number, message: string) {
  return new Response(
    JSON.stringify({ error: message }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}
