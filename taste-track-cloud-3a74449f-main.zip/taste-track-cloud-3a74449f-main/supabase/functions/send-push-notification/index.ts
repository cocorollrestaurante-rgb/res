import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const statusMessages: Record<string, { title: string; body: string }> = {
  confirmed: {
    title: "✅ Pedido confirmado",
    body: "Tu pedido #ORDER ha sido confirmado y pronto comenzará a prepararse.",
  },
  preparing: {
    title: "👨‍🍳 Preparando tu pedido",
    body: "Tu pedido #ORDER se está preparando. ¡Ya casi!",
  },
  ready: {
    title: "🎉 ¡Tu pedido está listo!",
    body: "Tu pedido #ORDER está listo para entrega o recogida.",
  },
  on_the_way: {
    title: "🚗 ¡Tu pedido va en camino!",
    body: "Tu pedido #ORDER está en camino. ¡Prepárate para recibirlo!",
  },
  delivered: {
    title: "📦 Pedido entregado",
    body: "Tu pedido #ORDER ha sido entregado. ¡Buen provecho!",
  },
  cancelled: {
    title: "❌ Pedido cancelado",
    body: "Tu pedido #ORDER ha sido cancelado. Contacta al restaurante para más info.",
  },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "No autorizado" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "No autorizado" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { order_id, new_status } = await req.json();

    if (!order_id || !new_status) {
      return new Response(JSON.stringify({ error: "Faltan parámetros" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const messageTemplate = statusMessages[new_status];
    if (!messageTemplate) {
      return new Response(JSON.stringify({ message: "Estado sin notificación configurada" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get order info including the player_id
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .select("order_number, customer_phone, restaurant_id, onesignal_player_id")
      .eq("id", order_id)
      .maybeSingle();

    if (orderError || !order) {
      return new Response(JSON.stringify({ error: "Pedido no encontrado" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!order.onesignal_player_id) {
      console.log("No player_id saved for this order — skipping push notification");
      return new Response(
        JSON.stringify({ success: true, recipients: 0, reason: "no_player_id" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const title = messageTemplate.title;
    const body = messageTemplate.body.replace("#ORDER", `#${order.order_number}`);

    const appId = Deno.env.get("ONESIGNAL_APP_ID");
    const apiKey = Deno.env.get("ONESIGNAL_REST_API_KEY");

    if (!appId || !apiKey) {
      console.error("OneSignal credentials not configured");
      return new Response(JSON.stringify({ error: "Notificaciones no configuradas" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Use include_subscription_ids with the saved player_id — much more reliable than tags
    const onesignalPayload = {
      app_id: appId,
      headings: { en: title, es: title },
      contents: { en: body, es: body },
      include_subscription_ids: [order.onesignal_player_id],
      url: `${Deno.env.get("APP_URL") || "https://menu365.com.mx"}/order/tracking/${order_id}`,
      data: {
        order_id,
        order_number: order.order_number,
        status: new_status,
      },
    };

    console.log("Sending push to player:", order.onesignal_player_id);

    const onesignalResponse = await fetch("https://api.onesignal.com/notifications", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Key ${apiKey}`,
      },
      body: JSON.stringify(onesignalPayload),
    });

    const onesignalResult = await onesignalResponse.json();
    console.log("OneSignal response:", JSON.stringify(onesignalResult));

    if (!onesignalResponse.ok) {
      console.error("OneSignal error:", JSON.stringify(onesignalResult));
      return new Response(
        JSON.stringify({ error: "Error al enviar notificación", details: onesignalResult }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, recipients: onesignalResult.recipients || 0 }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Push notification error:", err);
    return new Response(JSON.stringify({ error: "Error interno" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
