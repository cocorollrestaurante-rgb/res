import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const appId = Deno.env.get("ONESIGNAL_APP_ID");
    const apiKey = Deno.env.get("ONESIGNAL_REST_API_KEY");

    if (!appId || !apiKey) {
      console.error("OneSignal credentials not configured");
      return new Response(JSON.stringify({ error: "OneSignal not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Find orders delivered ~2 hours ago that haven't received review push
    const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
    const twoHoursThirtyAgo = new Date(Date.now() - 2.5 * 60 * 60 * 1000).toISOString();

    const { data: orders, error: ordersError } = await supabase
      .from("orders")
      .select("id, order_number, customer_name, onesignal_player_id, restaurant_id")
      .eq("status", "delivered")
      .eq("review_push_sent", false)
      .not("onesignal_player_id", "is", null)
      .not("delivered_at", "is", null)
      .gte("delivered_at", twoHoursThirtyAgo)
      .lte("delivered_at", twoHoursAgo);

    if (ordersError) {
      console.error("Error fetching orders:", ordersError);
      return new Response(JSON.stringify({ error: ordersError.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!orders || orders.length === 0) {
      console.log("No orders pending review push");
      return new Response(JSON.stringify({ sent: 0 }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get restaurant info for review links
    const restaurantIds = [...new Set(orders.map((o) => o.restaurant_id))];
    const { data: restaurants } = await supabase
      .from("restaurants")
      .select("id, name, review_link")
      .in("id", restaurantIds);

    const restaurantMap = new Map(
      (restaurants || []).map((r) => [r.id, r])
    );

    let sentCount = 0;

    for (const order of orders) {
      const restaurant = restaurantMap.get(order.restaurant_id);
      if (!restaurant?.review_link) {
        console.log(`Restaurant ${order.restaurant_id} has no review_link — skipping`);
        // Mark as sent to avoid retrying
        await supabase
          .from("orders")
          .update({ review_push_sent: true })
          .eq("id", order.id);
        continue;
      }

      const onesignalPayload = {
        app_id: appId,
        headings: {
          en: "⭐ ¿Te gustó tu pedido?",
          es: "⭐ ¿Te gustó tu pedido?",
        },
        contents: {
          en: `${order.customer_name}, tu opinión sobre ${restaurant.name} nos ayuda mucho. ¡Déjanos una reseña!`,
          es: `${order.customer_name}, tu opinión sobre ${restaurant.name} nos ayuda mucho. ¡Déjanos una reseña!`,
        },
        include_subscription_ids: [order.onesignal_player_id],
        url: restaurant.review_link,
        data: { type: "review_request", order_id: order.id },
      };

      console.log(`Sending review push for order ${order.order_number} to player ${order.onesignal_player_id}`);

      const response = await fetch("https://api.onesignal.com/notifications", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Key ${apiKey}`,
        },
        body: JSON.stringify(onesignalPayload),
      });

      const result = await response.json();
      console.log(`OneSignal response for order ${order.order_number}:`, JSON.stringify(result));

      // Mark as sent regardless of result to avoid spam
      await supabase
        .from("orders")
        .update({ review_push_sent: true })
        .eq("id", order.id);

      if (response.ok) {
        sentCount++;
      }
    }

    return new Response(
      JSON.stringify({ sent: sentCount, total: orders.length }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Review push error:", err);
    return new Response(JSON.stringify({ error: "Internal error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
