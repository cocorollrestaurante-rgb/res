import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Authenticate caller and verify admin role
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: roleData } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'admin')
      .maybeSingle();

    if (!roleData) {
      return new Response(JSON.stringify({ error: 'Forbidden - Admin only' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
    if (!RESEND_API_KEY) throw new Error('RESEND_API_KEY is not configured');

    // Find delivered orders from 2+ hours ago that haven't had review email sent
    const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();

    const { data: orders, error: ordersError } = await supabase
      .from('orders')
      .select('id, customer_name, customer_email, restaurant_id, delivered_at')
      .eq('status', 'delivered')
      .eq('review_email_sent', false)
      .not('customer_email', 'is', null)
      .not('delivered_at', 'is', null)
      .lte('delivered_at', twoHoursAgo)
      .limit(50);

    if (ordersError) throw ordersError;
    if (!orders || orders.length === 0) {
      return new Response(JSON.stringify({ message: 'No orders to process' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Get unique restaurant IDs and fetch their info
    const restaurantIds = [...new Set(orders.map(o => o.restaurant_id))];
    const { data: restaurants } = await supabase
      .from('restaurants')
      .select('id, name, review_link, logo_url')
      .in('id', restaurantIds);

    const restaurantMap = new Map(restaurants?.map(r => [r.id, r]) || []);

    let sent = 0;
    let skipped = 0;

    for (const order of orders) {
      const restaurant = restaurantMap.get(order.restaurant_id);
      if (!restaurant?.review_link) {
        skipped++;
        continue;
      }

      const emailHtml = `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 520px; margin: 0 auto; padding: 32px 24px;">
          <h2 style="color: #1a1a1a; margin: 0 0 16px;">¡Hola ${order.customer_name}! 👋</h2>
          <p style="color: #333; font-size: 15px; line-height: 1.7; margin: 0 0 16px;">
            Esperamos que hayas disfrutado tu pedido de <strong>${restaurant.name}</strong>.
          </p>
          <p style="color: #333; font-size: 15px; line-height: 1.7; margin: 0 0 16px;">
            Tu opinión es muy valiosa para nosotros y nos ayuda a seguir mejorando. ¿Podrías dedicarnos un momento para dejarnos una reseña? ⭐
          </p>
          <p style="margin: 24px 0;">
            <a href="${restaurant.review_link}" target="_blank" style="display: inline-block; background: #f97316; color: #fff; text-decoration: none; padding: 12px 28px; border-radius: 8px; font-weight: 600; font-size: 15px;">
              Dejar mi reseña
            </a>
          </p>
          <p style="color: #666; font-size: 13px; margin-top: 32px; border-top: 1px solid #eee; padding-top: 16px;">
            Gracias por ser parte de ${restaurant.name}. ¡Te esperamos pronto!
          </p>
        </div>
      `;

      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: `${restaurant.name} <onboarding@resend.dev>`,
          to: [order.customer_email],
          subject: `${order.customer_name}, ¿qué te pareció tu pedido? ⭐`,
          html: emailHtml,
        }),
      });

      if (res.ok) {
        await supabase
          .from('orders')
          .update({ review_email_sent: true })
          .eq('id', order.id);
        sent++;
      } else {
        const errBody = await res.text();
        console.error(`Failed to send email for order ${order.id}: ${res.status} ${errBody}`);
      }
    }

    return new Response(JSON.stringify({ sent, skipped, total: orders.length }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in send-review-emails:', error instanceof Error ? { message: error.message, name: error.name } : 'Unknown error');
    return new Response(JSON.stringify({ error: 'Error al procesar emails de reseñas' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
