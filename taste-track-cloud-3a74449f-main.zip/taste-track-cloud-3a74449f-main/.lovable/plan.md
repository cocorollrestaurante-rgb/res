

## Plan: Integración de Stripe para pagos en línea

### Resumen

Permitir que los dueños de restaurantes conecten su cuenta de Stripe para aceptar pagos en línea directamente desde el menú público.

### Cómo funcionará

1. **Configuración del dueño**: En la sección de Configuración del panel del dueño, habrá una opción para conectar Stripe ingresando su clave secreta (Secret Key) de Stripe.
2. **Pago en el menú público**: Cuando un cliente haga un pedido, podrá pagar con tarjeta de crédito/débito a través de Stripe Checkout.
3. **Registro automático**: El pago quedará vinculado al pedido en el sistema.

### Pasos técnicos

1. **Habilitar la integración de Stripe en Lovable** — Lovable tiene una integración nativa con Stripe que facilita la configuración.

2. **Crear una edge function** para procesar pagos usando Stripe Checkout Sessions, donde cada pedido genera un enlace de pago.

3. **Agregar columnas a la tabla `orders`** para registrar el estado del pago (`payment_status`, `stripe_session_id`).

4. **UI del dueño** — Sección en Configuración para ingresar/gestionar la clave de Stripe.

5. **UI del cliente** — Al confirmar un pedido, redirigir a Stripe Checkout para completar el pago.

6. **Webhook** — Edge function para recibir confirmaciones de pago de Stripe y actualizar el estado del pedido automáticamente.

### Consideraciones

- Cada dueño usará **su propia cuenta de Stripe**, por lo que los pagos van directo a ellos.
- La clave secreta de Stripe se almacenará de forma segura como un secret en el backend.
- Se necesitará que el dueño tenga una cuenta de Stripe activa con sus datos bancarios configurados.

### Primer paso

Antes de escribir código, necesito **habilitar la integración de Stripe** en el proyecto. Esto configurará las herramientas y el conocimiento necesario para implementar pagos correctamente.

